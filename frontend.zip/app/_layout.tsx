import { DarkTheme, DefaultTheme, ThemeProvider as NavigationThemeProvider } from '@react-navigation/native';
import { Stack, useRouter, useSegments } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import 'react-native-reanimated';
import { useEffect } from 'react';
import { View, Text, ActivityIndicator } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Colors } from '@/constants/theme';

import { AuthProvider, useAuth } from '../context/AuthContext';
import { ProductProvider } from '../context/ProductContext';
import { CartProvider } from '../context/CartContext';
import { WishlistProvider } from '../context/WishlistContext';
import { ThemeProvider, useAppTheme } from '../context/ThemeContext';
import { OrderProvider } from '../context/OrderContext';


export const unstable_settings = {
  anchor: '(tabs)',
};

function RootLayoutNav() {
  const { theme, isDark } = useAppTheme();
  const { user, isLoading } = useAuth();
  const segments = useSegments();
  const router = useRouter();
  const colors = Colors[theme];

  useEffect(() => {
    if (isLoading) return;

    const inAuthGroup = segments[0] === '(auth)';

    if (!user && !inAuthGroup) {
      router.replace('/(auth)/login');
    } else if (user && inAuthGroup) {
      if (user.role === 'admin') {
        router.replace('/(tabs)/admin-dashboard');
      } else {
        router.replace('/(tabs)');
      }
    }
  }, [user, isLoading, segments]);

  if (isLoading) {
    return (
      <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: isDark ? '#151718' : '#F9F9F9' }}>
        <View style={{ width: 100, height: 100, borderRadius: 30, backgroundColor: '#D4AF37', justifyContent: 'center', alignItems: 'center', marginBottom: 20 }}>
          <Ionicons name="diamond" size={50} color="#fff" />
        </View>
        <ActivityIndicator size="large" color="#D4AF37" />
        <Text style={{ marginTop: 20, color: isDark ? '#D4AF37' : '#B8860B', fontSize: 24, fontWeight: '900', letterSpacing: 2 }}>ZEEFASHION</Text>
      </View>
    );
  }

  return (
    <NavigationThemeProvider value={isDark ? DarkTheme : DefaultTheme}>
      <Stack>
        <Stack.Screen name="(tabs)" options={{ headerShown: false }} />
        <Stack.Screen name="(auth)" options={{ headerShown: false }} />
        <Stack.Screen name="modal" options={{ presentation: 'modal', title: 'Modal' }} />
      </Stack>
      <StatusBar style={isDark ? 'light' : 'dark'} />
    </NavigationThemeProvider>
  );
}


export default function RootLayout() {
  return (
    <AuthProvider>
      <ThemeProvider>
        <ProductProvider>
          <CartProvider>
            <WishlistProvider>
              <OrderProvider>
                <RootLayoutNav />
              </OrderProvider>
            </WishlistProvider>
          </CartProvider>
        </ProductProvider>
      </ThemeProvider>
    </AuthProvider>
  );
}

