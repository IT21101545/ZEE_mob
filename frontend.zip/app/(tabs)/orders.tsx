import React, { useEffect, useState } from 'react';
import { 
  View, 
  Text, 
  FlatList, 
  StyleSheet, 
  TouchableOpacity, 
  ActivityIndicator,
  SafeAreaView
} from 'react-native';
import { useOrders } from '../../context/OrderContext';
import { useAuth } from '../../context/AuthContext';
import { useAppTheme } from '../../context/ThemeContext';
import { Colors } from '@/constants/theme';
import { Ionicons, MaterialIcons } from '@expo/vector-icons';
import { useRouter } from 'expo-router';

export default function OrdersScreen() {
  const { orders, isLoading, fetchMyOrders, fetchAllOrders, updateStatus } = useOrders();
  const { user } = useAuth();
  const { theme, isDark } = useAppTheme();
  const router = useRouter();
  const colors = Colors[theme];

  const isAdmin = user?.role === 'admin';

  useEffect(() => {
    if (isAdmin) fetchAllOrders();
    else fetchMyOrders();
  }, [isAdmin]);

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'Pending': return '#FF9500';
      case 'Shipped': return '#007AFF';
      case 'Delivered': return '#34C759';
      case 'Cancelled': return '#FF3B30';
      default: return '#999';
    }
  };

  const renderOrder = ({ item }: { item: any }) => (
    <TouchableOpacity 
      style={[styles.orderCard, { backgroundColor: colors.card }]}
      onPress={() => router.push(`/order/${item._id}`)}
    >
      <View style={styles.orderHeader}>
        <View>
          <Text style={[styles.orderId, { color: colors.text }]}>Order #{item._id.slice(-6).toUpperCase()}</Text>
          <Text style={styles.orderDate}>{new Date(item.createdAt).toLocaleDateString()}</Text>
        </View>
        <View style={[styles.statusBadge, { backgroundColor: getStatusColor(item.status) + '20' }]}>
          <Text style={[styles.statusText, { color: getStatusColor(item.status) }]}>{item.status}</Text>
        </View>
      </View>

      <View style={styles.orderItems}>
        {item.orderItems?.map((oi: any, idx: number) => (
          <View key={idx} style={styles.itemRow}>
            <Text style={[styles.itemLine, { color: colors.text, flex: 1 }]} numberOfLines={1}>
              {oi.quantity}x {oi.name}
            </Text>
            {!isAdmin && item.status === 'Delivered' && (
              <TouchableOpacity 
                style={styles.smallRateBtn}
                onPress={() => router.push(`/product/${oi.product}`)}
              >
                <Ionicons name="star-outline" size={12} color={colors.accent} />
                <Text style={[styles.smallRateText, { color: colors.accent }]}>Rate</Text>
              </TouchableOpacity>
            )}
          </View>
        ))}
      </View>

      <View style={[styles.orderFooter, { borderTopColor: colors.border }]}>
        <Text style={[styles.totalLabel, { color: colors.text }]}>Total Amount</Text>
        <Text style={[styles.totalValue, { color: colors.accent }]}>${(item.totalPrice || 0).toFixed(2)}</Text>
      </View>

      {isAdmin && (
        <View style={styles.adminActions}>
          <TouchableOpacity 
            style={[styles.actionBtn, { backgroundColor: '#007AFF20' }]}
            onPress={() => updateStatus(item._id, 'Shipped')}
          >
            <Text style={{ color: '#007AFF', fontWeight: 'bold', fontSize: 12 }}>Mark Shipped</Text>
          </TouchableOpacity>
          <TouchableOpacity 
            style={[styles.actionBtn, { backgroundColor: '#34C75920' }]}
            onPress={() => updateStatus(item._id, 'Delivered')}
          >
            <Text style={{ color: '#34C759', fontWeight: 'bold', fontSize: 12 }}>Mark Delivered</Text>
          </TouchableOpacity>
        </View>
      )}
    </TouchableOpacity>
  );

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: colors.background }]}>
      <FlatList
        data={orders}
        keyExtractor={item => item._id}
        renderItem={renderOrder}
        contentContainerStyle={styles.list}
        refreshing={isLoading}
        onRefresh={isAdmin ? fetchAllOrders : fetchMyOrders}
        ListEmptyComponent={
          <View style={styles.empty}>
            <Ionicons name="receipt-outline" size={80} color="#ccc" />
            <Text style={styles.emptyText}>No orders found</Text>
          </View>
        }
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  list: { padding: 20 },
  orderCard: { borderRadius: 20, padding: 20, marginBottom: 15, shadowColor: '#000', shadowOpacity: 0.05, shadowRadius: 10, elevation: 2 },
  orderHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 15 },
  orderId: { fontSize: 16, fontWeight: 'bold' },
  orderDate: { fontSize: 12, color: '#999', marginTop: 2 },
  statusBadge: { paddingHorizontal: 10, paddingVertical: 5, borderRadius: 8 },
  statusText: { fontSize: 12, fontWeight: 'bold' },
  orderItems: { marginBottom: 15 },
  itemLine: { fontSize: 14, opacity: 0.8 },
  itemRow: { flexDirection: 'row', alignItems: 'center', marginBottom: 6 },
  smallRateBtn: { flexDirection: 'row', alignItems: 'center', backgroundColor: '#FDF9F6', paddingHorizontal: 10, paddingVertical: 4, borderRadius: 6, borderWidth: 1, borderColor: '#D4AF3740' },
  smallRateText: { fontSize: 11, fontWeight: 'bold', marginLeft: 4 },
  orderFooter: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingTop: 15, borderTopWidth: 1 },
  totalLabel: { fontSize: 14, fontWeight: '500' },
  totalValue: { fontSize: 18, fontWeight: 'bold' },
  adminActions: { flexDirection: 'row', justifyContent: 'space-between', marginTop: 15 },
  actionBtn: { flex: 1, paddingVertical: 10, borderRadius: 10, alignItems: 'center', marginHorizontal: 5 },
  empty: { flex: 1, justifyContent: 'center', alignItems: 'center', marginTop: 100 },
  emptyText: { color: '#999', fontSize: 16, marginTop: 15 },
});
