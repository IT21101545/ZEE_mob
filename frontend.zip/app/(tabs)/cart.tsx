import React from 'react';
import { View, Text, FlatList, Image, TouchableOpacity, StyleSheet, ActivityIndicator, ScrollView, Dimensions } from 'react-native';
import { useCart, CartItem } from '../../context/CartContext';
import { MaterialIcons, Ionicons } from '@expo/vector-icons';
import { useRouter } from 'expo-router';
import { Colors } from '@/constants/theme';

const { width } = Dimensions.get('window');

export default function CartScreen() {
  const { cartItems, cartTotal, isLoading, updateCartItem, removeFromCart } = useCart();
  const router = useRouter();

  const deliveryFee = cartItems.length > 0 ? 5.00 : 0;
  const discount = 0;
  const finalTotal = cartTotal + deliveryFee - discount;

  if (isLoading && cartItems.length === 0) {
    return (
      <View style={styles.center}>
        <ActivityIndicator size="large" color={Colors.light.accent} />
      </View>
    );
  }

  if (cartItems.length === 0) {
    return (
      <View style={styles.center}>
        <Ionicons name="cart-outline" size={80} color="#ccc" />
        <Text style={styles.emptyText}>Your cart is empty</Text>
        <TouchableOpacity style={styles.shopButton} onPress={() => router.push('/(tabs)')}>
          <Text style={styles.shopButtonText}>Explore Products</Text>
        </TouchableOpacity>
      </View>
    );
  }

  const renderItem = ({ item }: { item: CartItem }) => {
    if (!item.product) return null; // Safety check
    
    return (
      <View style={styles.cartItem}>
        <Image source={{ uri: item.product.image || 'https://via.placeholder.com/100' }} style={styles.itemImage} />
        <View style={styles.itemDetails}>
          <Text style={styles.itemName} numberOfLines={1}>{item.product.name}</Text>
          <Text style={styles.itemCategory}>Designer Choice</Text>
          <View style={styles.priceRow}>
            <Text style={styles.itemPrice}>${item.product.price?.toFixed(2)}</Text>
          <View style={styles.quantityControl}>
            <TouchableOpacity 
              style={styles.qtyBtn} 
              onPress={() => updateCartItem(item.product._id, item.quantity - 1)}
            >
              <Ionicons name="remove" size={18} color="#2F2D2C" />
            </TouchableOpacity>
            <Text style={styles.qtyText}>{item.quantity}</Text>
            <TouchableOpacity 
              style={styles.qtyBtn} 
              onPress={() => updateCartItem(item.product._id, item.quantity + 1)}
            >
              <Ionicons name="add" size={18} color="#2F2D2C" />
            </TouchableOpacity>
          </View>
        </View>
      </View>
      <TouchableOpacity style={styles.deleteBtn} onPress={() => removeFromCart(item.product._id)}>
        <Ionicons name="trash-outline" size={20} color="#FF3B30" />
      </TouchableOpacity>
    </View>
  );
};

  return (
    <View style={styles.container}>
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingBottom: 120 }}>
        {/* Delivery Address Mock */}
        <View style={styles.addressCard}>
          <View style={styles.addressHeader}>
            <Text style={styles.addressTitle}>Delivery Address</Text>
            <TouchableOpacity>
              <Text style={styles.editBtn}>Edit</Text>
            </TouchableOpacity>
          </View>
          <View style={styles.addressInfo}>
            <View style={styles.addressIconBox}>
              <Ionicons name="location-outline" size={20} color={Colors.light.accent} />
            </View>
            <View style={{ flex: 1 }}>
              <Text style={styles.addressText} numberOfLines={1}>Jl. Kp Baru No. 1, Jakarta Selatan</Text>
              <Text style={styles.addressSub}>Default Address</Text>
            </View>
          </View>
        </View>

        <View style={styles.listContainer}>
          {cartItems.map((item, index) => (
            <View key={item.product?._id || index}>
              {renderItem({ item })}
            </View>
          ))}
        </View>

        {/* Payment Summary */}
        <View style={styles.summaryContainer}>
          <Text style={styles.summaryTitle}>Order Summary</Text>
          <View style={styles.summaryRow}>
            <Text style={styles.summaryLabel}>Price</Text>
            <Text style={styles.summaryValue}>${cartTotal.toFixed(2)}</Text>
          </View>
          <View style={styles.summaryRow}>
            <Text style={styles.summaryLabel}>Delivery Fee</Text>
            <Text style={styles.summaryValue}>${deliveryFee.toFixed(2)}</Text>
          </View>
          <View style={styles.summaryRow}>
            <Text style={styles.summaryLabel}>Discount</Text>
            <Text style={styles.summaryValue}>-${discount.toFixed(2)}</Text>
          </View>
          <View style={[styles.summaryRow, { marginTop: 10, paddingTop: 10, borderTopWidth: 1, borderTopColor: '#F0F0F0' }]}>
            <Text style={[styles.summaryLabel, { fontWeight: 'bold', color: '#2F2D2C' }]}>Total Payment</Text>
            <Text style={[styles.summaryValue, { fontWeight: 'bold', color: Colors.light.accent, fontSize: 18 }]}>${finalTotal.toFixed(2)}</Text>
          </View>
        </View>
      </ScrollView>

      {/* Bottom Bar */}
      <View style={styles.bottomBar}>
        <View style={styles.totalBox}>
          <Ionicons name="wallet-outline" size={24} color={Colors.light.accent} />
          <View style={{ marginLeft: 10 }}>
            <Text style={styles.cashLabel}>Cash Payment</Text>
            <Text style={styles.cashValue}>$ {finalTotal.toFixed(2)}</Text>
          </View>
          <Ionicons name="chevron-down" size={18} color="#999" style={{ marginLeft: 'auto' }} />
        </View>
        <TouchableOpacity style={styles.orderBtn} onPress={() => router.push('/checkout')}>
          <Text style={styles.orderBtnText}>Order Now</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#F9F9F9' },
  center: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  emptyText: { fontSize: 18, color: '#999', marginTop: 15, marginBottom: 25 },
  shopButton: { backgroundColor: Colors.light.accent, paddingHorizontal: 30, paddingVertical: 14, borderRadius: 20 },
  shopButtonText: { color: '#fff', fontSize: 16, fontWeight: 'bold' },
  addressCard: { backgroundColor: '#fff', padding: 20, margin: 20, borderRadius: 20, shadowColor: '#000', shadowOpacity: 0.03, shadowRadius: 10, elevation: 2 },
  addressHeader: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 15 },
  addressTitle: { fontSize: 16, fontWeight: 'bold', color: '#2F2D2C' },
  editBtn: { color: Colors.light.accent, fontWeight: '500' },
  addressInfo: { flexDirection: 'row', alignItems: 'center' },
  addressIconBox: { width: 40, height: 40, borderRadius: 12, backgroundColor: '#FDF5F0', justifyContent: 'center', alignItems: 'center', marginRight: 15 },
  addressText: { fontSize: 14, fontWeight: 'bold', color: '#2F2D2C' },
  addressSub: { fontSize: 12, color: '#999', marginTop: 2 },
  listContainer: { paddingHorizontal: 20 },
  cartItem: { flexDirection: 'row', backgroundColor: '#fff', borderRadius: 20, padding: 12, marginBottom: 15, alignItems: 'center' },
  itemImage: { width: 80, height: 80, borderRadius: 15, backgroundColor: '#F5F5F5' },
  itemDetails: { flex: 1, marginLeft: 15 },
  itemName: { fontSize: 16, fontWeight: 'bold', color: '#2F2D2C' },
  itemCategory: { fontSize: 12, color: '#999', marginTop: 2 },
  priceRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginTop: 10 },
  itemPrice: { fontSize: 16, fontWeight: 'bold', color: Colors.light.accent },
  quantityControl: { flexDirection: 'row', alignItems: 'center' },
  qtyBtn: { width: 28, height: 28, borderRadius: 14, borderWidth: 1, borderColor: '#EAEAEA', justifyContent: 'center', alignItems: 'center' },
  qtyText: { fontSize: 14, fontWeight: 'bold', marginHorizontal: 10, minWidth: 20, textAlign: 'center' },
  deleteBtn: { padding: 8 },
  summaryContainer: { backgroundColor: '#fff', margin: 20, padding: 20, borderRadius: 20 },
  summaryTitle: { fontSize: 16, fontWeight: 'bold', color: '#2F2D2C', marginBottom: 15 },
  summaryRow: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 8 },
  summaryLabel: { color: '#999', fontSize: 14 },
  summaryValue: { color: '#2F2D2C', fontSize: 14, fontWeight: '600' },
  bottomBar: { 
    position: 'absolute', 
    bottom: 0, 
    width: width, 
    backgroundColor: '#fff', 
    padding: 20, 
    paddingBottom: 35,
    borderTopLeftRadius: 30,
    borderTopRightRadius: 30,
    shadowColor: '#000',
    shadowOpacity: 0.1,
    shadowRadius: 15,
    elevation: 10
  },
  totalBox: { flexDirection: 'row', alignItems: 'center', backgroundColor: '#F9F9F9', padding: 12, borderRadius: 15, marginBottom: 15 },
  cashLabel: { fontSize: 12, color: '#999' },
  cashValue: { fontSize: 14, fontWeight: 'bold', color: '#2F2D2C' },
  orderBtn: {
    backgroundColor: Colors.light.accent,
    padding: 18,
    borderRadius: 20,
    alignItems: 'center'
  },
  orderBtnText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: 'bold'
  },
});

