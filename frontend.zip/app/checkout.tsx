import React, { useState } from 'react';
import { 
  View, 
  Text, 
  TextInput, 
  TouchableOpacity, 
  StyleSheet, 
  ScrollView, 
  Alert, 
  ActivityIndicator,
  SafeAreaView
} from 'react-native';
import { useRouter } from 'expo-router';
import { useCart } from '../context/CartContext';
import { useOrders } from '../context/OrderContext';
import { useAppTheme } from '../context/ThemeContext';
import { Colors } from '@/constants/theme';
import { Ionicons } from '@expo/vector-icons';

export default function CheckoutScreen() {
  const { cartItems, cartTotal, clearCart } = useCart();
  const { createOrder } = useOrders();
  const { theme, isDark } = useAppTheme();
  const router = useRouter();
  const colors = Colors[theme];

  const [address, setAddress] = useState('');
  const [paymentMethod, setPaymentMethod] = useState<'Card' | 'COD'>('COD');
  const [cardNumber, setCardNumber] = useState('');
  const [expiry, setExpiry] = useState('');
  const [cvv, setCvv] = useState('');
  const [loading, setLoading] = useState(false);

  const deliveryFee = 5.00;
  const totalPrice = cartTotal + deliveryFee;

  const handlePlaceOrder = async () => {
    if (!address) {
      Alert.alert('Error', 'Please enter your delivery address');
      return;
    }

    if (paymentMethod === 'Card') {
      if (!cardNumber || !expiry || !cvv) {
        Alert.alert('Error', 'Please fill in your card details');
        return;
      }
    }

    setLoading(true);
    try {
      const orderData = {
        orderItems: cartItems
          .filter(item => item.product != null)
          .map(item => ({
            name: item.product.name,
            quantity: item.quantity,
            image: item.product.image || 'https://via.placeholder.com/150',
            price: item.product.price,
            product: item.product._id,
          })),
        shippingAddress: { address, city: 'N/A', postalCode: 'N/A' },
        paymentMethod: paymentMethod === 'Card' ? 'Credit Card' : 'Cash on Delivery',
        itemsPrice: cartTotal,
        shippingPrice: deliveryFee,
        totalPrice: totalPrice,
      };

      await createOrder(orderData);
      clearCart();
      Alert.alert('Success', 'Order placed successfully!', [
        { text: 'View Orders', onPress: () => router.push('/(tabs)/orders') },
        { text: 'Continue Shopping', onPress: () => router.push('/(tabs)') }
      ]);
    } catch (error: any) {
      Alert.alert('Error', error.response?.data?.message || 'Failed to place order');
    } finally {
      setLoading(false);
    }
  };

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: '#F9F9F9' }]}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => router.back()} style={styles.backBtn}>
          <Ionicons name="arrow-back" size={24} color="#000" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>checkout</Text>
      </View>

      <ScrollView contentContainerStyle={styles.content}>
        <Text style={styles.mainTitle}>Checkout</Text>

        {/* Order Summary */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Order Summary</Text>
          {cartItems.map((item, idx) => (
            <View key={idx} style={styles.summaryRow}>
              <Text style={styles.itemText}>{item.quantity}x {item.product?.name || 'Unavailable Product'}</Text>
              <Text style={styles.itemPrice}>${((item.product?.price || 0) * item.quantity).toFixed(2)}</Text>
            </View>
          ))}
          <View style={styles.divider} />
          <View style={styles.totalRow}>
            <Text style={styles.totalLabel}>Total</Text>
            <Text style={styles.totalValue}>${totalPrice.toFixed(2)}</Text>
          </View>
        </View>

        {/* Delivery Address */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Delivery Address</Text>
          <TextInput
            style={styles.textArea}
            placeholder="Enter full shipping address..."
            multiline
            numberOfLines={4}
            value={address}
            onChangeText={setAddress}
          />
        </View>

        {/* Payment Method */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Payment Method</Text>
          
          {/* Credit Card Option */}
          <TouchableOpacity 
            style={[styles.paymentOption, paymentMethod === 'Card' && styles.paymentOptionSelected]}
            onPress={() => setPaymentMethod('Card')}
          >
            <Ionicons name="card-outline" size={24} color={paymentMethod === 'Card' ? '#D4AF37' : '#666'} />
            <Text style={[styles.paymentOptionText, paymentMethod === 'Card' && { color: '#D4AF37', fontWeight: 'bold' }]}>Credit Card</Text>
            {paymentMethod === 'Card' && <Ionicons name="checkmark-circle" size={22} color="#D4AF37" style={{ marginLeft: 'auto' }} />}
          </TouchableOpacity>

          {paymentMethod === 'Card' && (
            <View style={styles.professionalCardContainer}>
              <View style={styles.cardHeader}>
                <Ionicons name="logo-bitcoin" size={24} color="#D4AF37" />
                <Ionicons name="wifi" size={24} color="#666" style={{ transform: [{ rotate: '90deg' }] }} />
              </View>
              <View style={styles.inputWithIcon}>
                <Ionicons name="card-outline" size={20} color="#999" style={styles.inputIcon} />
                <TextInput
                  style={styles.proInput}
                  placeholder="Card Number"
                  placeholderTextColor="#999"
                  value={cardNumber}
                  onChangeText={setCardNumber}
                  keyboardType="numeric"
                  maxLength={19}
                />
              </View>
              <View style={styles.row}>
                <View style={[styles.inputWithIcon, { flex: 1, marginRight: 15 }]}>
                  <Ionicons name="calendar-outline" size={20} color="#999" style={styles.inputIcon} />
                  <TextInput
                    style={styles.proInput}
                    placeholder="MM/YY"
                    placeholderTextColor="#999"
                    value={expiry}
                    onChangeText={setExpiry}
                    maxLength={5}
                  />
                </View>
                <View style={[styles.inputWithIcon, { flex: 1 }]}>
                  <Ionicons name="lock-closed-outline" size={20} color="#999" style={styles.inputIcon} />
                  <TextInput
                    style={styles.proInput}
                    placeholder="CVV"
                    placeholderTextColor="#999"
                    value={cvv}
                    onChangeText={setCvv}
                    keyboardType="numeric"
                    secureTextEntry
                    maxLength={4}
                  />
                </View>
              </View>
            </View>
          )}

          {/* COD Option */}
          <TouchableOpacity 
            style={[styles.paymentOption, paymentMethod === 'COD' && { borderColor: '#D4AF37', backgroundColor: '#FDFBF7' }]}
            onPress={() => setPaymentMethod('COD')}
          >
            <Ionicons name="cash-outline" size={24} color={paymentMethod === 'COD' ? '#D4AF37' : '#666'} />
            <Text style={[styles.paymentOptionText, paymentMethod === 'COD' && { color: '#D4AF37', fontWeight: 'bold' }]}>Cash on Delivery</Text>
            {paymentMethod === 'COD' && <Ionicons name="checkmark-circle" size={22} color="#D4AF37" style={{ marginLeft: 'auto' }} />}
          </TouchableOpacity>
        </View>
      </ScrollView>

      <View style={styles.footer}>
        <TouchableOpacity 
          style={styles.confirmBtn} 
          onPress={handlePlaceOrder}
          disabled={loading}
        >
          {loading ? <ActivityIndicator color="#fff" /> : <Text style={styles.confirmBtnText}>Confirm Payment & Place Order</Text>}
        </TouchableOpacity>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: { flexDirection: 'row', alignItems: 'center', padding: 20 },
  backBtn: { padding: 5 },
  headerTitle: { fontSize: 18, fontWeight: '500', marginLeft: 20, color: '#000' },
  content: { padding: 20 },
  mainTitle: { fontSize: 28, fontWeight: 'bold', color: '#333', marginBottom: 25 },
  section: { backgroundColor: '#fff', borderRadius: 15, padding: 20, marginBottom: 20, borderWidth: 1, borderColor: '#EBEBEB' },
  sectionTitle: { fontSize: 18, fontWeight: 'bold', marginBottom: 15, color: '#333' },
  summaryRow: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 10 },
  itemText: { fontSize: 16, color: '#666' },
  itemPrice: { fontSize: 16, fontWeight: '500', color: '#333' },
  divider: { height: 1, backgroundColor: '#EEE', marginVertical: 15 },
  totalRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  totalLabel: { fontSize: 18, fontWeight: 'bold', color: '#333' },
  totalValue: { fontSize: 20, fontWeight: 'bold', color: '#D4AF37' },
  textArea: { borderWidth: 1, borderColor: '#EBEBEB', borderRadius: 15, padding: 15, fontSize: 16, height: 100, textAlignVertical: 'top', backgroundColor: '#FDFDFD' },
  paymentOption: { 
    flexDirection: 'row', 
    alignItems: 'center', 
    padding: 18, 
    borderWidth: 1, 
    borderColor: '#EBEBEB', 
    borderRadius: 15, 
    marginBottom: 12 
  },
  paymentOptionText: { fontSize: 16, marginLeft: 15, color: '#666' },
  professionalCardContainer: { padding: 20, backgroundColor: '#FAFAFA', borderRadius: 20, borderWidth: 1, borderColor: '#EEE', marginBottom: 15 },
  cardHeader: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 20 },
  inputWithIcon: { flexDirection: 'row', alignItems: 'center', backgroundColor: '#FFF', borderWidth: 1, borderColor: '#EBEBEB', borderRadius: 12, paddingHorizontal: 15, marginBottom: 15, height: 55, shadowColor: '#000', shadowOpacity: 0.02, shadowRadius: 5, elevation: 1 },
  inputIcon: { marginRight: 10 },
  proInput: { flex: 1, fontSize: 16, color: '#333' },
  row: { flexDirection: 'row' },
  footer: { padding: 20, paddingBottom: 35 },
  confirmBtn: { backgroundColor: '#D4AF37', height: 60, borderRadius: 15, justifyContent: 'center', alignItems: 'center', shadowColor: '#D4AF37', shadowOpacity: 0.4, shadowRadius: 10, elevation: 5 },
  confirmBtnText: { color: '#fff', fontSize: 18, fontWeight: 'bold', letterSpacing: 1 },
});
