import React, { createContext, useState, useEffect, useContext } from 'react';
import * as SecureStore from 'expo-secure-store';
import api from '../api/axios';

import { Platform } from 'react-native';

interface User {
  _id: string;
  name: string;
  email: string;
  phone?: string;
  role: string;
  avatar?: string;
}

interface AuthContextData {
  user: User | null;
  isLoading: boolean;
  login: (email: string, password: string) => Promise<void>;
  register: (name: string, email: string, password: string, role?: string) => Promise<void>;
  requestOtp: (email: string) => Promise<void>;
  verifyOtpAndReset: (email: string, otp: string, newPassword: string) => Promise<void>;
  updateProfile: (formData: FormData) => Promise<void>;
  logout: () => Promise<void>;
}

// Platform-aware storage wrapper
const setToken = async (token: string) => {
  if (Platform.OS === 'web') {
    localStorage.setItem('userToken', token);
  } else {
    await SecureStore.setItemAsync('userToken', token);
  }
};

const getToken = async () => {
  if (Platform.OS === 'web') {
    return localStorage.getItem('userToken');
  } else {
    return await SecureStore.getItemAsync('userToken');
  }
};

const deleteToken = async () => {
  if (Platform.OS === 'web') {
    localStorage.removeItem('userToken');
  } else {
    await SecureStore.deleteItemAsync('userToken');
  }
};

const AuthContext = createContext<AuthContextData>({} as AuthContextData);

export const AuthProvider = ({ children }: { children: React.ReactNode }) => {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Check if user is logged in
    const loadUser = async () => {
      try {
        const token = await getToken();
        if (token) {
          // Verify token and fetch user profile
          const res = await api.get('/auth/profile');
          setUser(res.data);
        }
      } catch (error) {
        console.error('Failed to load user', error);
        await deleteToken();
      } finally {
        setIsLoading(false);
      }
    };

    loadUser();
  }, []);

  const login = async (email: string, password: string) => {
    try {
      const res = await api.post('/auth/login', { email, password });
      const { token, ...userData } = res.data;
      await setToken(token);
      setUser(userData);
    } catch (error) {
      throw error;
    }
  };

  const register = async (name: string, email: string, password: string, role?: string) => {
    try {
      const payload: any = { name, email, password };
      if (role) payload.role = role;
      const res = await api.post('/auth/register', payload);
      const { token, ...userData } = res.data;
      await setToken(token);
      setUser(userData);
    } catch (error) {
      throw error;
    }
  };

  const requestOtp = async (email: string) => {
    try {
      await api.post('/auth/request-otp', { email });
    } catch (error) {
      throw error;
    }
  };

  const verifyOtpAndReset = async (email: string, otp: string, newPassword: string) => {
    try {
      await api.post('/auth/verify-otp', { email, otp, newPassword });
    } catch (error) {
      throw error;
    }
  };

  const updateProfile = async (data: FormData | any) => {
    try {
      const isFormData = data instanceof FormData;
      const res = await api.put('/auth/profile', data, {
        headers: isFormData ? undefined : { 'Content-Type': 'application/json' }
      });
      setUser(res.data);
    } catch (error) {
      throw error;
    }
  };

  const logout = async () => {
    await deleteToken();
    setUser(null);
  };

  return (
    <AuthContext.Provider value={{ user, isLoading, login, register, requestOtp, verifyOtpAndReset, updateProfile, logout }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => useContext(AuthContext);
