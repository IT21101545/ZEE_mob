import React, { createContext, useState, useEffect, useContext, useCallback } from 'react';
import api from '../api/axios';

export interface Product {
  _id: string;
  name: string;
  description: string;
  price: number;
  salePrice?: number;
  discountPercentage?: number;
  category: string;
  stock: number;
  image: string;
  images?: Array<{ url: string; publicId: string }>;
  averageRating: number;
  totalReviews: number;
  sizes?: string[];
  colors?: string[];
  brand?: string;
  sku?: string;
  isFeatured?: boolean;
  isActive?: boolean;
}

interface PaginationData {
  total: number;
  page: number;
  limit: number;
  pages: number;
}

interface ProductContextData {
  products: Product[];
  featuredProducts: Product[];
  trendingProducts: Product[];
  categories: string[];
  isLoading: boolean;
  error: string | null;
  pagination: PaginationData | null;
  
  // Fetch methods
  fetchProducts: (filters?: ProductFilters) => Promise<void>;
  fetchFeaturedProducts: () => Promise<void>;
  fetchTrendingProducts: () => Promise<void>;
  getProduct: (id: string) => Promise<Product | null>;
  getCategories: () => Promise<void>;
  
  // Admin methods
  addProduct: (formData: FormData) => Promise<void>;
  updateProduct: (id: string, formData: FormData) => Promise<void>;
  deleteProduct: (id: string) => Promise<void>;
  
  // Utility methods
  clearError: () => void;
  searchProducts: (query: string) => Promise<void>;
}

export interface ProductFilters {
  category?: string;
  search?: string;
  page?: number;
  limit?: number;
  sortBy?: 'createdAt' | 'price' | 'averageRating' | 'name';
  sortOrder?: 'asc' | 'desc';
  minPrice?: number;
  maxPrice?: number;
  minRating?: number;
  featured?: boolean;
}

const ProductContext = createContext<ProductContextData>({} as ProductContextData);

export const ProductProvider = ({ children }: { children: React.ReactNode }) => {
  const [products, setProducts] = useState<Product[]>([]);
  const [featuredProducts, setFeaturedProducts] = useState<Product[]>([]);
  const [trendingProducts, setTrendingProducts] = useState<Product[]>([]);
  const [categories, setCategories] = useState<string[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [pagination, setPagination] = useState<PaginationData | null>(null);

  const clearError = useCallback(() => setError(null), []);

  const fetchProducts = useCallback(async (filters?: ProductFilters) => {
    setIsLoading(true);
    setError(null);
    try {
      const params = new URLSearchParams();
      
      if (filters?.category) params.append('category', filters.category);
      if (filters?.search) params.append('search', filters.search);
      if (filters?.page) params.append('page', filters.page.toString());
      if (filters?.limit) params.append('limit', filters.limit.toString());
      if (filters?.sortBy) params.append('sortBy', filters.sortBy);
      if (filters?.sortOrder) params.append('sortOrder', filters.sortOrder);
      if (filters?.minPrice) params.append('minPrice', filters.minPrice.toString());
      if (filters?.maxPrice) params.append('maxPrice', filters.maxPrice.toString());
      if (filters?.minRating) params.append('minRating', filters.minRating.toString());
      if (filters?.featured) params.append('featured', 'true');

      const res = await api.get(`/products?${params.toString()}`);
      
      if (res.data.success) {
        setProducts(res.data.data);
        setPagination(res.data.pagination);
      } else {
        setError('Failed to fetch products');
      }
    } catch (err: any) {
      const errorMessage = err.response?.data?.message || err.message || 'Failed to fetch products';
      setError(errorMessage);
      console.error('Error fetching products:', err);
    } finally {
      setIsLoading(false);
    }
  }, []);

  const fetchFeaturedProducts = useCallback(async () => {
    try {
      const res = await api.get('/products/featured?limit=10');
      if (res.data.success) {
        setFeaturedProducts(res.data.data);
      }
    } catch (err) {
      console.error('Error fetching featured products:', err);
    }
  }, []);

  const fetchTrendingProducts = useCallback(async () => {
    try {
      const res = await api.get('/products/trending?limit=10');
      if (res.data.success) {
        setTrendingProducts(res.data.data);
      }
    } catch (err) {
      console.error('Error fetching trending products:', err);
    }
  }, []);

  const getProduct = useCallback(async (id: string): Promise<Product | null> => {
    try {
      const res = await api.get(`/products/${id}`);
      if (res.data.success) {
        return res.data.data;
      }
      return null;
    } catch (err) {
      console.error('Error fetching product:', err);
      return null;
    }
  }, []);

  const getCategories = useCallback(async () => {
    try {
      const res = await api.get('/products/categories');
      if (res.data.success) {
        setCategories(res.data.data);
      }
    } catch (err) {
      console.error('Error fetching categories:', err);
    }
  }, []);

  const addProduct = useCallback(async (formData: FormData) => {
    setIsLoading(true);
    setError(null);
    try {
      const res = await api.post('/products', formData, {
        headers: {
          'Content-Type': 'multipart/form-data',
        },
      });
      
      if (res.data.success) {
        await fetchProducts();
      } else {
        setError(res.data.message || 'Failed to add product');
      }
    } catch (err: any) {
      const errorMessage = err.response?.data?.message || err.message || 'Failed to add product';
      setError(errorMessage);
      throw err;
    } finally {
      setIsLoading(false);
    }
  }, [fetchProducts]);

  const updateProduct = useCallback(async (id: string, formData: FormData) => {
    setIsLoading(true);
    setError(null);
    try {
      const res = await api.put(`/products/${id}`, formData, {
        headers: {
          'Content-Type': 'multipart/form-data',
        },
      });
      
      if (res.data.success) {
        await fetchProducts();
      } else {
        setError(res.data.message || 'Failed to update product');
      }
    } catch (err: any) {
      const errorMessage = err.response?.data?.message || err.message || 'Failed to update product';
      setError(errorMessage);
      throw err;
    } finally {
      setIsLoading(false);
    }
  }, [fetchProducts]);

  const deleteProduct = useCallback(async (id: string) => {
    setIsLoading(true);
    setError(null);
    try {
      const res = await api.delete(`/products/${id}`);
      
      if (res.data.success) {
        await fetchProducts();
      } else {
        setError(res.data.message || 'Failed to delete product');
      }
    } catch (err: any) {
      const errorMessage = err.response?.data?.message || err.message || 'Failed to delete product';
      setError(errorMessage);
      throw err;
    } finally {
      setIsLoading(false);
    }
  }, [fetchProducts]);

  const searchProducts = useCallback(async (query: string) => {
    await fetchProducts({ search: query, page: 1 });
  }, [fetchProducts]);

  // Initial load
  useEffect(() => {
    fetchProducts({ limit: 10, page: 1 });
    getCategories();
    fetchFeaturedProducts();
    fetchTrendingProducts();
  }, []);

  const value: ProductContextData = {
    products,
    featuredProducts,
    trendingProducts,
    categories,
    isLoading,
    error,
    pagination,
    fetchProducts,
    fetchFeaturedProducts,
    fetchTrendingProducts,
    getProduct,
    getCategories,
    addProduct,
    updateProduct,
    deleteProduct,
    clearError,
    searchProducts,
  };

  return (
    <ProductContext.Provider value={value}>
      {children}
    </ProductContext.Provider>
  );
};

export const useProducts = () => {
  const context = useContext(ProductContext);
  if (!context) {
    throw new Error('useProducts must be used within ProductProvider');
  }
  return context;
};
