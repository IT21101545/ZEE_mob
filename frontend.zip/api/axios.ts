import axios from 'axios';
import * as SecureStore from 'expo-secure-store';
import { Platform } from 'react-native';

// Auto-detect the correct base URL for each platform
const getBaseUrl = () => {
  if (Platform.OS === 'web') {
    return 'http://192.168.1.3:5000/api';
  }
  // For physical devices and emulators, use your LAN IP
  return 'http://192.168.1.3:5000/api';
};

const api = axios.create({
  baseURL: getBaseUrl(),
  timeout: 20000, // 20 seconds timeout
  headers: {
    'Content-Type': 'application/json',
  },
});

// Interceptor to add the auth token to all requests
api.interceptors.request.use(
  async (config) => {
    let token = null;
    if (Platform.OS === 'web') {
      token = typeof localStorage !== 'undefined' ? localStorage.getItem('userToken') : null;
    } else {
      token = await SecureStore.getItemAsync('userToken');
    }

    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => Promise.reject(error)
);

export default api;