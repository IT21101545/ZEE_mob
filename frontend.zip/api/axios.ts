import axios from 'axios';
import * as SecureStore from 'expo-secure-store';
import Constants from 'expo-constants';
import { Platform } from 'react-native';

function mapLocalhostForAndroid(url: string): string {
  if (Platform.OS !== 'android') return url;
  // Android emulator reaches the dev machine via 10.0.2.2, not localhost
  return url.replace('://localhost', '://10.0.2.2').replace('://127.0.0.1', '://10.0.2.2');
}

/** Reject tutorial placeholders so the app falls back to Expo’s real dev host. */
function isInvalidApiBaseUrl(url: string): boolean {
  const raw = url.trim().toLowerCase();
  if (!raw) return true;
  if (raw.includes('your_pc_lan_ip')) return true;
  if (raw.includes('your-ip')) return true;
  if (raw.includes('<') && raw.includes('>')) return true;
  if (/\bxxx\.xxx\b/.test(raw) || raw.includes('xxx:')) return true;
  try {
    const withProto = /^https?:\/\//i.test(url) ? url : `http://${url}`;
    const host = new URL(withProto.replace(/\/$/, '')).hostname.toLowerCase();
    if (!host || host.length < 2) return true;
    if (host === 'your_pc_lan_ip' || host.includes('your_pc')) return true;
    if (host === 'example.com' || host.endsWith('.invalid')) return true;
  } catch {
    return true;
  }
  return false;
}

/**
 * API base URL resolution order:
 * 1. EXPO_PUBLIC_API_URL (must be a real IP/hostname, e.g. http://192.168.1.5:5000/api)
 * 2. LAN IP from Expo dev host (works with Expo Go on the same Wi‑Fi)
 * 3. localhost (simulators / web; localhost is remapped on Android emulator)
 */
function getBaseUrl(): string {
  const fromEnv = process.env.EXPO_PUBLIC_API_URL;
  if (fromEnv && String(fromEnv).trim()) {
    const trimmed = fromEnv.replace(/\/$/, '');
    if (!isInvalidApiBaseUrl(trimmed)) {
      return mapLocalhostForAndroid(trimmed);
    }
    if (__DEV__) {
      // eslint-disable-next-line no-console
      console.warn(
        '[api] EXPO_PUBLIC_API_URL looks like a placeholder or is invalid — ignoring. Set it to http://YOUR_REAL_IP:5000/api (see backend console when you npm start the server).'
      );
    }
  }

  const hostUri = Constants.expoConfig?.hostUri;
  const debuggerHost = hostUri?.split(':')[0];
  if (debuggerHost && debuggerHost !== 'localhost') {
    return `http://${debuggerHost}:5000/api`;
  }

  return mapLocalhostForAndroid('http://localhost:5000/api');
}

const api = axios.create({
  baseURL: getBaseUrl(),
  headers: {
    'Content-Type': 'application/json',
  },
});

api.interceptors.request.use(
  async (config) => {
    const token = await SecureStore.getItemAsync('userToken');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => Promise.reject(error)
);

export default api;
