import React, { useEffect, useState } from 'react';
import {
  Image,
  ImageResizeMode,
  StyleProp,
  StyleSheet,
  View,
  ImageStyle,
  ViewStyle,
} from 'react-native';
import { MaterialIcons } from '@expo/vector-icons';

type Props = {
  uri?: string | null;
  style?: StyleProp<ImageStyle>;
  /** Applied to the fallback box so layout matches the image frame */
  placeholderStyle?: StyleProp<ViewStyle>;
  resizeMode?: ImageResizeMode;
  onLoadEnd?: () => void;
};

/** Loads a remote image; on missing URL or load error shows an offline-safe placeholder (no external URLs). */
export function RemoteImage({ uri, style, placeholderStyle, resizeMode = 'cover', onLoadEnd }: Props) {
  const clean = uri?.trim() ?? '';
  const [failed, setFailed] = useState(!clean);

  useEffect(() => {
    if (!clean) onLoadEnd?.();
  }, [clean, onLoadEnd]);

  if (failed) {
    return (
      <View style={[styles.placeholder, style as StyleProp<ViewStyle>, placeholderStyle]}>
        <MaterialIcons name="hide-image" size={32} color="#999" />
      </View>
    );
  }

  return (
    <Image
      style={style}
      resizeMode={resizeMode}
      source={{ uri: clean }}
      onError={() => {
        setFailed(true);
        onLoadEnd?.();
      }}
      onLoadEnd={() => onLoadEnd?.()}
    />
  );
}

const styles = StyleSheet.create({
  placeholder: {
    backgroundColor: '#e8eaed',
    alignItems: 'center',
    justifyContent: 'center',
  },
});
