import { type ReactNode } from 'react';
import { Linking, Platform, Pressable, StyleSheet, Text, type PressableProps } from 'react-native';
import * as WebBrowser from 'expo-web-browser';
import { WebBrowserPresentationStyle } from 'expo-web-browser';

type Props = Omit<PressableProps, 'onPress'> & {
  href: string;
  children?: ReactNode;
};

/**
 * Opens http(s) links in the system browser / in-app browser.
 * Does not use expo-router `Link` for external URLs (that breaks many devices).
 */
export function ExternalLink({ href, children, style, ...rest }: Props) {
  const open = async () => {
    const url = href.trim();
    if (!url) return;

    const openSystem = () => Linking.openURL(url).catch(() => {});

    try {
      if (Platform.OS === 'web') {
        await openSystem();
        return;
      }
      await WebBrowser.openBrowserAsync(url, {
        presentationStyle: WebBrowserPresentationStyle.FULL_SCREEN,
        enableBarCollapsing: true,
      });
    } catch {
      await openSystem();
    }
  };

  return (
    <Pressable
      accessibilityRole="link"
      onPress={open}
      style={({ pressed }) => [pressed && styles.pressed, style]}
      {...rest}
    >
      {typeof children === 'string' ? <Text style={styles.linkText}>{children}</Text> : children}
    </Pressable>
  );
}

const styles = StyleSheet.create({
  linkText: {
    color: '#0a7ea4',
    textDecorationLine: 'underline',
  },
  pressed: {
    opacity: 0.7,
  },
});
