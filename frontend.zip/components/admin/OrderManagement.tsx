import React, { useEffect, useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, ActivityIndicator, Alert, FlatList, ScrollView, Modal } from 'react-native';
import { MaterialIcons } from '@expo/vector-icons';
import api from '../../api/axios';

interface OrderItem {
  product: string;
  name: string;
  price: number;
  quantity: number;
}

interface Order {
  _id: string;
  user: { name: string; email: string };
  totalAmount: number;
  status: string;
  address: string;
  items: OrderItem[];
  attachment?: string;
  createdAt: string;
}

const STATUS_OPTIONS = ['Pending', 'Processing', 'Shipped', 'Delivered', 'Cancelled'];

export default function OrderManagement() {
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);

  const fetchOrders = async () => {
    try {
      const res = await api.get('/orders');
      setOrders(res.data);
    } catch (error) {
      Alert.alert('Error', 'Failed to fetch orders');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchOrders();
  }, []);

  const updateStatus = async (orderId: string, status: string) => {
    try {
      await api.put(`/orders/${orderId}/status`, { status });
      fetchOrders();
      setSelectedOrder(null);
      Alert.alert('Success', `Order status updated to ${status}`);
    } catch (error: any) {
      Alert.alert('Error', error.response?.data?.message || 'Failed to update status');
    }
  };

  if (loading) return <ActivityIndicator size="large" color="#007AFF" style={{ marginTop: 50 }} />;

  return (
    <View style={styles.container}>
      <FlatList
        data={orders}
        keyExtractor={(item) => item._id}
        renderItem={({ item }) => (
          <TouchableOpacity style={styles.card} onPress={() => setSelectedOrder(item)}>
            <View style={styles.cardHeader}>
              <Text style={styles.orderId}>#{item._id.slice(-6).toUpperCase()}</Text>
              <Text style={[styles.statusBadge, styles[`status${item.status}` as keyof typeof styles] || styles.statusPending]}>
                {item.status}
              </Text>
            </View>
            <Text style={styles.userName}>{item.user?.name || 'Unknown User'} ({item.user?.email})</Text>
            <Text style={styles.date}>{new Date(item.createdAt).toLocaleDateString()}</Text>
            <Text style={styles.total}>Total: ${item.totalAmount.toFixed(2)}</Text>
            {item.attachment ? (
               <View style={styles.attachmentBadge}><MaterialIcons name="attach-file" size={14} color="#007AFF" /><Text style={styles.attachmentText}>Has Attachment</Text></View>
            ) : null}
          </TouchableOpacity>
        )}
      />

      <Modal visible={!!selectedOrder} animationType="slide" transparent>
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>Order Details</Text>
              <TouchableOpacity onPress={() => setSelectedOrder(null)}><MaterialIcons name="close" size={24} color="#333" /></TouchableOpacity>
            </View>
            
            {selectedOrder && (
              <ScrollView>
                <Text style={styles.detailLabel}>Order ID:</Text>
                <Text style={styles.detailValue}>{selectedOrder._id}</Text>
                
                <Text style={styles.detailLabel}>Customer:</Text>
                <Text style={styles.detailValue}>{selectedOrder.user?.name} ({selectedOrder.user?.email})</Text>
                
                <Text style={styles.detailLabel}>Address:</Text>
                <Text style={styles.detailValue}>{selectedOrder.address}</Text>

                <Text style={styles.detailLabel}>Items:</Text>
                {selectedOrder.items.map((item, idx) => (
                  <View key={idx} style={styles.itemRow}>
                    <Text style={styles.itemName}>{item.quantity}x {item.name}</Text>
                    <Text style={styles.itemPrice}>${(item.price * item.quantity).toFixed(2)}</Text>
                  </View>
                ))}
                
                <Text style={[styles.detailLabel, { marginTop: 15 }]}>Update Status:</Text>
                <View style={styles.statusButtons}>
                  {STATUS_OPTIONS.map(status => (
                    <TouchableOpacity 
                      key={status} 
                      style={[styles.statusBtn, selectedOrder.status === status && styles.statusBtnActive]}
                      onPress={() => updateStatus(selectedOrder._id, status)}
                    >
                      <Text style={[styles.statusBtnText, selectedOrder.status === status && styles.statusBtnTextActive]}>{status}</Text>
                    </TouchableOpacity>
                  ))}
                </View>
              </ScrollView>
            )}
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, paddingBottom: 20 },
  card: { backgroundColor: '#fff', padding: 15, borderRadius: 10, marginBottom: 15, elevation: 2, shadowColor: '#000', shadowOpacity: 0.1, shadowRadius: 4, shadowOffset: { width: 0, height: 2 }, marginHorizontal: 5 },
  cardHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 10 },
  orderId: { fontSize: 16, fontWeight: 'bold', color: '#333' },
  statusBadge: { fontSize: 12, fontWeight: 'bold', paddingHorizontal: 10, paddingVertical: 4, borderRadius: 12, overflow: 'hidden' },
  statusPending: { backgroundColor: '#fff3cd', color: '#856404' },
  statusProcessing: { backgroundColor: '#cce5ff', color: '#004085' },
  statusShipped: { backgroundColor: '#d1ecf1', color: '#0c5460' },
  statusDelivered: { backgroundColor: '#d4edda', color: '#155724' },
  statusCancelled: { backgroundColor: '#f8d7da', color: '#721c24' },
  userName: { fontSize: 15, color: '#444', marginBottom: 4 },
  date: { fontSize: 13, color: '#888', marginBottom: 8 },
  total: { fontSize: 16, fontWeight: 'bold', color: '#007AFF' },
  attachmentBadge: { flexDirection: 'row', alignItems: 'center', backgroundColor: '#e6f2ff', paddingHorizontal: 8, paddingVertical: 4, borderRadius: 10, alignSelf: 'flex-start', marginTop: 10 },
  attachmentText: { color: '#007AFF', fontSize: 12, marginLeft: 4, fontWeight: '600' },
  
  // Modal
  modalOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'flex-end' },
  modalContent: { backgroundColor: '#fff', borderTopLeftRadius: 20, borderTopRightRadius: 20, padding: 20, maxHeight: '80%' },
  modalHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20, paddingBottom: 15, borderBottomWidth: 1, borderBottomColor: '#eee' },
  modalTitle: { fontSize: 20, fontWeight: 'bold', color: '#333' },
  detailLabel: { fontSize: 14, color: '#888', marginBottom: 4 },
  detailValue: { fontSize: 16, color: '#333', marginBottom: 15, fontWeight: '500' },
  itemRow: { flexDirection: 'row', justifyContent: 'space-between', paddingVertical: 8, borderBottomWidth: 1, borderBottomColor: '#f4f4f4' },
  itemName: { fontSize: 15, color: '#555', flex: 1 },
  itemPrice: { fontSize: 15, fontWeight: 'bold', color: '#333' },
  statusButtons: { flexDirection: 'row', flexWrap: 'wrap', gap: 10, marginTop: 10 },
  statusBtn: { paddingHorizontal: 15, paddingVertical: 8, borderRadius: 20, borderWidth: 1, borderColor: '#ddd', backgroundColor: '#f9f9f9' },
  statusBtnActive: { backgroundColor: '#007AFF', borderColor: '#007AFF' },
  statusBtnText: { color: '#666', fontWeight: 'bold' },
  statusBtnTextActive: { color: '#fff' }
});
