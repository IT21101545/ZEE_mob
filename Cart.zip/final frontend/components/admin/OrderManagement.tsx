import React, { useEffect, useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, ActivityIndicator, Alert, FlatList, ScrollView, Modal } from 'react-native';
import { MaterialIcons } from '@expo/vector-icons';
import api from '../../api/axios';

interface OrderItem {
  product: string;
  name: string;
  price: number;
  quantity: number;
}

interface Order {
  _id: string;
  user: { name: string; email: string };
  totalPrice: number;
  status: string;
  shippingAddress: { address: string; city: string };
  orderItems: OrderItem[];
  paymentMethod: string;
  createdAt: string;
}

const STATUS_OPTIONS = ['Pending', 'Processing', 'Shipped', 'Delivered', 'Cancelled'];

export default function OrderManagement() {
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);

  const fetchOrders = async () => {
    try {
      const res = await api.get('/orders');
      setOrders(res.data);
    } catch (error) {
      Alert.alert('Error', 'Failed to fetch orders');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchOrders();
  }, []);

  const updateStatus = async (orderId: string, status: string) => {
    try {
      await api.put(`/orders/${orderId}/status`, { status });
      fetchOrders();
      setSelectedOrder(null);
      Alert.alert('Success', `Order status updated to ${status}`);
    } catch (error: any) {
      Alert.alert('Error', error.response?.data?.message || 'Failed to update status');
    }
  };

  if (loading) return <ActivityIndicator size="large" color="#007AFF" style={{ marginTop: 50 }} />;

  return (
    <View style={styles.container}>
      <FlatList
        data={orders}
        keyExtractor={(item) => item._id}
        showsVerticalScrollIndicator={false}
        renderItem={({ item }) => (
          <TouchableOpacity style={styles.card} onPress={() => setSelectedOrder(item)}>
            <View style={styles.cardHeader}>
              <View>
                <Text style={styles.orderId}>#{item._id.slice(-6).toUpperCase()}</Text>
                <Text style={styles.date}>{new Date(item.createdAt).toLocaleDateString()} {new Date(item.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</Text>
              </View>
              <View style={[styles.statusBadge, styles[`status${item.status}` as keyof typeof styles] || styles.statusPending]}>
                <Text style={[styles.statusText, styles[`statusText${item.status}` as keyof typeof styles] || styles.statusTextPending]}>{item.status}</Text>
              </View>
            </View>
            
            <View style={styles.userRow}>
              <Ionicons name="person-outline" size={14} color="#666" />
              <Text style={styles.userName}>{item.user?.name || 'Guest User'}</Text>
            </View>

            <View style={styles.cardFooter}>
              <Text style={styles.paymentMethod}>{item.paymentMethod}</Text>
              <Text style={styles.total}>${(item.totalPrice || 0).toFixed(2)}</Text>
            </View>
          </TouchableOpacity>
        )}
      />

      <Modal visible={!!selectedOrder} animationType="slide" transparent onRequestClose={() => setSelectedOrder(null)}>
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <View style={styles.modalHeader}>
              <View>
                <Text style={styles.modalTitle}>Order Details</Text>
                <Text style={styles.modalSub}>#{selectedOrder?._id}</Text>
              </View>
              <TouchableOpacity onPress={() => setSelectedOrder(null)} style={styles.closeBtn}>
                <MaterialIcons name="close" size={24} color="#333" />
              </TouchableOpacity>
            </View>
            
            {selectedOrder && (
              <ScrollView showsVerticalScrollIndicator={false}>
                <View style={styles.detailSection}>
                  <Text style={styles.detailLabel}>CUSTOMER INFO</Text>
                  <Text style={styles.detailValue}>{selectedOrder.user?.name}</Text>
                  <Text style={styles.detailSubValue}>{selectedOrder.user?.email}</Text>
                </View>

                <View style={styles.detailSection}>
                  <Text style={styles.detailLabel}>SHIPPING ADDRESS</Text>
                  <Text style={styles.detailValue}>{selectedOrder.shippingAddress?.address}</Text>
                  <Text style={styles.detailSubValue}>{selectedOrder.shippingAddress?.city}</Text>
                </View>

                <View style={styles.detailSection}>
                  <Text style={styles.detailLabel}>ORDER ITEMS</Text>
                  {selectedOrder.orderItems.map((item, idx) => (
                    <View key={idx} style={styles.itemRow}>
                      <View style={{ flex: 1 }}>
                        <Text style={styles.itemName}>{item.name}</Text>
                        <Text style={styles.itemQty}>Quantity: {item.quantity}</Text>
                      </View>
                      <Text style={styles.itemPrice}>${(item.price * item.quantity).toFixed(2)}</Text>
                    </View>
                  ))}
                </View>

                <View style={styles.totalSection}>
                  <Text style={styles.totalLabel}>Grand Total</Text>
                  <Text style={styles.totalValue}>${(selectedOrder.totalPrice || 0).toFixed(2)}</Text>
                </View>
                
                <Text style={[styles.detailLabel, { marginTop: 20 }]}>UPDATE STATUS</Text>
                <View style={styles.statusButtons}>
                  {STATUS_OPTIONS.map(status => (
                    <TouchableOpacity 
                      key={status} 
                      style={[
                        styles.statusBtn, 
                        selectedOrder.status === status && { backgroundColor: '#2F2D2C', borderColor: '#2F2D2C' }
                      ]}
                      onPress={() => updateStatus(selectedOrder._id, status)}
                    >
                      <Text style={[styles.statusBtnText, selectedOrder.status === status && { color: '#fff' }]}>{status}</Text>
                    </TouchableOpacity>
                  ))}
                </View>
                <View style={{ height: 40 }} />
              </ScrollView>
            )}
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 15, backgroundColor: '#F9F9F9' },
  card: { backgroundColor: '#fff', padding: 20, borderRadius: 20, marginBottom: 15, shadowColor: '#000', shadowOpacity: 0.05, shadowRadius: 10, elevation: 3 },
  cardHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 15 },
  orderId: { fontSize: 17, fontWeight: 'bold', color: '#2F2D2C' },
  date: { fontSize: 12, color: '#999', marginTop: 2 },
  statusBadge: { paddingHorizontal: 12, paddingVertical: 6, borderRadius: 10 },
  statusText: { fontSize: 12, fontWeight: 'bold' },
  statusPending: { backgroundColor: '#FFF9F0' },
  statusTextPending: { color: '#FF9500' },
  statusProcessing: { backgroundColor: '#F0F7FF' },
  statusTextProcessing: { color: '#007AFF' },
  statusShipped: { backgroundColor: '#F0FFF7' },
  statusTextShipped: { color: '#34C759' },
  statusDelivered: { backgroundColor: '#F0FFF7' },
  statusTextDelivered: { color: '#34C759' },
  statusCancelled: { backgroundColor: '#FFF0F0' },
  statusTextCancelled: { color: '#FF3B30' },
  userRow: { flexDirection: 'row', alignItems: 'center', marginBottom: 15 },
  userName: { fontSize: 14, color: '#666', marginLeft: 6 },
  cardFooter: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', borderTopWidth: 1, borderTopColor: '#F5F5F5', paddingTop: 15 },
  paymentMethod: { fontSize: 12, color: '#999', fontWeight: '500' },
  total: { fontSize: 18, fontWeight: 'bold', color: '#2F2D2C' },
  
  // Modal
  modalOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.6)', justifyContent: 'flex-end' },
  modalContent: { backgroundColor: '#fff', borderTopLeftRadius: 30, borderTopRightRadius: 30, padding: 25, maxHeight: '90%' },
  modalHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 25 },
  modalTitle: { fontSize: 22, fontWeight: 'bold', color: '#2F2D2C' },
  modalSub: { fontSize: 12, color: '#999', marginTop: 2 },
  closeBtn: { padding: 5, backgroundColor: '#F5F5F5', borderRadius: 20 },
  detailSection: { marginBottom: 20, paddingBottom: 15, borderBottomWidth: 1, borderBottomColor: '#F5F5F5' },
  detailLabel: { fontSize: 11, fontWeight: 'bold', color: '#999', letterSpacing: 1, marginBottom: 8 },
  detailValue: { fontSize: 16, fontWeight: 'bold', color: '#2F2D2C' },
  detailSubValue: { fontSize: 14, color: '#666', marginTop: 2 },
  itemRow: { flexDirection: 'row', justifyContent: 'space-between', paddingVertical: 10 },
  itemName: { fontSize: 15, color: '#2F2D2C', fontWeight: '500' },
  itemQty: { fontSize: 12, color: '#999', marginTop: 2 },
  itemPrice: { fontSize: 15, fontWeight: 'bold', color: '#2F2D2C' },
  totalSection: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', backgroundColor: '#FDF9F6', padding: 15, borderRadius: 15 },
  totalLabel: { fontSize: 16, fontWeight: 'bold', color: '#2F2D2C' },
  totalValue: { fontSize: 20, fontWeight: 'bold', color: '#C67C4E' },
  statusButtons: { flexDirection: 'row', flexWrap: 'wrap', gap: 10, marginTop: 10 },
  statusBtn: { paddingHorizontal: 15, paddingVertical: 10, borderRadius: 12, borderWidth: 1, borderColor: '#EEE', backgroundColor: '#F9F9F9' },
  statusBtnText: { color: '#666', fontWeight: 'bold', fontSize: 13 }
});
