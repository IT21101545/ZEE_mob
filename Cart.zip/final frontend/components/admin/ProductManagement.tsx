import React, { useEffect, useState } from 'react';
import { 
  View, 
  Text, 
  StyleSheet, 
  TouchableOpacity, 
  ActivityIndicator, 
  Alert, 
  FlatList, 
  TextInput, 
  ScrollView,
  Dimensions
} from 'react-native';
import { Image } from 'expo-image';
import { MaterialIcons, Ionicons } from '@expo/vector-icons';
import * as ImagePicker from 'expo-image-picker';
import * as SecureStore from 'expo-secure-store';
import api from '../../api/axios';
import { useProducts, Product } from '../../context/ProductContext';
import { Colors } from '@/constants/theme';

const { width } = Dimensions.get('window');

const CATEGORIES = [
  'Cotton', 'Silk', 'Linen', 'Velvet', 'Georgette',
  'Chiffon', 'Satin', 'Polyester', 'Wool', 'Denim',
  'Rayon', 'Nylon', 'Crepe', 'Organza', 'Net',
  'Lycra', 'Khadi', 'Jute', 'Other'
];

export default function ProductManagement() {
  const { products, fetchProducts, addProduct } = useProducts();
  const [loading, setLoading] = useState(false);
  const [showAddForm, setShowAddForm] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);

  // Form State
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [price, setPrice] = useState('');
  const [category, setCategory] = useState('');
  const [customCategory, setCustomCategory] = useState('');
  const [stock, setStock] = useState('');
  const [image, setImage] = useState<ImagePicker.ImagePickerAsset | null>(null);
  const [existingImage, setExistingImage] = useState('');
  const [additionalImages, setAdditionalImages] = useState<ImagePicker.ImagePickerAsset[]>([]);
  const [existingAdditionalImages, setExistingAdditionalImages] = useState<string[]>([]);

  useEffect(() => {
    fetchProducts();
  }, []);

  const pickImage = async () => {
    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      allowsEditing: true,
      aspect: [4, 3],
      quality: 0.8,
    });

    if (!result.canceled) {
      setImage(result.assets[0]);
    }
  };

  const pickAdditionalImages = async () => {
    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      allowsMultipleSelection: true,
      selectionLimit: 5,
      quality: 0.7,
    });
    if (!result.canceled) {
      setAdditionalImages(prev => [...prev, ...result.assets].slice(0, 5));
    }
  };

  const resetForm = () => {
    setName('');
    setDescription('');
    setPrice('');
    setCategory('');
    setCustomCategory('');
    setStock('');
    setImage(null);
    setExistingImage('');
    setAdditionalImages([]);
    setExistingAdditionalImages([]);
    setEditingId(null);
    setShowAddForm(false);
  };

  const openEditForm = (prod: Product) => {
    setEditingId(prod._id);
    setName(prod.name);
    setDescription(prod.description);
    setPrice(prod.price.toString());
    if (CATEGORIES.includes(prod.category)) {
      setCategory(prod.category);
      setCustomCategory('');
    } else {
      setCategory('Other');
      setCustomCategory(prod.category);
    }
    setStock(prod.stock.toString());
    setExistingImage(prod.image);
    setImage(null);
    setAdditionalImages([]);
    setExistingAdditionalImages(prod.images || []);
    setShowAddForm(true);
  };

  const handleSubmit = async () => {
    const finalCategory = category === 'Other' ? customCategory.trim() : category;
    if (!name || !description || !price || !finalCategory || !stock) {
      Alert.alert('Error', 'Please fill all fields');
      return;
    }

    setLoading(true);
    try {
      const formData = new FormData();
      formData.append('name', name);
      formData.append('description', description);
      formData.append('price', price);
      formData.append('category', finalCategory);
      formData.append('stock', stock);

      if (image) {
        const filename = image.uri.split('/').pop() || 'product.jpg';
        const match = /\.(\w+)$/.exec(filename);
        const type = match ? `image/${match[1]}` : `image`;
        formData.append('image', { uri: image.uri, name: filename, type } as any);
      }

      additionalImages.forEach((img, i) => {
        const filename = img.uri.split('/').pop() || `extra_${i}.jpg`;
        const match = /\.(\w+)$/.exec(filename);
        const type = match ? `image/${match[1]}` : `image`;
        formData.append('images', { uri: img.uri, name: filename, type } as any);
      });

      if (editingId && additionalImages.length > 0) {
        formData.append('keepExistingImages', 'false');
      }

      if (editingId) {
        const token = await SecureStore.getItemAsync('userToken');
        const res = await fetch(`${api.defaults.baseURL}/products/${editingId}`, {
          method: 'PUT',
          headers: { Authorization: `Bearer ${token}` },
          body: formData,
        });
        if (!res.ok) throw new Error(await res.text());
        Alert.alert('Success', 'Product updated successfully!');
      } else {
        await addProduct(formData);
        Alert.alert('Success', 'Product created successfully!');
      }
      
      resetForm();
      fetchProducts();
    } catch (error: any) {
      Alert.alert('Error', error.response?.data?.message || 'Failed to save product');
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = (id: string) => {
    Alert.alert('Confirm Delete', 'Are you sure you want to delete this product?', [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Delete',
        style: 'destructive',
        onPress: async () => {
          try {
            await api.delete(`/products/${id}`);
            fetchProducts();
            Alert.alert('Success', 'Product deleted');
          } catch (error: any) {
            Alert.alert('Error', error.response?.data?.message || 'Failed to delete product');
          }
        }
      }
    ]);
  };

  if (showAddForm) {
    return (
      <ScrollView style={styles.formContainer} showsVerticalScrollIndicator={false}>
        <View style={styles.formHeader}>
          <Text style={styles.formTitle}>{editingId ? 'Edit Product' : 'Add New Product'}</Text>
          <TouchableOpacity onPress={resetForm} style={styles.closeBtn}>
            <Ionicons name="close" size={24} color="#333" />
          </TouchableOpacity>
        </View>

        <TouchableOpacity style={styles.imagePicker} onPress={pickImage}>
          {image ? (
            <Image source={{ uri: image.uri }} style={styles.imagePreview} />
          ) : existingImage ? (
            <Image source={{ uri: existingImage }} style={styles.imagePreview} />
          ) : (
            <View style={styles.placeholder}>
              <Ionicons name="cloud-upload-outline" size={40} color={Colors.light.accent} />
              <Text style={styles.placeholderText}>Select Cover Image</Text>
            </View>
          )}
        </TouchableOpacity>

        <View style={styles.inputGroup}>
          <Text style={styles.label}>Product Name</Text>
          <TextInput style={styles.input} placeholder="e.g. Premium Cotton Shirt" placeholderTextColor="#999" value={name} onChangeText={setName} />
        </View>

        <View style={styles.inputGroup}>
          <Text style={styles.label}>Description</Text>
          <TextInput style={[styles.input, styles.textArea]} placeholder="Describe the material, quality, etc." placeholderTextColor="#999" value={description} onChangeText={setDescription} multiline />
        </View>
        
        <View style={styles.row}>
          <View style={[styles.inputGroup, { flex: 1, marginRight: 10 }]}>
            <Text style={styles.label}>Price ($)</Text>
            <TextInput style={styles.input} placeholder="25.99" placeholderTextColor="#999" value={price} onChangeText={setPrice} keyboardType="numeric" />
          </View>
          <View style={[styles.inputGroup, { flex: 1 }]}>
            <Text style={styles.label}>Stock</Text>
            <TextInput style={styles.input} placeholder="100" placeholderTextColor="#999" value={stock} onChangeText={setStock} keyboardType="numeric" />
          </View>
        </View>
        
        <Text style={styles.label}>Category</Text>
        <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.chipScroll} contentContainerStyle={styles.chipContainer}>
          {CATEGORIES.map((cat) => (
            <TouchableOpacity
              key={cat}
              style={[styles.chip, category === cat && styles.chipActive]}
              onPress={() => setCategory(cat)}
            >
              <Text style={[styles.chipText, category === cat && styles.chipTextActive]}>{cat}</Text>
            </TouchableOpacity>
          ))}
        </ScrollView>

        {category === 'Other' && (
          <TextInput
            style={styles.input}
            placeholder="Enter custom category name"
            placeholderTextColor="#999"
            value={customCategory}
            onChangeText={setCustomCategory}
          />
        )}

        <Text style={styles.label}>Additional Photos</Text>
        <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ marginBottom: 20 }}>
          {existingAdditionalImages.map((uri, i) => (
            <View key={`existing-${i}`} style={styles.extraImgWrap}>
              <Image source={{ uri }} style={styles.extraImg} />
              <TouchableOpacity
                style={styles.extraImgRemove}
                onPress={() => setExistingAdditionalImages(prev => prev.filter((_, idx) => idx !== i))}
              >
                <Ionicons name="close" size={12} color="#fff" />
              </TouchableOpacity>
            </View>
          ))}
          {additionalImages.map((img, i) => (
            <View key={`new-${i}`} style={styles.extraImgWrap}>
              <Image source={{ uri: img.uri }} style={styles.extraImg} />
              <TouchableOpacity
                style={styles.extraImgRemove}
                onPress={() => setAdditionalImages(prev => prev.filter((_, idx) => idx !== i))}
              >
                <Ionicons name="close" size={12} color="#fff" />
              </TouchableOpacity>
            </View>
          ))}
          {(additionalImages.length + existingAdditionalImages.length) < 5 && (
            <TouchableOpacity style={styles.extraImgAdd} onPress={pickAdditionalImages}>
              <Ionicons name="add" size={28} color={Colors.light.accent} />
              <Text style={{ fontSize: 10, color: Colors.light.accent, fontWeight: 'bold' }}>ADD</Text>
            </TouchableOpacity>
          )}
        </ScrollView>

        <TouchableOpacity style={styles.submitBtn} onPress={handleSubmit} disabled={loading}>
          {loading ? <ActivityIndicator color="#fff" /> : <Text style={styles.submitBtnText}>{editingId ? 'Save Changes' : 'Publish Product'}</Text>}
        </TouchableOpacity>
        <View style={{ height: 100 }} />
      </ScrollView>
    );
  }

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>Inventory</Text>
        <TouchableOpacity style={styles.addCircleBtn} onPress={() => setShowAddForm(true)}>
          <Ionicons name="add" size={24} color="#fff" />
        </TouchableOpacity>
      </View>

      <FlatList
        data={products}
        keyExtractor={(item) => item._id}
        showsVerticalScrollIndicator={false}
        renderItem={({ item }) => (
          <View style={styles.card}>
            <Image source={{ uri: item.image || 'https://via.placeholder.com/100' }} style={styles.thumbnail} />
            <View style={styles.info}>
              <Text style={styles.productName} numberOfLines={1}>{item.name}</Text>
              <View style={styles.priceRow}>
                <Text style={styles.productPrice}>${item.price.toFixed(2)}</Text>
                <View style={styles.stockBadge}>
                  <Text style={styles.stockText}>{item.stock} in stock</Text>
                </View>
              </View>
            </View>
            <View style={styles.actions}>
              <TouchableOpacity style={[styles.iconBtn, { backgroundColor: '#FDF5F0' }]} onPress={() => openEditForm(item)}>
                <Ionicons name="create-outline" size={20} color={Colors.light.accent} />
              </TouchableOpacity>
              <TouchableOpacity style={[styles.iconBtn, { backgroundColor: '#FEF0F0' }]} onPress={() => handleDelete(item._id)}>
                <Ionicons name="trash-outline" size={20} color="#FF3B30" />
              </TouchableOpacity>
            </View>
          </View>
        )}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#F9F9F9' },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingVertical: 15 },
  title: { fontSize: 24, fontWeight: 'bold', color: '#2F2D2C' },
  addCircleBtn: { backgroundColor: Colors.light.accent, width: 44, height: 44, borderRadius: 22, justifyContent: 'center', alignItems: 'center', shadowColor: Colors.light.accent, shadowOpacity: 0.3, shadowRadius: 10, elevation: 5 },
  card: { flexDirection: 'row', backgroundColor: '#fff', padding: 12, borderRadius: 20, marginBottom: 15, alignItems: 'center', shadowColor: '#000', shadowOpacity: 0.05, shadowRadius: 10, elevation: 2 },
  thumbnail: { width: 65, height: 65, borderRadius: 15, backgroundColor: '#F5F5F5' },
  info: { flex: 1, marginLeft: 15 },
  productName: { fontSize: 16, fontWeight: 'bold', color: '#2F2D2C' },
  priceRow: { flexDirection: 'row', alignItems: 'center', marginTop: 5 },
  productPrice: { fontSize: 15, fontWeight: 'bold', color: Colors.light.accent, marginRight: 10 },
  stockBadge: { backgroundColor: '#F5F5F5', paddingHorizontal: 8, paddingVertical: 2, borderRadius: 6 },
  stockText: { fontSize: 11, color: '#666', fontWeight: '500' },
  actions: { flexDirection: 'row', gap: 10 },
  iconBtn: { width: 36, height: 36, borderRadius: 10, justifyContent: 'center', alignItems: 'center' },
  
  // Form Styles
  formContainer: { flex: 1 },
  formHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 25 },
  formTitle: { fontSize: 22, fontWeight: 'bold', color: '#2F2D2C' },
  closeBtn: { padding: 5 },
  imagePicker: { height: 200, backgroundColor: '#F9F9F9', borderRadius: 25, borderWidth: 1, borderColor: '#EAEAEA', borderStyle: 'dashed', marginBottom: 25, overflow: 'hidden', justifyContent: 'center', alignItems: 'center' },
  imagePreview: { width: '100%', height: '100%' },
  placeholder: { alignItems: 'center' },
  placeholderText: { marginTop: 10, color: Colors.light.accent, fontWeight: 'bold', fontSize: 14 },
  inputGroup: { marginBottom: 20 },
  label: { fontSize: 14, fontWeight: 'bold', color: '#2F2D2C', marginBottom: 10 },
  input: { backgroundColor: '#fff', borderWidth: 1, borderColor: '#F0F0F0', borderRadius: 15, padding: 15, fontSize: 15, color: '#2F2D2C' },
  textArea: { minHeight: 100, textAlignVertical: 'top' },
  row: { flexDirection: 'row' },
  chipScroll: { marginBottom: 20 },
  chipContainer: { flexDirection: 'row', gap: 10, paddingRight: 20 },
  chip: { paddingHorizontal: 15, paddingVertical: 10, borderRadius: 12, backgroundColor: '#F5F5F5', borderWidth: 1, borderColor: '#EAEAEA' },
  chipActive: { backgroundColor: '#2F2D2C', borderColor: '#2F2D2C' },
  chipText: { fontSize: 13, color: '#666', fontWeight: '500' },
  chipTextActive: { color: '#fff', fontWeight: 'bold' },
  extraImgWrap: { width: 70, height: 70, marginRight: 12, borderRadius: 15, overflow: 'hidden', position: 'relative' },
  extraImg: { width: 70, height: 70 },
  extraImgRemove: { position: 'absolute', top: 3, right: 3, backgroundColor: 'rgba(255,59,48,0.9)', borderRadius: 10, width: 20, height: 20, justifyContent: 'center', alignItems: 'center' },
  extraImgAdd: { width: 70, height: 70, borderRadius: 15, borderWidth: 1, borderColor: Colors.light.accent, borderStyle: 'dashed', justifyContent: 'center', alignItems: 'center', backgroundColor: '#FDF5F0' },
  submitBtn: { backgroundColor: Colors.light.accent, padding: 18, borderRadius: 20, alignItems: 'center', shadowColor: Colors.light.accent, shadowOpacity: 0.2, shadowRadius: 10, elevation: 5 },
  submitBtnText: { color: '#fff', fontSize: 16, fontWeight: 'bold' },
});

