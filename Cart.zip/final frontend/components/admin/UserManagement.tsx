import React, { useEffect, useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, ActivityIndicator, Alert, FlatList, Image } from 'react-native';
import { MaterialIcons } from '@expo/vector-icons';
import api from '../../api/axios';

interface User {
  _id: string;
  name: string;
  email: string;
  role: string;
  isBlocked: boolean;
  avatar?: string;
  createdAt: string;
}

export default function UserManagement() {
  const [users, setUsers] = useState<User[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchUsers = async () => {
    try {
      const res = await api.get('/auth/users');
      setUsers(res.data);
    } catch (error) {
      Alert.alert('Error', 'Failed to fetch users');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchUsers();
  }, []);

  const toggleRole = async (userId: string, currentRole: string) => {
    const newRole = currentRole === 'admin' ? 'user' : 'admin';
    try {
      await api.put(`/auth/users/${userId}/role`, { role: newRole });
      fetchUsers();
    } catch (error: any) {
      Alert.alert('Error', error.response?.data?.message || 'Failed to update role');
    }
  };

  const toggleBlock = async (userId: string) => {
    try {
      await api.put(`/auth/users/${userId}/block`);
      fetchUsers();
    } catch (error: any) {
      Alert.alert('Error', error.response?.data?.message || 'Failed to update block status');
    }
  };

  const deleteUser = async (userId: string) => {
    Alert.alert('Confirm', 'Are you sure you want to delete this user?', [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Delete',
        style: 'destructive',
        onPress: async () => {
          try {
            await api.delete(`/auth/users/${userId}`);
            fetchUsers();
          } catch (error: any) {
            Alert.alert('Error', error.response?.data?.message || 'Failed to delete user');
          }
        }
      }
    ]);
  };

  if (loading) return <ActivityIndicator size="large" color="#007AFF" style={{ marginTop: 50 }} />;

  return (
    <View style={styles.container}>
      <FlatList
        data={users}
        keyExtractor={(item) => item._id}
        renderItem={({ item }) => (
          <View style={[styles.card, item.isBlocked && styles.cardBlocked]}>
            <View style={styles.userInfo}>
              {item.avatar ? (
                <Image source={{ uri: item.avatar }} style={styles.avatar} />
              ) : (
                <View style={styles.avatarPlaceholder}>
                  <MaterialIcons name="person" size={24} color="#fff" />
                </View>
              )}
              <View style={styles.userDetails}>
                <Text style={styles.name}>{item.name}</Text>
                <Text style={styles.email}>{item.email}</Text>
                <Text style={styles.role}>Role: {item.role.toUpperCase()}</Text>
                {item.isBlocked && <Text style={styles.blockedText}>BLOCKED</Text>}
              </View>
            </View>
            
            <View style={styles.actions}>
              <TouchableOpacity style={[styles.btn, styles.roleBtn]} onPress={() => toggleRole(item._id, item.role)}>
                <Text style={styles.btnText}>{item.role === 'admin' ? 'Make User' : 'Make Admin'}</Text>
              </TouchableOpacity>
              
              <TouchableOpacity style={[styles.btn, item.isBlocked ? styles.unblockBtn : styles.blockBtn]} onPress={() => toggleBlock(item._id)}>
                <Text style={styles.btnText}>{item.isBlocked ? 'Unblock' : 'Block'}</Text>
              </TouchableOpacity>
              
              <TouchableOpacity style={styles.iconBtn} onPress={() => deleteUser(item._id)}>
                <MaterialIcons name="delete" size={24} color="#ff3b30" />
              </TouchableOpacity>
            </View>
          </View>
        )}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, paddingBottom: 20 },
  card: { backgroundColor: '#fff', padding: 15, borderRadius: 10, marginBottom: 15, elevation: 2, shadowColor: '#000', shadowOpacity: 0.1, shadowRadius: 4, shadowOffset: { width: 0, height: 2 } },
  cardBlocked: { backgroundColor: '#ffebe6' },
  userInfo: { flexDirection: 'row', alignItems: 'center', marginBottom: 15 },
  avatar: { width: 50, height: 50, borderRadius: 25, marginRight: 15 },
  avatarPlaceholder: { width: 50, height: 50, borderRadius: 25, backgroundColor: '#ccc', marginRight: 15, justifyContent: 'center', alignItems: 'center' },
  userDetails: { flex: 1 },
  name: { fontSize: 18, fontWeight: 'bold', color: '#333' },
  email: { fontSize: 14, color: '#666', marginTop: 2 },
  role: { fontSize: 12, color: '#007AFF', marginTop: 4, fontWeight: 'bold' },
  blockedText: { fontSize: 12, color: '#ff3b30', fontWeight: 'bold', marginTop: 4 },
  actions: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', borderTopWidth: 1, borderTopColor: '#eee', paddingTop: 15 },
  btn: { paddingVertical: 8, paddingHorizontal: 12, borderRadius: 6, flex: 1, alignItems: 'center', marginHorizontal: 5 },
  roleBtn: { backgroundColor: '#f0ad4e' },
  blockBtn: { backgroundColor: '#ff9800' },
  unblockBtn: { backgroundColor: '#4caf50' },
  btnText: { color: '#fff', fontWeight: 'bold', fontSize: 12 },
  iconBtn: { padding: 5, marginLeft: 10 }
});
