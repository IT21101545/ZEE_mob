import React, { createContext, useState, useEffect, useContext } from 'react';
import api from '../api/axios';
import { useAuth } from './AuthContext';
import { Product } from './ProductContext';

interface WishlistContextData {
  wishlist: Product[];
  isLoading: boolean;
  toggleWishlist: (productId: string) => Promise<boolean>;
  isInWishlist: (productId: string) => boolean;
}

const WishlistContext = createContext<WishlistContextData>({} as WishlistContextData);

export function WishlistProvider({ children }: { children: React.ReactNode }) {
  const [wishlist, setWishlist] = useState<Product[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const { user } = useAuth();

  const fetchWishlist = async () => {
    if (!user) return;
    setIsLoading(true);
    try {
      const res = await api.get('/wishlist');
      setWishlist(res.data);
    } catch (err) {
      console.error('Error fetching wishlist:', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchWishlist();
  }, [user]);

  const toggleWishlist = async (productId: string) => {
    try {
      const res = await api.post(`/wishlist/toggle/${productId}`);
      const { added } = res.data;
      
      // Optimistic update or just refetch
      if (added) {
        // We might not have the full product object here if we just get the ID back
        // For simplicity, refetch
        fetchWishlist();
      } else {
        setWishlist(prev => prev.filter(p => p._id !== productId));
      }
      return added;
    } catch (err) {
      console.error('Error toggling wishlist:', err);
      return false;
    }
  };

  const isInWishlist = (productId: string) => {
    return wishlist.some(p => p._id === productId);
  };

  return (
    <WishlistContext.Provider value={{ wishlist, isLoading, toggleWishlist, isInWishlist }}>
      {children}
    </WishlistContext.Provider>
  );
}

export function useWishlist() {
  return useContext(WishlistContext);
}
