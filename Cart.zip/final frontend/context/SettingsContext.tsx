import React, { createContext, useContext, useState, useEffect } from 'react';
import * as SecureStore from 'expo-secure-store';
import { Platform } from 'react-native';

type Language = 'English' | 'Sinhala' | 'Tamil';

interface SettingsContextType {
  language: Language;
  setLanguage: (lang: Language) => Promise<void>;
}

const SettingsContext = createContext<SettingsContextType>({} as SettingsContextType);

export const SettingsProvider = ({ children }: { children: React.ReactNode }) => {
  const [language, _setLanguage] = useState<Language>('English');

  useEffect(() => {
    const loadSettings = async () => {
      try {
        let savedLang: string | null = null;
        if (Platform.OS === 'web') {
          savedLang = localStorage.getItem('userLanguage');
        } else {
          savedLang = await SecureStore.getItemAsync('userLanguage');
        }
        
        if (savedLang === 'English' || savedLang === 'Sinhala' || savedLang === 'Tamil') {
          _setLanguage(savedLang as Language);
        }
      } catch (e) {
        console.error('Failed to load language', e);
      }
    };
    loadSettings();
  }, []);

  const setLanguage = async (lang: Language) => {
    _setLanguage(lang);
    try {
      if (Platform.OS === 'web') {
        localStorage.setItem('userLanguage', lang);
      } else {
        await SecureStore.setItemAsync('userLanguage', lang);
      }
    } catch (e) {
      console.error('Failed to save language', e);
    }
  };

  return (
    <SettingsContext.Provider value={{ language, setLanguage }}>
      {children}
    </SettingsContext.Provider>
  );
};

export const useSettings = () => useContext(SettingsContext);
