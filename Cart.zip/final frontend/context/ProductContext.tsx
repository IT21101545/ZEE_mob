import React, { createContext, useState, useEffect, useContext } from 'react';
import { Image } from 'react-native';
import api from '../api/axios';
import * as SecureStore from 'expo-secure-store';

export interface Product {
  _id: string;
  name: string;
  description: string;
  price: number;
  category: string;
  stock: number;
  image: string;
  images?: string[];
}

interface ProductContextData {
  products: Product[];
  isLoading: boolean;
  fetchProducts: () => Promise<void>;
  getProduct: (id: string) => Promise<Product | null>;
  addProduct: (formData: FormData) => Promise<void>;
}

const ProductContext = createContext<ProductContextData>({} as ProductContextData);

export const ProductProvider = ({ children }: { children: React.ReactNode }) => {
  const [products, setProducts] = useState<Product[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  const fetchProducts = async () => {
    setIsLoading(true);
    try {
      const res = await api.get('/products');
      setProducts(res.data);
      
      // Prefetch images for instant display without crashing on failure
      res.data.forEach((p: Product) => {
        if (p.image) Image.prefetch(p.image).catch(() => console.warn('Failed to prefetch:', p.image));
        if (p.images) p.images.forEach(img => Image.prefetch(img).catch(() => {}));
      });
    } catch (error) {
      console.error('Failed to fetch products', error);
    } finally {
      setIsLoading(false);
    }
  };

  const getProduct = async (id: string, forceRefresh = false) => {
    // Try to find in local state first for instant loading
    const localProduct = products.find(p => p._id === id);
    if (localProduct && !forceRefresh) return localProduct;

    try {
      const res = await api.get(`/products/${id}`);
      return res.data;
    } catch (error) {
      console.error('Failed to get product', error);
      return null;
    }
  };

  const addProduct = async (formData: FormData) => {
    try {
      const token = await SecureStore.getItemAsync('userToken');
      const res = await fetch(`${api.defaults.baseURL}/products`, {
        method: 'POST',
        headers: { Authorization: `Bearer ${token}` },
        body: formData,
      });
      if (!res.ok) throw new Error(await res.text());
      await fetchProducts();
    } catch (error) {
      console.error('Failed to add product', error);
      throw error;
    }
  };

  useEffect(() => {
    fetchProducts();
  }, []);

  return (
    <ProductContext.Provider value={{ products, isLoading, fetchProducts, getProduct, addProduct }}>
      {children}
    </ProductContext.Provider>
  );
};

export const useProducts = () => useContext(ProductContext);
