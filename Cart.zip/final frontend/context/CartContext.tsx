import React, { createContext, useState, useEffect, useContext } from 'react';
import api from '../api/axios';
import { useAuth } from './AuthContext';
import * as SecureStore from 'expo-secure-store';

export interface CartItem {
  product: {
    _id: string;
    name: string;
    price: number;
    image: string;
    stock: number;
  };
  quantity: number;
  customFile?: string;
}

interface CartContextData {
  cartItems: CartItem[];
  cartTotal: number;
  isLoading: boolean;
  fetchCart: () => Promise<void>;
  addToCart: (productId: string, quantity: number, customFile?: any) => Promise<void>;
  updateCartItem: (productId: string, quantity: number) => Promise<void>;
  removeFromCart: (productId: string) => Promise<void>;
  clearCart: () => Promise<void>;
  shippingAddress: { address: string; city: string; postalCode: string };
  setShippingAddress: (address: { address: string; city: string; postalCode: string }) => void;
}

const CartContext = createContext<CartContextData>({} as CartContextData);

export const CartProvider = ({ children }: { children: React.ReactNode }) => {
  const [cartItems, setCartItems] = useState<CartItem[]>([]);
  const [cartTotal, setCartTotal] = useState(0);
  const [isLoading, setIsLoading] = useState(false);
  const { user } = useAuth();
  const [shippingAddress, setShippingAddress] = useState({ 
    address: 'Jl. Kp Baru No. 1, Colombo 07', 
    city: 'Colombo', 
    postalCode: '00700' 
  });

  const fetchCart = async () => {
    if (!user) return;
    setIsLoading(true);
    try {
      const res = await api.get('/cart');
      setCartItems(res.data.cart.items);
      setCartTotal(res.data.total);
    } catch (error) {
      console.error('Failed to fetch cart', error);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    if (user) {
      fetchCart();
    } else {
      setCartItems([]);
      setCartTotal(0);
    }
  }, [user]);

  const addToCart = async (productId: string, quantity: number, customFile?: any) => {
    try {
      if (customFile) {
        const formData = new FormData();
        formData.append('productId', productId);
        formData.append('quantity', quantity.toString());
        
        const filename = customFile.uri.split('/').pop() || 'custom.jpg';
        const match = /\.(\w+)$/.exec(filename);
        const type = match ? `image/${match[1]}` : `image`;
        formData.append('customFile', { uri: customFile.uri, name: filename, type } as any);
        
        await api.post('/cart/add', formData, {
          headers: { 'Content-Type': 'multipart/form-data' }
        });
      } else {
        await api.post('/cart/add', { productId, quantity });
      }
      await fetchCart();
    } catch (error) {
      console.error('Add to cart failed', error);
      throw error;
    }
  };

  const updateCartItem = async (productId: string, quantity: number) => {
    try {
      await api.put('/cart/update', { productId, quantity });
      fetchCart();
    } catch (error) {
      throw error;
    }
  };

  const removeFromCart = async (productId: string) => {
    try {
      await api.delete(`/cart/remove/${productId}`);
      fetchCart();
    } catch (error) {
      throw error;
    }
  };

  const clearCart = async () => {
    try {
      await api.delete('/cart/clear');
      fetchCart();
    } catch (error) {
      throw error;
    }
  };

  return (
    <CartContext.Provider value={{ 
      cartItems, cartTotal, isLoading, fetchCart, addToCart, updateCartItem, removeFromCart, clearCart,
      shippingAddress, setShippingAddress 
    }}>
      {children}
    </CartContext.Provider>
  );
};

export const useCart = () => useContext(CartContext);
