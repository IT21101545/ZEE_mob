import React, { createContext, useState, useEffect, useContext } from 'react';
import api from '../api/axios';
import { useAuth } from './AuthContext';

export interface OrderItem {
  name: string;
  quantity: number;
  image: string;
  price: number;
  product: string;
}

export interface Order {
  _id: string;
  user: any;
  orderItems: OrderItem[];
  shippingAddress: {
    address: string;
    city: string;
    postalCode: string;
  };
  paymentMethod: string;
  totalPrice: number;
  status: 'Pending' | 'Shipped' | 'Delivered' | 'Cancelled';
  createdAt: string;
}

interface OrderContextData {
  orders: Order[];
  isLoading: boolean;
  createOrder: (orderData: any) => Promise<Order>;
  fetchMyOrders: () => Promise<void>;
  fetchAllOrders: () => Promise<void>;
  updateStatus: (id: string, status: string) => Promise<void>;
}

const OrderContext = createContext<OrderContextData>({} as OrderContextData);

export const OrderProvider = ({ children }: { children: React.ReactNode }) => {
  const [orders, setOrders] = useState<Order[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const { user } = useAuth();

  const fetchMyOrders = async () => {
    setIsLoading(true);
    try {
      const res = await api.get('/orders/myorders');
      setOrders(res.data);
    } catch (err: any) {
      if (err.response?.status !== 401) {
        console.error('Fetch my orders error', err);
      }
    } finally {
      setIsLoading(false);
    }
  };

  const fetchAllOrders = async () => {
    setIsLoading(true);
    try {
      const res = await api.get('/orders');
      setOrders(res.data);
    } catch (err: any) {
      if (err.response?.status !== 401) {
        console.error('Fetch all orders error', err);
      }
    } finally {
      setIsLoading(false);
    }
  };

  const createOrder = async (orderData: any) => {
    try {
      const res = await api.post('/orders', orderData);
      setOrders([res.data, ...orders]);
      return res.data;
    } catch (err) {
      throw err;
    }
  };

  const updateStatus = async (id: string, status: string) => {
    try {
      const res = await api.put(`/orders/${id}/status`, { status });
      setOrders(orders.map(o => o._id === id ? res.data : o));
    } catch (err) {
      throw err;
    }
  };

  useEffect(() => {
    if (user) {
      if (user.role === 'admin') {
        fetchAllOrders();
      } else {
        fetchMyOrders();
      }
    }
  }, [user]);

  return (
    <OrderContext.Provider value={{ orders, isLoading, createOrder, fetchMyOrders, fetchAllOrders, updateStatus }}>
      {children}
    </OrderContext.Provider>
  );
};

export const useOrders = () => useContext(OrderContext);
