import React, { createContext, useContext, useState, useEffect } from 'react';
import { useColorScheme as _useColorScheme } from 'react-native';
import * as SecureStore from 'expo-secure-store';
import { Platform } from 'react-native';

type Theme = 'light' | 'dark';

interface ThemeContextType {
  theme: Theme;
  toggleTheme: () => void;
  isDark: boolean;
}

const ThemeContext = createContext<ThemeContextType>({} as ThemeContextType);

export const ThemeProvider = ({ children }: { children: React.ReactNode }) => {
  const systemColorScheme = _useColorScheme();
  const [theme, setTheme] = useState<Theme>('light');

  useEffect(() => {
    const loadTheme = async () => {
      try {
        let savedTheme: string | null = null;
        if (Platform.OS === 'web') {
          savedTheme = localStorage.getItem('userTheme');
        } else {
          savedTheme = await SecureStore.getItemAsync('userTheme');
        }
        
        if (savedTheme === 'light' || savedTheme === 'dark') {
          setTheme(savedTheme as Theme);
        } else {
          setTheme(systemColorScheme || 'light');
        }
      } catch (e) {
        setTheme(systemColorScheme || 'light');
      }
    };
    loadTheme();
  }, [systemColorScheme]);

  const toggleTheme = async () => {
    const newTheme = theme === 'light' ? 'dark' : 'light';
    setTheme(newTheme);
    try {
      if (Platform.OS === 'web') {
        localStorage.setItem('userTheme', newTheme);
      } else {
        await SecureStore.setItemAsync('userTheme', newTheme);
      }
    } catch (e) {}
  };

  return (
    <ThemeContext.Provider value={{ theme, toggleTheme, isDark: theme === 'dark' }}>
      {children}
    </ThemeContext.Provider>
  );
};

export const useAppTheme = () => useContext(ThemeContext);
