import axios from 'axios';
import * as SecureStore from 'expo-secure-store';
import { Platform } from 'react-native';

import Constants from 'expo-constants';

// Auto-detect the correct base URL for each platform
const getBaseUrl = () => {
  // Web is usually opened on the same machine running backend.
  if (Platform.OS === 'web') {
    return 'http://127.0.0.1:5000/api';
  }

  const hostUri =
    Constants.expoConfig?.hostUri ||
    // @ts-ignore - older/newer Expo SDKs expose this differently.
    Constants.manifest2?.extra?.expoClient?.hostUri ||
    // @ts-ignore - fallback for legacy Expo manifest.
    Constants.manifest?.debuggerHost;

  if (hostUri) {
    const ip = String(hostUri).split(':')[0];
    if (ip) {
      console.log(`[Config] Auto-detected backend IP: ${ip}`);
      return `http://${ip}:5000/api`;
    }
  }

  // Final fallback for physical devices: replace with your PC LAN IP if needed.
  return 'http://192.168.8.199:5000/api';
};

let on401: (() => void) | null = null;

export const set401Callback = (cb: () => void) => {
  on401 = cb;
};

const api = axios.create({
  baseURL: getBaseUrl(),
  timeout: 20000, // 20 seconds timeout
  headers: {
    'Content-Type': 'application/json',
  },
});

// Interceptor to add the auth token to all requests
api.interceptors.request.use(
  async (config) => {
    let token = null;
    if (Platform.OS === 'web') {
      token = typeof localStorage !== 'undefined' ? localStorage.getItem('userToken') : null;
    } else {
      token = await SecureStore.getItemAsync('userToken');
    }

    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    
    // Log final URL for debugging
    if (__DEV__) {
      console.log(`[API Request] ${config.method?.toUpperCase()} ${config.baseURL}${config.url}`);
    }
    
    return config;
  },
  (error) => Promise.reject(error)
);

// Add a response interceptor for global error handling
api.interceptors.response.use(
  (response) => response,
  (error) => {
    const { response, message } = error;
    
    if (response) {
      // The server responded with a status code outside the 2xx range
      if (response.status === 401) {
        // Handle unauthorized (token expired, etc.)
        // Silent redirect to login via callback
        if (on401) on401();
      } else {
        console.error(`[API Error] ${response.status}: ${response.data?.message || response.statusText}`);
      }
    } else if (error.request) {
      // The request was made but no response was received
      console.error('[API Network Error] No response received. Check server connection.', message);
    } else {
      // Something happened in setting up the request that triggered an Error
      console.error('[API Config Error]', message);
    }
    
    return Promise.reject(error);
  }
);

export default api;