import React, { useEffect, useState, useCallback } from 'react';
import { View, Text, FlatList, TouchableOpacity, StyleSheet, ActivityIndicator, RefreshControl, SafeAreaView } from 'react-native';
import { MaterialIcons, Ionicons } from '@expo/vector-icons';
import { useRouter, Stack } from 'expo-router';
import { Colors } from '@/constants/theme';
import api from '../api/axios';

interface Notification {
  _id: string;
  type: 'review_reply' | 'new_review' | 'new_order' | 'order_status';
  title: string;
  message: string;
  product?: { _id: string; name: string };
  order?: { _id: string; totalAmount: number; status: string };
  review?: string;
  isRead: boolean;
  createdAt: string;
}

const ICONS: Record<string, { name: string; color: string; bg: string }> = {
  review_reply: { name: 'chatbubble-ellipses', color: '#fff', bg: '#C67C4E' },
  new_review:   { name: 'star', color: '#fff', bg: '#FF9500' },
  new_order:    { name: 'cart', color: '#fff', bg: '#34C759' },
  order_status: { name: 'car', color: '#fff', bg: '#2F2D2C' },
  chat_message: { name: 'chatbubbles', color: '#fff', bg: '#5856D6' },
};

export default function NotificationsScreen() {
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const router = useRouter();

  const fetchNotifications = async () => {
    try {
      const res = await api.get('/notifications');
      setNotifications(res.data.notifications || []);
    } catch (err) {
      console.error('Failed to fetch notifications', err);
    } finally {
      setLoading(false);
    }
  };

  const onRefresh = useCallback(async () => {
    setRefreshing(true);
    await fetchNotifications();
    setRefreshing(false);
  }, []);

  useEffect(() => {
    fetchNotifications();
  }, []);

  const handlePress = async (notif: Notification) => {
    if (!notif.isRead) {
      try {
        await api.put(`/notifications/${notif._id}/read`);
        setNotifications(prev =>
          prev.map(n => n._id === notif._id ? { ...n, isRead: true } : n)
        );
      } catch (err) {}
    }

    if (notif.type === 'review_reply' && notif.product) {
      router.push(`/product/${notif.product._id}`);
    } else if (notif.type === 'new_review') {
      router.push('/(tabs)/reviews');
    } else if (notif.type === 'new_order' || notif.type === 'order_status') {
      router.push('/(tabs)/orders');
    } else if (notif.type === 'chat_message' && notif.order) {
      router.push(`/chat/${notif.order._id}`);
    }
  };

  const markAllRead = async () => {
    try {
      await api.put('/notifications/read-all');
      setNotifications(prev => prev.map(n => ({ ...n, isRead: true })));
    } catch (err) {}
  };

  const formatTime = (dateStr: string) => {
    const date = new Date(dateStr);
    const now = new Date();
    const diffMs = now.getTime() - date.getTime();
    const diffMin = Math.floor(diffMs / 60000);
    const diffHr = Math.floor(diffMin / 60);
    const diffDay = Math.floor(diffHr / 24);

    if (diffMin < 1) return 'Just now';
    if (diffMin < 60) return `${diffMin}m ago`;
    if (diffHr < 24) return `${diffHr}h ago`;
    if (diffDay < 7) return `${diffDay}d ago`;
    return date.toLocaleDateString();
  };

  const renderItem = ({ item }: { item: Notification }) => {
    const icon = ICONS[item.type] || ICONS.new_review;
    return (
      <TouchableOpacity
        style={[styles.card, !item.isRead && styles.cardUnread]}
        onPress={() => handlePress(item)}
        activeOpacity={0.7}
      >
        <View style={[styles.iconCircle, { backgroundColor: icon.bg }]}>
          <Ionicons name={icon.name as any} size={20} color={icon.color} />
        </View>
        <View style={styles.content}>
          <View style={styles.titleRow}>
            <Text style={[styles.title, !item.isRead && styles.titleBold]}>{item.title}</Text>
            <Text style={styles.time}>{formatTime(item.createdAt)}</Text>
          </View>
          <Text style={styles.message} numberOfLines={2}>{item.message}</Text>
          {!item.isRead && (
            <View style={styles.newBadge}>
              <Text style={styles.newBadgeText}>NEW</Text>
            </View>
          )}
        </View>
      </TouchableOpacity>
    );
  };

  const unreadCount = Array.isArray(notifications) ? notifications.filter(n => !n.isRead).length : 0;

  return (
    <SafeAreaView style={styles.container}>
      <Stack.Screen 
        options={{ 
          title: 'Notifications',
          headerTitleStyle: { fontWeight: 'bold', color: '#2F2D2C' },
          headerRight: () => unreadCount > 0 ? (
            <TouchableOpacity onPress={markAllRead} style={{ marginRight: 15 }}>
              <Text style={{ color: Colors.light.accent, fontWeight: 'bold' }}>Mark All Read</Text>
            </TouchableOpacity>
          ) : null
        }} 
      />

      {loading ? (
        <View style={styles.center}>
          <ActivityIndicator size="large" color={Colors.light.accent} />
        </View>
      ) : notifications.length === 0 ? (
        <View style={styles.center}>
          <View style={styles.emptyIconBox}>
            <Ionicons name="notifications-outline" size={60} color="#ccc" />
          </View>
          <Text style={styles.emptyTitle}>All caught up!</Text>
          <Text style={styles.emptySubtitle}>You'll see updates about your orders and reviews here.</Text>
        </View>
      ) : (
        <FlatList
          data={notifications}
          keyExtractor={(item) => item._id}
          renderItem={renderItem}
          contentContainerStyle={styles.list}
          refreshControl={
            <RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={Colors.light.accent} />
          }
        />
      )}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#fff' },
  center: { flex: 1, justifyContent: 'center', alignItems: 'center', padding: 40 },
  list: { padding: 20 },
  card: {
    flexDirection: 'row',
    padding: 15,
    marginBottom: 15,
    borderRadius: 20,
    backgroundColor: '#fff',
    borderWidth: 1,
    borderColor: '#F0F0F0',
    alignItems: 'flex-start',
  },
  cardUnread: {
    backgroundColor: '#FDF5F0',
    borderColor: '#FDF5F0',
  },
  iconCircle: {
    width: 45,
    height: 45,
    borderRadius: 15,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 15,
  },
  content: { flex: 1 },
  titleRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 5 },
  title: { fontSize: 15, color: '#2F2D2C', fontWeight: '600' },
  titleBold: { color: '#2F2D2C' },
  time: { fontSize: 11, color: '#999' },
  message: { fontSize: 13, color: '#777', lineHeight: 18 },
  newBadge: { 
    alignSelf: 'flex-start', 
    backgroundColor: Colors.light.accent, 
    paddingHorizontal: 8, 
    paddingVertical: 2, 
    borderRadius: 10, 
    marginTop: 8 
  },
  newBadgeText: { color: '#fff', fontSize: 10, fontWeight: 'bold' },
  emptyIconBox: { width: 120, height: 120, borderRadius: 60, backgroundColor: '#F9F9F9', justifyContent: 'center', alignItems: 'center', marginBottom: 20 },
  emptyTitle: { fontSize: 20, fontWeight: 'bold', color: '#2F2D2C' },
  emptySubtitle: { fontSize: 14, color: '#999', textAlign: 'center', marginTop: 10, lineHeight: 22 },
});

