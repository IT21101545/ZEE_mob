import React, { useState, useEffect, useRef } from 'react';
import { 
  View, 
  Text, 
  StyleSheet, 
  FlatList, 
  TextInput, 
  TouchableOpacity, 
  KeyboardAvoidingView, 
  Platform, 
  SafeAreaView,
  ActivityIndicator
} from 'react-native';
import { useLocalSearchParams, useRouter, Stack } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { useAppTheme } from '../../context/ThemeContext';
import { useAuth } from '../../context/AuthContext';
import { Colors } from '@/constants/theme';
import api from '../../api/axios';

interface Message {
  _id: string;
  sender: {
    _id: string;
    name: string;
    role: string;
  };
  text: string;
  createdAt: string;
}

export default function ChatScreen() {
  const { orderId } = useLocalSearchParams();
  const { theme } = useAppTheme();
  const { user } = useAuth();
  const colors = Colors[theme];
  const router = useRouter();

  const [messages, setMessages] = useState<Message[]>([]);
  const [inputText, setInputText] = useState('');
  const [loading, setLoading] = useState(true);
  const [sending, setSending] = useState(false);
  const flatListRef = useRef<FlatList>(null);

  const fetchMessages = async () => {
    try {
      const res = await api.get(`/messages/${orderId}`);
      setMessages(res.data);
      // Mark as read
      await api.put(`/messages/${orderId}/read`);
    } catch (error) {
      console.error('Failed to fetch messages', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchMessages();
    // Poll for new messages every 5 seconds for a "live" feel without websockets
    const interval = setInterval(fetchMessages, 5000);
    return () => clearInterval(interval);
  }, [orderId]);

  const handleSend = async () => {
    if (!inputText.trim()) return;

    setSending(true);
    try {
      const res = await api.post('/messages', {
        orderId,
        text: inputText.trim()
      });
      setMessages([...messages, { ...res.data, sender: { _id: user?._id, name: user?.name, role: user?.role } }]);
      setInputText('');
      setTimeout(() => flatListRef.current?.scrollToEnd({ animated: true }), 100);
    } catch (error) {
      console.error('Failed to send message', error);
    } finally {
      setSending(false);
    }
  };

  const renderMessage = ({ item }: { item: Message }) => {
    const isMine = item.sender._id === user?._id;
    return (
      <View style={[
        styles.messageWrapper,
        isMine ? styles.myMessageWrapper : styles.theirMessageWrapper
      ]}>
        {!isMine && <Text style={styles.senderName}>{item.sender.role === 'admin' ? 'Support' : item.sender.name}</Text>}
        <View style={[
          styles.messageBubble,
          isMine ? [styles.myBubble, { backgroundColor: colors.accent }] : [styles.theirBubble, { backgroundColor: theme === 'dark' ? '#333' : '#F0F0F0' }]
        ]}>
          <Text style={[
            styles.messageText,
            { color: isMine ? '#fff' : colors.text }
          ]}>
            {item.text}
          </Text>
          <Text style={[
            styles.timestamp,
            { color: isMine ? 'rgba(255,255,255,0.7)' : '#999' }
          ]}>
            {new Date(item.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
          </Text>
        </View>
      </View>
    );
  };

  if (loading) {
    return (
      <View style={[styles.center, { backgroundColor: colors.background }]}>
        <ActivityIndicator size="large" color={colors.accent} />
      </View>
    );
  }

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: colors.background }]}>
      <Stack.Screen options={{ 
        headerTitle: 'Order Support',
        headerStyle: { backgroundColor: colors.background },
        headerTintColor: colors.text
      }} />
      
      <KeyboardAvoidingView 
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'} 
        style={{ flex: 1 }}
        keyboardVerticalOffset={Platform.OS === 'ios' ? 90 : 0}
      >
        <FlatList
          ref={flatListRef}
          data={messages}
          keyExtractor={(item) => item._id}
          renderItem={renderMessage}
          contentContainerStyle={styles.listContent}
          onContentSizeChange={() => flatListRef.current?.scrollToEnd({ animated: true })}
        />

        <View style={[styles.inputArea, { backgroundColor: colors.card, borderTopColor: theme === 'dark' ? '#333' : '#EEE' }]}>
          <TextInput
            style={[styles.input, { color: colors.text, backgroundColor: theme === 'dark' ? '#222' : '#F9F9F9' }]}
            placeholder="Type a message..."
            placeholderTextColor="#999"
            value={inputText}
            onChangeText={setInputText}
            multiline
          />
          <TouchableOpacity 
            style={[styles.sendBtn, { backgroundColor: colors.accent }]}
            onPress={handleSend}
            disabled={sending || !inputText.trim()}
          >
            {sending ? (
              <ActivityIndicator size="small" color="#fff" />
            ) : (
              <Ionicons name="send" size={20} color="#fff" />
            )}
          </TouchableOpacity>
        </View>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  center: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  listContent: { padding: 20, paddingBottom: 10 },
  messageWrapper: { marginBottom: 15, maxWidth: '80%' },
  myMessageWrapper: { alignSelf: 'flex-end' },
  theirMessageWrapper: { alignSelf: 'flex-start' },
  senderName: { fontSize: 10, color: '#999', marginBottom: 4, marginLeft: 10 },
  messageBubble: { padding: 12, borderRadius: 20 },
  myBubble: { borderBottomRightRadius: 4 },
  theirBubble: { borderBottomLeftRadius: 4 },
  messageText: { fontSize: 15, lineHeight: 20 },
  timestamp: { fontSize: 9, marginTop: 4, textAlign: 'right' },
  inputArea: { flexDirection: 'row', padding: 15, alignItems: 'flex-end', borderTopWidth: 1 },
  input: { flex: 1, borderRadius: 25, paddingHorizontal: 20, paddingVertical: 10, fontSize: 15, maxHeight: 100, marginRight: 10 },
  sendBtn: { width: 50, height: 50, borderRadius: 25, justifyContent: 'center', alignItems: 'center' },
});
