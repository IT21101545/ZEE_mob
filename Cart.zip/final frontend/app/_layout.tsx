import React, { useEffect } from 'react';
import { DarkTheme, DefaultTheme, ThemeProvider as NavigationThemeProvider } from '@react-navigation/native';
import { Stack, useRouter, useSegments } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import 'react-native-reanimated';
import { View, Text, ActivityIndicator } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Colors } from '@/constants/theme';

import { AuthProvider, useAuth } from '../context/AuthContext';
import { ProductProvider } from '../context/ProductContext';
import { CartProvider } from '../context/CartContext';
import { WishlistProvider } from '../context/WishlistContext';
import { ThemeProvider, useAppTheme } from '../context/ThemeContext';
import { OrderProvider } from '../context/OrderContext';
import { SettingsProvider } from '../context/SettingsContext';


export const unstable_settings = {
  anchor: '(tabs)',
};

function RootLayoutNav() {
  const { theme, isDark } = useAppTheme();
  const { user, isLoading } = useAuth();
  const segments = useSegments();
  const router = useRouter();
  const colors = Colors[theme];
  const [appReady, setAppReady] = React.useState(false);

  useEffect(() => {
    // Show splash for at least 3 seconds
    const timer = setTimeout(() => {
      setAppReady(true);
    }, 3000);
    return () => clearTimeout(timer);
  }, []);

  useEffect(() => {
    if (isLoading || !appReady) return;

    const inAuthGroup = segments[0] === '(auth)';
    const inTabsGroup = segments[0] === '(tabs)';
    const currentTab = segments[1];

    if (!user && !inAuthGroup) {
      // Not logged in -> go to login
      router.replace('/(auth)/login');
    } else if (user && inAuthGroup) {
      // Logged in but in auth pages -> redirect to dashboard
      if (user.role === 'admin') {
        router.replace('/(tabs)/admin-dashboard');
      } else {
        router.replace('/(tabs)');
      }
    } else if (user && inTabsGroup) {
      // Role-based access control for tabs
      if (user.role === 'admin') {
        // Admin should not be in customer tabs
        const customerTabs = [undefined, 'index', 'cart'];
        if (customerTabs.includes(currentTab)) {
          router.replace('/(tabs)/admin-dashboard');
        }
      } else {
        // Customer should not be in admin tabs
        const adminTabs = ['admin-dashboard', 'users', 'reviews', 'products'];
        if (adminTabs.includes(currentTab)) {
          router.replace('/(tabs)');
        }
      }
    }
  }, [user, isLoading, segments]);

  if (isLoading || !appReady) {
    return (
      <View style={{ 
        flex: 1, 
        justifyContent: 'center', 
        alignItems: 'center', 
        backgroundColor: isDark ? '#0F0F0F' : '#FFF' 
      }}>
        <View style={{ 
          width: 140, 
          height: 140, 
          borderRadius: 40, 
          backgroundColor: '#D4AF37', 
          justifyContent: 'center', 
          alignItems: 'center',
          shadowColor: '#D4AF37',
          shadowOffset: { width: 0, height: 10 },
          shadowOpacity: 0.5,
          shadowRadius: 20,
          elevation: 20,
          marginBottom: 30
        }}>
          <Ionicons name="diamond" size={70} color="#fff" />
        </View>
        <Text style={{ 
          color: isDark ? '#D4AF37' : '#B8860B', 
          fontSize: 32, 
          fontWeight: '900', 
          letterSpacing: 8,
          textTransform: 'uppercase'
        }}>ZEEFASHION</Text>
        <Text style={{ 
          marginTop: 10, 
          color: isDark ? '#FFF' : '#333', 
          fontSize: 12, 
          letterSpacing: 4,
          opacity: 0.6,
          fontWeight: '300'
        }}>LUXURY TEXTILES</Text>
        <View style={{ marginTop: 50 }}>
          <ActivityIndicator size="small" color="#D4AF37" />
        </View>
      </View>
    );
  }

  return (
    <NavigationThemeProvider value={isDark ? DarkTheme : DefaultTheme}>
      <Stack>
        <Stack.Screen name="(tabs)" options={{ headerShown: false }} />
        <Stack.Screen name="(auth)" options={{ headerShown: false }} />
        <Stack.Screen name="modal" options={{ presentation: 'modal', title: 'Modal' }} />
      </Stack>
      <StatusBar style={isDark ? 'light' : 'dark'} />
    </NavigationThemeProvider>
  );
}


export default function RootLayout() {
  return (
    <AuthProvider>
      <SettingsProvider>
        <ThemeProvider>
          <ProductProvider>
            <CartProvider>
              <WishlistProvider>
                <OrderProvider>
                  <RootLayoutNav />
                </OrderProvider>
              </WishlistProvider>
            </CartProvider>
          </ProductProvider>
        </ThemeProvider>
      </SettingsProvider>
    </AuthProvider>
  );
}

