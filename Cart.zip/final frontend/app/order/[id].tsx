import React, { useEffect, useState } from 'react';
import { 
  View, 
  Text, 
  StyleSheet, 
  ScrollView, 
  TouchableOpacity, 
  ActivityIndicator, 
  Image,
  Dimensions,
  SafeAreaView
} from 'react-native';
import { useLocalSearchParams, useRouter, Stack } from 'expo-router';
import { Ionicons, MaterialIcons } from '@expo/vector-icons';
import { Colors } from '@/constants/theme';
import { useAppTheme } from '../../context/ThemeContext';
import api from '../../api/axios';

const { width } = Dimensions.get('window');

interface OrderItem {
  name: string;
  quantity: number;
  image: string;
  price: number;
  product: string;
}

interface Order {
  _id: string;
  orderItems: OrderItem[];
  shippingAddress: {
    address: string;
    city: string;
    postalCode: string;
  };
  paymentMethod: string;
  totalPrice: number;
  status: string;
  createdAt: string;
  attachment?: string;
}

export default function OrderDetailsScreen() {
  const { id } = useLocalSearchParams();
  const router = useRouter();
  const { theme, isDark } = useAppTheme();
  const colors = Colors[theme];
  
  const [order, setOrder] = useState<Order | null>(null);
  const [unreadCount, setUnreadCount] = useState(0);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const [orderRes, unreadRes] = await Promise.all([
          api.get(`/orders/${id}`),
          api.get('/messages/unread-counts')
        ]);
        setOrder(orderRes.data);
        
        // Find unread count for this order
        const orderUnread = unreadRes.data.find((c: any) => c._id === id);
        if (orderUnread) setUnreadCount(orderUnread.count);
      } catch (error) {
        console.error('Failed to fetch order details', error);
      } finally {
        setLoading(false);
      }
    };
    fetchData();
    const interval = setInterval(fetchData, 10000); // Check for messages every 10s
    return () => clearInterval(interval);
  }, [id]);

  if (loading) {
    return (
      <View style={[styles.center, { backgroundColor: colors.background }]}>
        <ActivityIndicator size="large" color={colors.accent} />
      </View>
    );
  }

  if (!order) {
    return (
      <View style={[styles.center, { backgroundColor: colors.background }]}>
        <Text style={{ color: colors.text }}>Order not found</Text>
      </View>
    );
  }

  const steps = ['Pending', 'Processing', 'Shipped', 'Delivered'];
  const currentStepIndex = steps.indexOf(order.status);

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: colors.background }]}>
      <Stack.Screen options={{ 
        headerTitle: `Order #${order._id.slice(-6).toUpperCase()}`,
        headerStyle: { backgroundColor: colors.background },
        headerTintColor: colors.text
      }} />
      
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingBottom: 40 }}>
        {/* Tracking Bar */}
        <View style={[styles.section, { backgroundColor: colors.card }]}>
          <Text style={[styles.sectionTitle, { color: colors.text }]}>Order Tracking</Text>
          <View style={styles.trackingContainer}>
            {steps.map((step, index) => (
              <React.Fragment key={step}>
                <View style={styles.stepItem}>
                  <View style={[
                    styles.stepCircle, 
                    { backgroundColor: index <= currentStepIndex ? colors.accent : '#E0E0E0' }
                  ]}>
                    {index < currentStepIndex ? (
                      <Ionicons name="checkmark" size={16} color="#fff" />
                    ) : (
                      <Text style={styles.stepNumber}>{index + 1}</Text>
                    )}
                  </View>
                  <Text style={[
                    styles.stepText, 
                    { color: index <= currentStepIndex ? colors.text : '#999', fontWeight: index === currentStepIndex ? 'bold' : 'normal' }
                  ]}>{step}</Text>
                </View>
                {index < steps.length - 1 && (
                  <View style={[
                    styles.stepLine, 
                    { backgroundColor: index < currentStepIndex ? colors.accent : '#E0E0E0' }
                  ]} />
                )}
              </React.Fragment>
            ))}
          </View>
        </View>

        {/* Order Items */}
        <View style={[styles.section, { backgroundColor: colors.card }]}>
          <Text style={[styles.sectionTitle, { color: colors.text }]}>Items</Text>
          {order.orderItems.map((item, idx) => (
            <View key={idx} style={styles.itemRow}>
              <Image source={{ uri: item.image }} style={styles.itemImage} />
              <View style={styles.itemInfo}>
                <Text style={[styles.itemName, { color: colors.text }]}>{item.name}</Text>
                <Text style={styles.itemPrice}>${item.price.toFixed(2)} x {item.quantity}</Text>
              </View>
              <Text style={[styles.itemTotal, { color: colors.text }]}>${(item.price * item.quantity).toFixed(2)}</Text>
            </View>
          ))}
          <View style={[styles.divider, { backgroundColor: theme === 'dark' ? '#333' : '#F0F0F0' }]} />
          <View style={styles.totalRow}>
            <Text style={[styles.totalLabel, { color: colors.text }]}>Total Amount</Text>
            <Text style={[styles.totalValue, { color: colors.accent }]}>${order.totalPrice.toFixed(2)}</Text>
          </View>
        </View>

        {/* Shipping Info */}
        <View style={[styles.section, { backgroundColor: colors.card }]}>
          <Text style={[styles.sectionTitle, { color: colors.text }]}>Shipping Address</Text>
          <View style={styles.infoRow}>
            <Ionicons name="location-outline" size={20} color={colors.accent} />
            <Text style={[styles.infoText, { color: colors.text }]}>{order.shippingAddress.address}</Text>
          </View>
          <View style={styles.infoRow}>
            <Ionicons name="card-outline" size={20} color={colors.accent} />
            <Text style={[styles.infoText, { color: colors.text }]}>Payment: {order.paymentMethod}</Text>
          </View>

          {order.attachment ? (
            <View style={styles.attachmentSection}>
              <Text style={[styles.attachmentTitle, { color: colors.text }]}>Payment Slip (Verification)</Text>
              <Image source={{ uri: order.attachment }} style={styles.attachmentImage} />
            </View>
          ) : null}
        </View>

        {/* Contact Support */}
        <TouchableOpacity 
          style={[styles.supportBtn, { borderColor: colors.accent }]}
          onPress={() => router.push(`/chat/${id}`)}
        >
          <View style={{ position: 'relative' }}>
            <Ionicons name="chatbubble-outline" size={20} color={colors.accent} />
            {unreadCount > 0 && (
              <View style={styles.unreadBadge}>
                <Text style={styles.unreadText}>{unreadCount}</Text>
              </View>
            )}
          </View>
          <Text style={[styles.supportText, { color: colors.accent }]}>Contact Support</Text>
        </TouchableOpacity>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  center: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  section: { margin: 20, padding: 20, borderRadius: 20, shadowColor: '#000', shadowOpacity: 0.05, shadowRadius: 10, elevation: 2 },
  sectionTitle: { fontSize: 18, fontWeight: 'bold', marginBottom: 20 },
  trackingContainer: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingVertical: 10 },
  stepItem: { alignItems: 'center', width: 60 },
  stepCircle: { width: 30, height: 30, borderRadius: 15, justifyContent: 'center', alignItems: 'center', marginBottom: 8 },
  stepNumber: { color: '#fff', fontSize: 12, fontWeight: 'bold' },
  stepText: { fontSize: 10, textAlign: 'center' },
  stepLine: { flex: 1, height: 2, marginBottom: 25 },
  itemRow: { flexDirection: 'row', alignItems: 'center', marginBottom: 15 },
  itemImage: { width: 60, height: 60, borderRadius: 12, marginRight: 15 },
  itemInfo: { flex: 1 },
  itemName: { fontSize: 14, fontWeight: '600' },
  itemPrice: { fontSize: 12, color: '#999', marginTop: 2 },
  itemTotal: { fontSize: 14, fontWeight: 'bold' },
  divider: { height: 1, backgroundColor: '#F0F0F0', marginVertical: 15 },
  totalRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  totalLabel: { fontSize: 16, fontWeight: 'bold' },
  totalValue: { fontSize: 20, fontWeight: 'bold' },
  infoRow: { flexDirection: 'row', alignItems: 'center', marginBottom: 12 },
  infoText: { fontSize: 14, marginLeft: 12, flex: 1 },
  supportBtn: { marginHorizontal: 20, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', padding: 15, borderRadius: 15, borderWidth: 1, borderStyle: 'dashed' },
  supportText: { fontSize: 14, fontWeight: 'bold', marginLeft: 8 },
  unreadBadge: {
    position: 'absolute',
    top: -8,
    right: -8,
    backgroundColor: '#FF3B30',
    borderRadius: 10,
    minWidth: 18,
    height: 18,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 4,
    borderWidth: 1.5,
    borderColor: '#fff'
  },
  unreadText: {
    color: '#fff',
    fontSize: 10,
    fontWeight: 'bold'
  },
  attachmentSection: { marginTop: 20, paddingTop: 15, borderTopWidth: 1, borderTopColor: '#eee' },
  attachmentTitle: { fontSize: 14, fontWeight: 'bold', marginBottom: 10 },
  attachmentImage: { width: '100%', height: 250, borderRadius: 15, resizeMode: 'contain', backgroundColor: '#f9f9f9' },
});
