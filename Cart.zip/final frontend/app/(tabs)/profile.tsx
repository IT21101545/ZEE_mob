import React, { useEffect, useState } from 'react';
import { 
  View, 
  Text, 
  StyleSheet, 
  TouchableOpacity, 
  ScrollView, 
  ActivityIndicator, 
  Alert,
  Dimensions,
  FlatList,
  TextInput
} from 'react-native';
import { Image } from 'expo-image';
import * as ImagePicker from 'expo-image-picker';
import { useAuth } from '../../context/AuthContext';
import { useWishlist } from '../../context/WishlistContext';
import { useProducts } from '../../context/ProductContext';
import { useAppTheme } from '../../context/ThemeContext';
import { useSettings } from '../../context/SettingsContext';
import { translations } from '../../constants/translations';
import { MaterialIcons, Ionicons } from '@expo/vector-icons';
import { Colors } from '@/constants/theme';
import { useRouter } from 'expo-router';
import api from '../../api/axios';

const { width } = Dimensions.get('window');

export default function ProfileScreen() {
  const { user, logout, updateProfile } = useAuth();
  const { wishlist, isLoading: loadingWishlist } = useWishlist();
  const { theme, isDark, toggleTheme } = useAppTheme();
  const { language, setLanguage } = useSettings();
  const router = useRouter();
  const [uploadingAvatar, setUploadingAvatar] = useState(false);
  const [activeTab, setActiveTab] = useState('Settings');
  const [showLanguages, setShowLanguages] = useState(false);
  const [showPrivacy, setShowPrivacy] = useState(false);
  const [showHelp, setShowHelp] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [editData, setEditData] = useState({ name: user?.name || '', phone: user?.phone || '', password: '' });
  const [saving, setSaving] = useState(false);
  
  const colors = Colors[theme];
  const t = translations[language] || translations.English;

  const languages: ('English' | 'Sinhala' | 'Tamil')[] = ['English', 'Sinhala', 'Tamil'];

  const helpContent = [
    { q: 'How do I track my order?', a: 'Go to My Orders and tap on the tracking number provided.' },
    { q: 'What is your return policy?', a: 'We offer a 30-day return policy for unused and unwashed textiles.' },
    { q: 'How can I contact support?', a: 'Email us at support@zeefashion.com or call +94 11 234 5678.' },
    { q: 'Where are you located?', a: 'Our flagship store is in Colombo 07, Sri Lanka.' }
  ];

  useEffect(() => {
    if (user) {
      setEditData({ name: user.name, phone: user.phone || '', password: '' });
    }
  }, [user]);

  const handleUpdateGeneral = async () => {
    setSaving(true);
    try {
      const updatePayload = { ...editData };
      if (!updatePayload.password) delete updatePayload.password;
      await updateProfile(updatePayload);
      setIsEditing(false);
      Alert.alert('Success', 'Profile updated successfully');
    } catch (error: any) {
      Alert.alert('Error', error.response?.data?.message || 'Update failed');
    } finally {
      setSaving(false);
    }
  };

  const pickAvatar = async () => {
    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      allowsEditing: true,
      aspect: [1, 1],
      quality: 0.8,
    });

    if (!result.canceled) {
      setUploadingAvatar(true);
      try {
        const formData = new FormData();
        const asset = result.assets[0];
        const filename = asset.uri.split('/').pop() || 'avatar.jpg';
        const match = /\.(\w+)$/.exec(filename);
        const type = match ? `image/${match[1]}` : `image`;

        formData.append('avatar', {
          uri: asset.uri,
          name: filename,
          type,
        } as any);

        await updateProfile(formData);
        Alert.alert('Success', 'Profile picture updated!');
      } catch (error: any) {
        Alert.alert('Error', error.response?.data?.message || 'Failed to upload image');
      } finally {
        setUploadingAvatar(false);
      }
    }
  };

  return (
    <ScrollView style={[styles.container, { backgroundColor: colors.background }]} showsVerticalScrollIndicator={false}>
      {/* Profile Header */}
      <View style={[styles.header, { backgroundColor: colors.card }]}>
        <View style={styles.avatarWrapper}>
          <TouchableOpacity onPress={pickAvatar} style={[styles.avatarContainer, { borderColor: colors.background }]}>
            {uploadingAvatar ? (
              <ActivityIndicator size="large" color={colors.accent} />
            ) : user?.avatar ? (
              <Image 
                source={{ uri: user.avatar }} 
                style={styles.avatarImage} 
                contentFit="cover"
                transition={500}
              />
            ) : (
              <View style={[styles.avatarPlaceholder, { backgroundColor: colors.accent }]}>
                <Ionicons name="person" size={50} color="#fff" />
              </View>
            )}
            <View style={[styles.editIconBadge, { borderColor: colors.background }]}>
              <MaterialIcons name="camera-alt" size={14} color="#fff" />
            </View>
          </TouchableOpacity>
        </View>
        
        <Text style={[styles.name, { color: colors.text }]}>{user?.name}</Text>
        <Text style={styles.email}>{user?.email}</Text>

        {/* Stats - Hidden for Admin & Wishlist removed */}
        {user?.role !== 'admin' && (
          <View style={styles.statsRow}>
            <View style={styles.statItem}>
              <Text style={[styles.statValue, { color: colors.text }]}>12</Text>
              <Text style={styles.statLabel}>{t.orders}</Text>
            </View>
            <View style={[styles.statDivider, { backgroundColor: colors.border }]} />
            <View style={styles.statItem}>
              <Text style={[styles.statValue, { color: colors.text }]}>5</Text>
              <Text style={styles.statLabel}>{t.coupons}</Text>
            </View>
          </View>
        )}
      </View>

      <View style={styles.settingsSection}>
        <Text style={[styles.sectionTitle, { color: colors.text }]}>{t.settings} & Preferences</Text>
        
        {user?.role === 'admin' && (
          <TouchableOpacity 
            style={[styles.settingItem, { borderBottomColor: colors.border, backgroundColor: colors.accent + '10', borderRadius: 15, paddingHorizontal: 15, marginBottom: 10 }]} 
            onPress={() => router.push('/admin-dashboard')}
          >
            <View style={[styles.iconBox, { backgroundColor: colors.accent }]}>
              <Ionicons name="speedometer-outline" size={20} color="#fff" />
            </View>
            <Text style={[styles.settingText, { color: colors.accent, fontWeight: 'bold' }]}>{t.adminDashboard}</Text>
            <Ionicons name="chevron-forward" size={18} color={colors.accent} />
          </TouchableOpacity>
        )}

        {user?.role !== 'admin' && (
          <TouchableOpacity style={[styles.settingItem, { borderBottomColor: colors.border }]} onPress={() => router.push('/orders')}>
            <View style={[styles.iconBox, { backgroundColor: isDark ? '#1A2E44' : '#E8F0FE' }]}>
              <Ionicons name="receipt-outline" size={20} color="#007AFF" />
            </View>
            <Text style={[styles.settingText, { color: colors.text }]}>{t.orderHistory}</Text>
            <Ionicons name="chevron-forward" size={18} color="#ccc" />
          </TouchableOpacity>
        )}
        
        <TouchableOpacity style={[styles.settingItem, { borderBottomColor: colors.border }]}>
          <View style={[styles.iconBox, { backgroundColor: isDark ? '#441A1A' : '#FEF0F0' }]}>
            <Ionicons name="notifications-outline" size={20} color="#FF3B30" />
          </View>
          <Text style={[styles.settingText, { color: colors.text }]}>{t.notifications}</Text>
          <Ionicons name="chevron-forward" size={18} color="#ccc" />
        </TouchableOpacity>

        <TouchableOpacity style={[styles.settingItem, { borderBottomColor: colors.border }]} onPress={toggleTheme}>
          <View style={[styles.iconBox, { backgroundColor: isDark ? '#2F2D2C' : '#F5F5F5' }]}>
            <Ionicons name={isDark ? "sunny-outline" : "moon-outline"} size={20} color={isDark ? "#D4AF37" : "#666"} />
          </View>
          <Text style={[styles.settingText, { color: colors.text }]}>{isDark ? t.lightMode : t.darkMode}</Text>
          <Ionicons name="chevron-forward" size={18} color="#ccc" />
        </TouchableOpacity>

        {/* Language Selection */}
        <TouchableOpacity style={[styles.settingItem, { borderBottomColor: colors.border }]} onPress={() => setShowLanguages(!showLanguages)}>
          <View style={[styles.iconBox, { backgroundColor: isDark ? '#1A2E44' : '#E8F0FE' }]}>
            <Ionicons name="language-outline" size={20} color="#007AFF" />
          </View>
          <Text style={[styles.settingText, { color: colors.text }]}>{t.language} ({language})</Text>
          <Ionicons name={showLanguages ? "chevron-down" : "chevron-forward"} size={18} color="#ccc" />
        </TouchableOpacity>

        {showLanguages && (
          <View style={[styles.subSection, { backgroundColor: colors.card }]}>
            {languages.map(lang => (
              <TouchableOpacity key={lang} style={styles.subItem} onPress={() => { setLanguage(lang); setShowLanguages(false); }}>
                <Text style={[styles.subText, { color: colors.text, fontWeight: language === lang ? 'bold' : 'normal' }]}>{lang}</Text>
                {language === lang && <Ionicons name="checkmark" size={18} color={colors.accent} />}
              </TouchableOpacity>
            ))}
          </View>
        )}

        {/* Privacy & Security (includes General Info) */}
        <TouchableOpacity style={[styles.settingItem, { borderBottomColor: colors.border }]} onPress={() => setShowPrivacy(!showPrivacy)}>
          <View style={[styles.iconBox, { backgroundColor: isDark ? '#1A442E' : '#F0FEF5' }]}>
            <Ionicons name="shield-checkmark-outline" size={20} color="#34C759" />
          </View>
          <Text style={[styles.settingText, { color: colors.text }]}>{t.privacy}</Text>
          <Ionicons name={showPrivacy ? "chevron-down" : "chevron-forward"} size={18} color="#ccc" />
        </TouchableOpacity>

        {showPrivacy && (
          <View style={[styles.subSection, { backgroundColor: colors.card }]}>
            <View style={styles.generalHeader}>
              <Text style={[styles.generalTitle, { color: colors.text }]}>{t.generalInfo}</Text>
              <TouchableOpacity onPress={() => isEditing ? handleUpdateGeneral() : setIsEditing(true)}>
                {saving ? (
                  <ActivityIndicator size="small" color={colors.accent} />
                ) : (
                  <Ionicons name={isEditing ? "checkmark-circle" : "create-outline"} size={22} color={colors.accent} />
                )}
              </TouchableOpacity>
              {isEditing && (
                <TouchableOpacity onPress={() => setIsEditing(false)} style={{ marginLeft: 15 }}>
                  <Ionicons name="close-circle-outline" size={22} color="#FF3B30" />
                </TouchableOpacity>
              )}
            </View>

            <View style={styles.inputGroup}>
              <Text style={styles.inputLabel}>{t.fullName}</Text>
              {isEditing ? (
                <TextInput 
                  style={[styles.profileInput, { color: colors.text, borderColor: colors.border }]}
                  value={editData.name}
                  onChangeText={(val) => setEditData({...editData, name: val})}
                />
              ) : (
                <Text style={[styles.profileValue, { color: colors.text }]}>{user?.name}</Text>
              )}
            </View>

            <View style={styles.inputGroup}>
              <Text style={styles.inputLabel}>{t.phoneNumber}</Text>
              {isEditing ? (
                <TextInput 
                  style={[styles.profileInput, { color: colors.text, borderColor: colors.border }]}
                  value={editData.phone}
                  onChangeText={(val) => setEditData({...editData, phone: val})}
                  keyboardType="phone-pad"
                  placeholder="Enter phone number"
                  placeholderTextColor="#999"
                />
              ) : (
                <Text style={[styles.profileValue, { color: colors.text }]}>{user?.phone || 'Not set'}</Text>
              )}
            </View>

            {isEditing && (
              <View style={styles.inputGroup}>
                <Text style={styles.inputLabel}>{t.newPassword}</Text>
                <TextInput 
                  style={[styles.profileInput, { color: colors.text, borderColor: colors.border }]}
                  value={editData.password}
                  onChangeText={(val) => setEditData({...editData, password: val})}
                  placeholder="Change password"
                  placeholderTextColor="#999"
                  secureTextEntry
                />
              </View>
            )}
          </View>
        )}

        {/* Help Center */}
        <TouchableOpacity 
          style={[styles.settingItem, { borderBottomColor: colors.border }]} 
          onPress={() => router.push('/support')}
        >
          <View style={[styles.iconBox, { backgroundColor: isDark ? '#442E1A' : '#FEF5F0' }]}>
            <Ionicons name="help-circle-outline" size={20} color="#FF9500" />
          </View>
          <Text style={[styles.settingText, { color: colors.text }]}>{t.help}</Text>
          <Ionicons name="chevron-forward" size={18} color="#ccc" />
        </TouchableOpacity>



        <TouchableOpacity style={[styles.settingItem, { marginTop: 30, borderBottomColor: 'transparent' }]} onPress={logout}>
          <View style={[styles.iconBox, { backgroundColor: isDark ? '#441A1A' : '#FEF0F0' }]}>
            <Ionicons name="log-out-outline" size={20} color="#FF3B30" />
          </View>
          <Text style={[styles.settingText, { color: '#FF3B30', fontWeight: 'bold' }]}>{t.logout}</Text>
        </TouchableOpacity>
      </View>
      <View style={{ height: 100 }} />
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: { 
    paddingTop: 40, 
    paddingBottom: 30, 
    alignItems: 'center',
    borderBottomLeftRadius: 40,
    borderBottomRightRadius: 40,
    shadowColor: '#000',
    shadowOpacity: 0.05,
    shadowRadius: 15,
    elevation: 5
  },
  avatarWrapper: { marginBottom: 15 },
  avatarContainer: { 
    width: 110, 
    height: 110, 
    borderRadius: 55, 
    backgroundColor: '#F5F5F5',
    justifyContent: 'center',
    alignItems: 'center',
    position: 'relative',
    borderWidth: 3,
    shadowColor: '#000',
    shadowOpacity: 0.1,
    shadowRadius: 10,
    elevation: 5
  },
  avatarImage: { width: '100%', height: '100%', borderRadius: 55 },
  avatarPlaceholder: { width: '100%', height: '100%', borderRadius: 55, justifyContent: 'center', alignItems: 'center' },
  editIconBadge: { 
    position: 'absolute', 
    bottom: 0, 
    right: 5, 
    backgroundColor: '#2F2D2C', 
    width: 32, 
    height: 32, 
    borderRadius: 16, 
    justifyContent: 'center', 
    alignItems: 'center',
    borderWidth: 3
  },
  name: { fontSize: 22, fontWeight: 'bold' },
  email: { fontSize: 14, color: '#999', marginTop: 5 },
  statsRow: { flexDirection: 'row', marginTop: 25, width: '80%', justifyContent: 'space-between' },
  statItem: { alignItems: 'center' },
  statValue: { fontSize: 18, fontWeight: 'bold' },
  statLabel: { fontSize: 12, color: '#9B9B9B', marginTop: 2 },
  statDivider: { width: 1, height: 30 },
  sectionTabs: { flexDirection: 'row', paddingHorizontal: 20, marginTop: 20 },
  sectionTab: { paddingVertical: 10, marginRight: 25, borderBottomWidth: 2, borderBottomColor: 'transparent' },
  sectionTabActive: {},
  sectionTabText: { fontSize: 16, color: '#999', fontWeight: '500' },
  sectionTabTextActive: { fontWeight: 'bold' },
  wishlistSection: { padding: 15 },
  wishlistTitle: { fontSize: 18, fontWeight: 'bold', marginLeft: 5, marginBottom: 15 },
  wishlistGrid: { flexDirection: 'row', flexWrap: 'wrap' },
  wishlistCard: { borderRadius: 20, overflow: 'hidden', shadowColor: '#000', shadowOpacity: 0.05, shadowRadius: 5, elevation: 2 },
  wishlistImage: { width: '100%', height: 160, resizeMode: 'cover' },
  wishlistInfo: { padding: 10 },
  wishlistName: { fontSize: 14, fontWeight: 'bold' },
  wishlistPrice: { fontSize: 14, fontWeight: 'bold', marginTop: 2 },
  removeWishlist: { position: 'absolute', top: 10, right: 10, backgroundColor: 'rgba(255,255,255,0.8)', padding: 5, borderRadius: 15 },
  emptyContainer: { alignItems: 'center', marginTop: 50 },
  emptyText: { color: '#999', marginTop: 10 },
  settingsSection: { paddingHorizontal: 20, marginTop: 20 },
  settingItem: { flexDirection: 'row', alignItems: 'center', paddingVertical: 15, borderBottomWidth: 1 },
  iconBox: { width: 40, height: 40, borderRadius: 12, justifyContent: 'center', alignItems: 'center', marginRight: 15 },
  settingText: { flex: 1, fontSize: 16 },
  generalBox: { padding: 20, borderRadius: 25, marginBottom: 20, shadowColor: '#000', shadowOpacity: 0.03, shadowRadius: 10, elevation: 2 },
  generalHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20 },
  generalTitle: { fontSize: 18, fontWeight: 'bold' },
  inputGroup: { marginBottom: 15 },
  sectionTitle: { fontSize: 18, fontWeight: 'bold', marginBottom: 20 },
  subSection: { padding: 15, borderRadius: 20, marginBottom: 15, marginTop: -5 },
  subItem: { flexDirection: 'row', justifyContent: 'space-between', paddingVertical: 12, borderBottomWidth: 0.5, borderBottomColor: '#eee' },
  subText: { fontSize: 15 },
  helpQuestion: { fontSize: 15, fontWeight: 'bold', marginBottom: 5 },
  helpAnswer: { fontSize: 14, color: '#666', lineHeight: 20 },
  inputLabel: { fontSize: 12, color: '#999', marginBottom: 5, textTransform: 'uppercase', letterSpacing: 1 },
  profileValue: { fontSize: 16, fontWeight: '600' },
  profileInput: { borderWidth: 1, borderRadius: 12, paddingHorizontal: 15, paddingVertical: 10, fontSize: 16, marginTop: 5 },
});


