import React from 'react';
import { View, StyleSheet } from 'react-native';
import ProductManagement from '../../components/admin/ProductManagement';

export default function ProductsScreen() {
  return (
    <View style={styles.container}>
      <ProductManagement />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#f4f4f4', padding: 10 }
});
