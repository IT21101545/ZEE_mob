import React, { useEffect, useState } from 'react';
import { 
  View, 
  Text, 
  FlatList, 
  StyleSheet, 
  TouchableOpacity, 
  ActivityIndicator,
  SafeAreaView
} from 'react-native';
import { useOrders } from '../../context/OrderContext';
import { useAuth } from '../../context/AuthContext';
import { useAppTheme } from '../../context/ThemeContext';
import { Colors } from '@/constants/theme';
import { Ionicons, MaterialIcons } from '@expo/vector-icons';
import { useRouter } from 'expo-router';
import api from '../../api/axios';

export default function OrdersScreen() {
  const { orders, isLoading, fetchMyOrders, fetchAllOrders, updateStatus } = useOrders();
  const { user } = useAuth();
  const { theme, isDark } = useAppTheme();
  const router = useRouter();
  const colors = Colors[theme];

  const [activeTab, setActiveTab] = useState('All');
  const isAdmin = user?.role === 'admin';

  useEffect(() => {
    if (isAdmin) {
      fetchAllOrders();
      api.put('/orders/mark-read').catch(err => console.error('Failed to mark orders as read', err));
    } else {
      fetchMyOrders();
    }
  }, [isAdmin]);

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'Pending': return '#FF9500';
      case 'Processing': return '#5856D6';
      case 'Shipped': return '#007AFF';
      case 'Delivered': return '#34C759';
      case 'Cancelled': return '#FF3B30';
      default: return '#999';
    }
  };

  const filteredOrders = activeTab === 'All' 
    ? orders 
    : orders.filter(o => o.status === activeTab);

  const renderOrder = ({ item }: { item: any }) => (
    <TouchableOpacity 
      style={[styles.orderCard, { backgroundColor: colors.card }]}
      onPress={() => router.push(`/order/${item._id}`)}
    >
      <View style={styles.orderHeader}>
        <View>
          <Text style={[styles.orderId, { color: colors.text }]}>Order #{item._id.slice(-6).toUpperCase()}</Text>
          <Text style={styles.orderDate}>{new Date(item.createdAt).toLocaleDateString()}</Text>
        </View>
        <View style={[styles.statusBadge, { backgroundColor: getStatusColor(item.status) + '20' }]}>
          <Text style={[styles.statusText, { color: getStatusColor(item.status) }]}>{item.status}</Text>
        </View>
      </View>

      <View style={styles.orderItems}>
        {item.orderItems?.map((oi: any, idx: number) => (
          <View key={idx} style={styles.itemRow}>
            <Text style={[styles.itemLine, { color: colors.text, flex: 1 }]} numberOfLines={1}>
              {oi.quantity}x {oi.name}
            </Text>
          </View>
        ))}
      </View>

      <View style={[styles.orderFooter, { borderTopColor: colors.border }]}>
        <Text style={[styles.totalLabel, { color: colors.text }]}>Total Amount</Text>
        <Text style={[styles.totalValue, { color: colors.accent }]}>${(item.totalPrice || 0).toFixed(2)}</Text>
      </View>

      {isAdmin && item.status !== 'Delivered' && item.status !== 'Cancelled' && (
        <View style={styles.adminActions}>
          {item.status === 'Pending' && (
            <TouchableOpacity 
              style={[styles.actionBtn, { backgroundColor: '#5856D620' }]}
              onPress={() => updateStatus(item._id, 'Processing')}
            >
              <Text style={{ color: '#5856D6', fontWeight: 'bold', fontSize: 12 }}>Mark Processing</Text>
            </TouchableOpacity>
          )}
          {(item.status === 'Pending' || item.status === 'Processing') && (
            <TouchableOpacity 
              style={[styles.actionBtn, { backgroundColor: '#007AFF20' }]}
              onPress={() => updateStatus(item._id, 'Shipped')}
            >
              <Text style={{ color: '#007AFF', fontWeight: 'bold', fontSize: 12 }}>Mark Shipped</Text>
            </TouchableOpacity>
          )}
          {item.status === 'Shipped' && (
            <TouchableOpacity 
              style={[styles.actionBtn, { backgroundColor: '#34C75920' }]}
              onPress={() => updateStatus(item._id, 'Delivered')}
            >
              <Text style={{ color: '#34C759', fontWeight: 'bold', fontSize: 12 }}>Mark Delivered</Text>
            </TouchableOpacity>
          )}
        </View>
      )}
    </TouchableOpacity>
  );

  const tabs = ['All', 'Pending', 'Processing', 'Shipped', 'Delivered'];

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: colors.background }]}>
      <View style={styles.tabContainer}>
        <FlatList
          horizontal
          showsHorizontalScrollIndicator={false}
          data={tabs}
          keyExtractor={item => item}
          renderItem={({ item }) => (
            <TouchableOpacity 
              style={[
                styles.tab, 
                activeTab === item && { backgroundColor: colors.accent }
              ]}
              onPress={() => setActiveTab(item)}
            >
              <Text style={[
                styles.tabText, 
                { color: activeTab === item ? '#fff' : (isDark ? '#888' : '#666') }
              ]}>{item}</Text>
            </TouchableOpacity>
          )}
          contentContainerStyle={styles.tabList}
        />
      </View>

      <FlatList
        data={filteredOrders}
        keyExtractor={item => item._id}
        renderItem={renderOrder}
        contentContainerStyle={styles.list}
        refreshing={isLoading}
        onRefresh={isAdmin ? fetchAllOrders : fetchMyOrders}
        ListEmptyComponent={
          <View style={styles.empty}>
            <Ionicons name="receipt-outline" size={80} color="#ccc" />
            <Text style={styles.emptyText}>No {activeTab !== 'All' ? activeTab.toLowerCase() : ''} orders found</Text>
          </View>
        }
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  tabContainer: { paddingVertical: 15 },
  tabList: { paddingHorizontal: 20 },
  tab: { paddingHorizontal: 20, paddingVertical: 10, borderRadius: 20, marginRight: 10, backgroundColor: 'rgba(0,0,0,0.05)' },
  tabText: { fontSize: 14, fontWeight: 'bold' },
  list: { padding: 20, paddingTop: 0 },
  orderCard: { borderRadius: 20, padding: 20, marginBottom: 15, shadowColor: '#000', shadowOpacity: 0.05, shadowRadius: 10, elevation: 2 },
  orderHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 15 },
  orderId: { fontSize: 16, fontWeight: 'bold' },
  orderDate: { fontSize: 12, color: '#999', marginTop: 2 },
  statusBadge: { paddingHorizontal: 10, paddingVertical: 5, borderRadius: 8 },
  statusText: { fontSize: 12, fontWeight: 'bold' },
  orderItems: { marginBottom: 15 },
  itemLine: { fontSize: 14, opacity: 0.8 },
  itemRow: { flexDirection: 'row', alignItems: 'center', marginBottom: 6 },
  orderFooter: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingTop: 15, borderTopWidth: 1 },
  totalLabel: { fontSize: 14, fontWeight: '500' },
  totalValue: { fontSize: 18, fontWeight: 'bold' },
  adminActions: { flexDirection: 'row', justifyContent: 'space-between', marginTop: 15 },
  actionBtn: { flex: 1, paddingVertical: 10, borderRadius: 10, alignItems: 'center', marginHorizontal: 5 },
  empty: { flex: 1, justifyContent: 'center', alignItems: 'center', marginTop: 100 },
  emptyText: { color: '#999', fontSize: 16, marginTop: 15 },
});
