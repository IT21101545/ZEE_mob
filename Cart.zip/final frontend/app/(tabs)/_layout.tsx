import { Tabs, useRouter } from 'expo-router';
import React, { useEffect, useState, useCallback } from 'react';
import { TouchableOpacity, View, Text, StyleSheet, Modal, Pressable, ScrollView } from 'react-native';
import { Image } from 'expo-image';
import { MaterialIcons, Ionicons, FontAwesome } from '@expo/vector-icons';
import { Colors } from '@/constants/theme';
import { useAppTheme } from '../../context/ThemeContext';
import { useCart } from '../../context/CartContext';
import { useAuth } from '../../context/AuthContext';
import { useWishlist } from '../../context/WishlistContext';
import api from '../../api/axios';

function Sidebar({ visible, onClose }: { visible: boolean, onClose: () => void }) {
  const { user, logout } = useAuth();
  const { theme, isDark } = useAppTheme();
  const router = useRouter();
  const colors = Colors[theme];

  const menuItems = [
    { name: 'My Profile', icon: 'person-outline', route: '/profile' },
    ...(user?.role !== 'admin' ? [{ name: 'Wishlist', icon: 'heart-outline', route: '/(tabs)/profile' }] : []),
    { name: 'Settings', icon: 'settings-outline', route: '/profile' },
    { name: 'My Orders', icon: 'receipt-outline', route: '/(tabs)/orders' },
    { name: 'Help Center', icon: 'help-circle-outline', route: '/support' },
  ];

  return (
    <Modal
      transparent
      visible={visible}
      animationType="fade"
      onRequestClose={onClose}
    >
      <View style={sidebarStyles.overlay}>
        <Pressable style={sidebarStyles.backdrop} onPress={onClose} />
        <View style={[sidebarStyles.drawer, { backgroundColor: colors.background }]}>
          <View style={sidebarStyles.header}>
            <View style={sidebarStyles.profileInfo}>
              <Image 
                source={{ uri: user?.avatar || 'https://via.placeholder.com/100' }} 
                style={sidebarStyles.avatar}
                contentFit="cover"
                transition={500}
              />
              <View>
                <Text style={[sidebarStyles.userName, { color: colors.text }]}>{user?.name || 'User'}</Text>
                <Text style={sidebarStyles.userEmail}>{user?.email || 'user@example.com'}</Text>
              </View>
            </View>
            <TouchableOpacity onPress={onClose}>
              <Ionicons name="close" size={24} color={colors.text} />
            </TouchableOpacity>
          </View>

          <ScrollView style={sidebarStyles.menuList}>
            {menuItems.map((item, index) => (
              <TouchableOpacity 
                key={index} 
                style={[sidebarStyles.menuItem, { borderBottomColor: colors.border }]}
                onPress={() => {
                  onClose();
                  if (item.route) router.push(item.route as any);
                }}
              >
                <Ionicons name={item.icon as any} size={22} color={colors.text} style={{ marginRight: 15 }} />
                <Text style={[sidebarStyles.menuText, { color: colors.text }]}>{item.name}</Text>
              </TouchableOpacity>
            ))}
          </ScrollView>

          <TouchableOpacity style={sidebarStyles.logoutBtn} onPress={() => { onClose(); logout(); }}>
            <Ionicons name="log-out-outline" size={22} color="#FF3B30" style={{ marginRight: 15 }} />
            <Text style={sidebarStyles.logoutText}>Log Out</Text>
          </TouchableOpacity>
        </View>
      </View>
    </Modal>
  );
}

const sidebarStyles = StyleSheet.create({
  overlay: { flex: 1, flexDirection: 'row' },
  backdrop: { flex: 1, backgroundColor: 'rgba(0,0,0,0.5)' },
  drawer: { width: '80%', padding: 20, paddingTop: 60 },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 30 },
  profileInfo: { flexDirection: 'row', alignItems: 'center' },
  avatar: { width: 60, height: 60, borderRadius: 30, marginRight: 15 },
  userName: { fontSize: 18, fontWeight: 'bold' },
  userEmail: { fontSize: 13, color: '#999' },
  menuList: { flex: 1 },
  menuItem: { flexDirection: 'row', alignItems: 'center', paddingVertical: 15, borderBottomWidth: 1 },
  menuText: { fontSize: 16 },
  logoutBtn: { flexDirection: 'row', alignItems: 'center', marginTop: 20, paddingVertical: 15 },
  logoutText: { fontSize: 16, color: '#FF3B30', fontWeight: 'bold' },
});

function NotificationBell() {
  const [unreadCount, setUnreadCount] = useState(0);
  const { theme } = useAppTheme();
  const router = useRouter();
  const colors = Colors[theme];

  const fetchCount = useCallback(async () => {
    try {
      const res = await api.get('/notifications/unread');
      setUnreadCount(res.data.count);
    } catch (err) {}
  }, []);

  useEffect(() => {
    fetchCount();
    const interval = setInterval(fetchCount, 5000); // Poll every 5s
    return () => clearInterval(interval);
  }, []);

  return (
    <TouchableOpacity
      style={bellStyles.container}
      onPress={() => {
        // Toggle notification bar visibility via parent state
        if (typeof (global as any).toggleNotifications === 'function') {
          (global as any).toggleNotifications();
        }
      }}
    >
      <View style={[bellStyles.iconWrapper, { backgroundColor: colors.card }]}>
        <Ionicons name="notifications-outline" size={24} color={colors.text} />
        {unreadCount > 0 && (
          <View style={bellStyles.badge}>
            <Text style={bellStyles.badgeText}>{unreadCount > 9 ? '9+' : unreadCount}</Text>
          </View>
        )}
      </View>
    </TouchableOpacity>
  );
}

function WishlistBell() {
  const { wishlist } = useWishlist();
  const { theme } = useAppTheme();
  const router = useRouter();
  const colors = Colors[theme];
  const count = wishlist.length;

  return (
    <TouchableOpacity
      style={bellStyles.container}
      onPress={() => router.push('/wishlist')}
    >
      <View style={[bellStyles.iconWrapper, { backgroundColor: colors.card }]}>
        <Ionicons name="heart-outline" size={24} color={colors.text} />
        {count > 0 && (
          <View style={[bellStyles.badge, { backgroundColor: Colors.light.accent }]}>
            <Text style={bellStyles.badgeText}>{count > 9 ? '9+' : count}</Text>
          </View>
        )}
      </View>
    </TouchableOpacity>
  );
}

const bellStyles = StyleSheet.create({
  container: { marginRight: 10 },
  iconWrapper: { padding: 8, borderRadius: 12, position: 'relative' },
  badge: {
    position: 'absolute',
    top: -2,
    right: -2,
    backgroundColor: '#FF3B30',
    borderRadius: 8,
    width: 16,
    height: 16,
    justifyContent: 'center',
    alignItems: 'center',
  },
  badgeText: { color: '#fff', fontSize: 10, fontWeight: 'bold' },
});

export default function TabLayout() {
  const { theme, isDark } = useAppTheme();
  const { cartItems } = useCart();
  const { user } = useAuth();
  const [sidebarVisible, setSidebarVisible] = useState(false);
  const [notifVisible, setNotifVisible] = useState(false);
  const [notifications, setNotifications] = useState<any[]>([]);

  // Expose toggle to NotificationBell
  (global as any).toggleNotifications = () => {
    setNotifVisible(!notifVisible);
    if (!notifVisible) fetchNotifications();
  };

  const fetchNotifications = async () => {
    try {
      const res = await api.get('/notifications');
      // The controller returns { notifications, unreadCount }
      setNotifications(res.data.notifications || []);
      // Mark all as read when opening the bar
      await api.put('/notifications/read-all');
    } catch (err) {
      console.error('Failed to fetch notifications:', err);
    }
  };
  const cartCount = cartItems.reduce((acc, item) => acc + item.quantity, 0);
  const colors = Colors[theme];

  return (
    <>
      <Tabs
        screenOptions={{
          tabBarActiveTintColor: colors.accent,
          tabBarInactiveTintColor: '#9B9B9B',
          headerShown: true,
          headerStyle: { backgroundColor: colors.background, elevation: 0, shadowOpacity: 0 },
          headerTitleStyle: { fontWeight: 'bold', fontSize: 22, color: colors.text },
          tabBarStyle: {
            backgroundColor: colors.card,
            height: 70,
            paddingBottom: 10,
            paddingTop: 5,
            borderTopLeftRadius: 25,
            borderTopRightRadius: 25,
            position: 'absolute',
            left: 0,
            right: 0,
            bottom: 0,
            borderTopWidth: 0,
            elevation: 10,
            shadowColor: '#000',
            shadowOpacity: 0.1,
            shadowRadius: 10,
          },
          headerLeft: () => (
            <TouchableOpacity style={{ marginLeft: 20, backgroundColor: colors.card, padding: 8, borderRadius: 12 }} onPress={() => setSidebarVisible(true)}>
              <Ionicons name="menu-outline" size={24} color={colors.text} />
            </TouchableOpacity>
          ),
          headerRight: () => (
            <View style={{ flexDirection: 'row', alignItems: 'center' }}>
              {user?.role !== 'admin' && <WishlistBell />}
              <NotificationBell />
            </View>
          ),
        }}>
        <Tabs.Screen
          name="index"
          options={{
            href: user?.role === 'admin' ? null : '/',
            title: 'ZEEFASHION',
            tabBarLabel: 'Home',
            tabBarIcon: ({ color, focused }) => (
              <View style={{ alignItems: 'center', borderBottomWidth: focused ? 3 : 0, borderBottomColor: color, paddingBottom: 5, marginTop: 5 }}>
                <Ionicons name={focused ? "home" : "home-outline"} size={24} color={color} />
              </View>
            ),
          }}
        />
        <Tabs.Screen
          name="admin-dashboard"
          options={{
            href: user?.role === 'admin' ? '/admin-dashboard' : null,
            title: 'Dashboard',
            tabBarIcon: ({ color, focused }) => (
              <View style={{ alignItems: 'center', borderBottomWidth: focused ? 3 : 0, borderBottomColor: color, paddingBottom: 5, marginTop: 5 }}>
                <Ionicons name={focused ? "speedometer" : "speedometer-outline"} size={24} color={color} />
              </View>
            ),
          }}
        />
        <Tabs.Screen
          name="cart"
          options={{
            href: user?.role === 'admin' ? null : '/cart',
            title: 'Cart',
            tabBarIcon: ({ color, focused }) => (
              <View style={{ alignItems: 'center', borderBottomWidth: focused ? 3 : 0, borderBottomColor: color, paddingBottom: 5, marginTop: 5 }}>
                <Ionicons name={focused ? "bag" : "bag-outline"} size={24} color={color} />
              </View>
            ),
            tabBarBadge: cartCount > 0 ? cartCount : undefined,
          }}
        />
        <Tabs.Screen
          name="profile"
          options={{
            title: 'Settings',
            tabBarIcon: ({ color, focused }) => (
              <View style={{ alignItems: 'center', borderBottomWidth: focused ? 3 : 0, borderBottomColor: color, paddingBottom: 5, marginTop: 5 }}>
                <Ionicons name={focused ? "grid" : "grid-outline"} size={24} color={color} />
              </View>
            ),
          }}
        />
        {/* Hidden internal tabs for routing purpose */}
        <Tabs.Screen name="products" options={{ href: null }} />
        <Tabs.Screen name="users" options={{ href: null }} />
        <Tabs.Screen name="orders" options={{ href: null }} />
        <Tabs.Screen name="reviews" options={{ href: null }} />
      </Tabs>
      <Sidebar visible={sidebarVisible} onClose={() => setSidebarVisible(false)} />

      {/* Notification Bar Dropdown */}
      {notifVisible && (
        <Pressable style={styles.notifOverlay} onPress={() => setNotifVisible(false)}>
          <View style={[styles.notifBar, { backgroundColor: colors.card }]}>
            <View style={styles.notifHeader}>
              <Text style={[styles.notifTitle, { color: colors.text }]}>Notifications</Text>
              <TouchableOpacity onPress={() => setNotifVisible(false)}>
                <Ionicons name="close" size={20} color={colors.text} />
              </TouchableOpacity>
            </View>
            <ScrollView style={{ maxHeight: 400 }}>
              {(!Array.isArray(notifications) || notifications.length === 0) ? (
                <Text style={styles.emptyNotif}>No new notifications</Text>
              ) : (
                notifications.map((n, i) => (
                  <View key={i} style={[styles.notifItem, { borderBottomColor: colors.border }]}>
                    <View style={[styles.notifIcon, { backgroundColor: colors.accent + '20' }]}>
                      <Ionicons name="notifications" size={16} color={colors.accent} />
                    </View>
                    <View style={{ flex: 1 }}>
                      <Text style={[styles.notifMsg, { color: colors.text }]}>{n.message}</Text>
                      <Text style={styles.notifTime}>{new Date(n.createdAt).toLocaleDateString()}</Text>
                    </View>
                  </View>
                ))
              )}
            </ScrollView>
          </View>
        </Pressable>
      )}
    </>
  );
}

const styles = StyleSheet.create({
  notifOverlay: { position: 'absolute', top: 0, left: 0, right: 0, bottom: 0, backgroundColor: 'rgba(0,0,0,0.2)', zIndex: 999 },
  notifBar: { marginTop: 100, marginHorizontal: 20, borderRadius: 20, padding: 15, shadowColor: '#000', shadowOpacity: 0.1, shadowRadius: 10, elevation: 5 },
  notifHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 15 },
  notifTitle: { fontSize: 18, fontWeight: 'bold' },
  notifItem: { flexDirection: 'row', alignItems: 'center', paddingVertical: 12, borderBottomWidth: 1 },
  notifIcon: { width: 36, height: 36, borderRadius: 18, justifyContent: 'center', alignItems: 'center', marginRight: 12 },
  notifMsg: { fontSize: 14, fontWeight: '500' },
  notifTime: { fontSize: 11, color: '#999', marginTop: 2 },
  emptyNotif: { textAlign: 'center', color: '#999', paddingVertical: 20 },
});


