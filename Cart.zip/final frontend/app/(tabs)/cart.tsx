import React from 'react';
import { View, Text, FlatList, Image, TouchableOpacity, StyleSheet, ActivityIndicator, ScrollView, Dimensions, Modal, TextInput, Alert } from 'react-native';
import { useCart, CartItem } from '../../context/CartContext';
import { useAppTheme } from '../../context/ThemeContext';
import { MaterialIcons, Ionicons } from '@expo/vector-icons';
import { useRouter } from 'expo-router';
import { Colors } from '@/constants/theme';

const { width } = Dimensions.get('window');

export default function CartScreen() {
  const { cartItems, cartTotal, isLoading, updateCartItem, removeFromCart, shippingAddress, setShippingAddress } = useCart();
  const router = useRouter();
  const { theme, isDark } = useAppTheme();
  const colors = Colors[theme];

  const [isEditingAddress, setIsEditingAddress] = React.useState(false);
  const [tempAddress, setTempAddress] = React.useState(shippingAddress);

  const handleRemoveItem = (item: CartItem) => {
    Alert.alert(
      'Remove Item',
      `Do you want to remove "${item.product.name}" from your cart?`,
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Remove',
          style: 'destructive',
          onPress: async () => {
            try {
              await removeFromCart(item.product._id);
              Alert.alert('Removed', `"${item.product.name}" was removed from your cart.`);
            } catch (error) {
              Alert.alert('Error', 'Could not remove item from cart. Please try again.');
            }
          },
        },
      ]
    );
  };

  const deliveryFee = cartItems.length > 0 ? 5.00 : 0;
  const discount = 0;
  const finalTotal = cartTotal + deliveryFee - discount;

  if (isLoading && cartItems.length === 0) {
    return (
      <View style={[styles.center, { backgroundColor: colors.background }]}>
        <ActivityIndicator size="large" color={colors.accent} />
      </View>
    );
  }

  if (cartItems.length === 0) {
    return (
      <View style={[styles.center, { backgroundColor: colors.background }]}>
        <Ionicons name="cart-outline" size={80} color={isDark ? '#444' : '#ccc'} />
        <Text style={[styles.emptyText, { color: isDark ? '#888' : '#999' }]}>Your cart is empty</Text>
        <TouchableOpacity style={[styles.shopButton, { backgroundColor: colors.accent }]} onPress={() => router.push('/(tabs)')}>
          <Text style={styles.shopButtonText}>Explore Products</Text>
        </TouchableOpacity>
      </View>
    );
  }

  const renderItem = ({ item }: { item: CartItem }) => {
    if (!item.product) return null;
    
    return (
      <View style={[styles.cartItem, { backgroundColor: colors.card }]}>
        <Image 
          source={{ uri: item.product.image || 'https://via.placeholder.com/100' }} 
          style={styles.itemImage} 
          contentFit="cover"
        />
        <View style={styles.itemDetails}>
          <Text style={[styles.itemName, { color: colors.text }]} numberOfLines={1}>{item.product.name}</Text>
          <Text style={[styles.itemCategory, { color: isDark ? '#888' : '#999' }]}>Designer Choice</Text>
          <View style={styles.priceRow}>
            <Text style={[styles.itemPrice, { color: colors.accent }]}>${item.product.price?.toFixed(2)}</Text>
            <View style={[styles.quantityControl, { backgroundColor: isDark ? colors.background : '#F5F5F5', borderRadius: 12, padding: 4 }]}>
              <TouchableOpacity 
                style={[styles.qtyBtn, { borderColor: isDark ? '#444' : '#EAEAEA' }]} 
                onPress={() => updateCartItem(item.product._id, Math.max(1, item.quantity - 1))}
              >
                <Ionicons name="remove" size={16} color={colors.text} />
              </TouchableOpacity>
              <Text style={[styles.qtyText, { color: colors.text }]}>{item.quantity}</Text>
              <TouchableOpacity 
                style={[styles.qtyBtn, { borderColor: isDark ? '#444' : '#EAEAEA' }]} 
                onPress={() => updateCartItem(item.product._id, Math.min(item.product.stock || 99, item.quantity + 1))}
              >
                <Ionicons name="add" size={16} color={colors.text} />
              </TouchableOpacity>
            </View>
          </View>
        </View>
        <TouchableOpacity style={styles.deleteBtn} onPress={() => handleRemoveItem(item)}>
          <Ionicons name="trash-outline" size={18} color="#FF3B30" />
        </TouchableOpacity>
      </View>
    );
  };

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingBottom: 160 }}>
        {/* Delivery Address Mock */}
        <View style={[styles.addressCard, { backgroundColor: colors.card }]}>
          <View style={styles.addressHeader}>
            <Text style={[styles.addressTitle, { color: colors.text }]}>Delivery Address</Text>
            <TouchableOpacity onPress={() => setIsEditingAddress(true)}>
              <Text style={[styles.editBtn, { color: colors.accent }]}>Edit</Text>
            </TouchableOpacity>
          </View>
          <View style={styles.addressInfo}>
            <View style={[styles.addressIconBox, { backgroundColor: isDark ? colors.background : '#FDF5F0' }]}>
              <Ionicons name="location-outline" size={20} color={colors.accent} />
            </View>
            <View style={{ flex: 1 }}>
              <Text style={[styles.addressText, { color: colors.text }]} numberOfLines={1}>{shippingAddress.address}</Text>
              <Text style={[styles.addressSub, { color: isDark ? '#888' : '#999' }]}>{shippingAddress.city}, {shippingAddress.postalCode}</Text>
            </View>
          </View>
        </View>

        <View style={styles.listContainer}>
          {cartItems.map((item, index) => (
            <View key={item.product?._id || index}>
              {renderItem({ item })}
            </View>
          ))}
        </View>

        {/* Payment Summary */}
        <View style={[styles.summaryContainer, { backgroundColor: colors.card }]}>
          <Text style={[styles.summaryTitle, { color: colors.text }]}>Order Summary</Text>
          <View style={styles.summaryRow}>
            <Text style={styles.summaryLabel}>Subtotal</Text>
            <Text style={[styles.summaryValue, { color: colors.text }]}>${cartTotal.toFixed(2)}</Text>
          </View>
          <View style={styles.summaryRow}>
            <Text style={styles.summaryLabel}>Delivery Fee</Text>
            <Text style={[styles.summaryValue, { color: colors.text }]}>${deliveryFee.toFixed(2)}</Text>
          </View>
          <View style={styles.summaryRow}>
            <Text style={styles.summaryLabel}>Discount</Text>
            <Text style={[styles.summaryValue, { color: colors.text }]}>-${discount.toFixed(2)}</Text>
          </View>
          <View style={[styles.summaryRow, { marginTop: 10, paddingTop: 10, borderTopWidth: 1, borderTopColor: colors.border }]}>
            <Text style={[styles.summaryLabel, { fontWeight: 'bold', color: colors.text }]}>Total Payment</Text>
            <Text style={[styles.summaryValue, { fontWeight: 'bold', color: colors.accent, fontSize: 18 }]}>${finalTotal.toFixed(2)}</Text>
          </View>
        </View>
      </ScrollView>

      {/* Bottom Bar */}
      <View style={[styles.bottomBar, { backgroundColor: colors.card, borderTopColor: colors.border, borderTopWidth: isDark ? 1 : 0 }]}>
        <View style={[styles.totalBox, { backgroundColor: isDark ? colors.background : '#F9F9F9' }]}>
          <Ionicons name="wallet-outline" size={24} color={colors.accent} />
          <View style={{ marginLeft: 10 }}>
            <Text style={[styles.cashLabel, { color: isDark ? '#888' : '#999' }]}>Total Payment</Text>
            <Text style={[styles.cashValue, { color: colors.text }]}>$ {finalTotal.toFixed(2)}</Text>
          </View>
          <Ionicons name="chevron-down" size={18} color="#999" style={{ marginLeft: 'auto' }} />
        </View>
        <TouchableOpacity style={[styles.orderBtn, { backgroundColor: colors.text }]} onPress={() => router.push('/checkout')}>
          <Text style={[styles.orderBtnText, { color: colors.background }]}>Checkout Now</Text>
        </TouchableOpacity>
      </View>

      {/* Address Edit Modal */}
      <Modal visible={isEditingAddress} transparent animationType="slide">
        <View style={styles.modalOverlay}>
          <View style={[styles.modalContent, { backgroundColor: colors.card }]}>
            <Text style={[styles.modalTitle, { color: colors.text }]}>Edit Delivery Address</Text>
            
            <Text style={styles.modalLabel}>Address</Text>
            <TextInput 
              style={[styles.modalInput, { color: colors.text, borderColor: colors.border }]} 
              value={tempAddress.address} 
              onChangeText={(val) => setTempAddress({...tempAddress, address: val})}
              placeholder="Enter full address"
            />

            <View style={{ flexDirection: 'row', gap: 10 }}>
              <View style={{ flex: 1 }}>
                <Text style={styles.modalLabel}>City</Text>
                <TextInput 
                  style={[styles.modalInput, { color: colors.text, borderColor: colors.border }]} 
                  value={tempAddress.city} 
                  onChangeText={(val) => setTempAddress({...tempAddress, city: val})}
                />
              </View>
              <View style={{ flex: 1 }}>
                <Text style={styles.modalLabel}>Postal Code</Text>
                <TextInput 
                  style={[styles.modalInput, { color: colors.text, borderColor: colors.border }]} 
                  value={tempAddress.postalCode} 
                  onChangeText={(val) => setTempAddress({...tempAddress, postalCode: val})}
                  keyboardType="numeric"
                />
              </View>
            </View>

            <View style={styles.modalActions}>
              <TouchableOpacity style={styles.cancelBtn} onPress={() => setIsEditingAddress(false)}>
                <Text style={{ color: '#999' }}>Cancel</Text>
              </TouchableOpacity>
              <TouchableOpacity 
                style={[styles.saveBtn, { backgroundColor: colors.accent }]} 
                onPress={() => { setShippingAddress(tempAddress); setIsEditingAddress(false); }}
              >
                <Text style={{ color: '#fff', fontWeight: 'bold' }}>Save Address</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#F9F9F9' },
  center: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  emptyText: { fontSize: 18, color: '#999', marginTop: 15, marginBottom: 25 },
  shopButton: { backgroundColor: Colors.light.accent, paddingHorizontal: 30, paddingVertical: 14, borderRadius: 20 },
  shopButtonText: { color: '#fff', fontSize: 16, fontWeight: 'bold' },
  addressCard: { backgroundColor: '#fff', padding: 20, margin: 20, borderRadius: 20, shadowColor: '#000', shadowOpacity: 0.03, shadowRadius: 10, elevation: 2 },
  addressHeader: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 15 },
  addressTitle: { fontSize: 16, fontWeight: 'bold', color: '#2F2D2C' },
  editBtn: { color: Colors.light.accent, fontWeight: '500' },
  addressInfo: { flexDirection: 'row', alignItems: 'center' },
  addressIconBox: { width: 40, height: 40, borderRadius: 12, backgroundColor: '#FDF5F0', justifyContent: 'center', alignItems: 'center', marginRight: 15 },
  addressText: { fontSize: 14, fontWeight: 'bold', color: '#2F2D2C' },
  addressSub: { fontSize: 12, color: '#999', marginTop: 2 },
  listContainer: { paddingHorizontal: 20 },
  cartItem: { flexDirection: 'row', backgroundColor: '#fff', borderRadius: 20, padding: 12, marginBottom: 15, alignItems: 'center' },
  itemImage: { width: 80, height: 80, borderRadius: 15, backgroundColor: '#F5F5F5' },
  itemDetails: { flex: 1, marginLeft: 15 },
  itemName: { fontSize: 16, fontWeight: 'bold', color: '#2F2D2C' },
  itemCategory: { fontSize: 12, color: '#999', marginTop: 2 },
  priceRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginTop: 10 },
  itemPrice: { fontSize: 16, fontWeight: 'bold', color: Colors.light.accent },
  quantityControl: { flexDirection: 'row', alignItems: 'center' },
  qtyBtn: { width: 28, height: 28, borderRadius: 14, borderWidth: 1, borderColor: '#EAEAEA', justifyContent: 'center', alignItems: 'center' },
  qtyText: { fontSize: 14, fontWeight: 'bold', marginHorizontal: 10, minWidth: 20, textAlign: 'center' },
  deleteBtn: { padding: 8 },
  summaryContainer: { backgroundColor: '#fff', margin: 20, padding: 20, borderRadius: 20 },
  summaryTitle: { fontSize: 16, fontWeight: 'bold', color: '#2F2D2C', marginBottom: 15 },
  summaryRow: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 8 },
  summaryLabel: { color: '#999', fontSize: 14 },
  summaryValue: { color: '#2F2D2C', fontSize: 14, fontWeight: '600' },
  bottomBar: { 
    position: 'absolute', 
    bottom: 90, 
    width: width, 
    backgroundColor: '#fff', 
    padding: 20, 
    paddingBottom: 35,
    borderTopLeftRadius: 30,
    borderTopRightRadius: 30,
    shadowColor: '#000',
    shadowOpacity: 0.1,
    shadowRadius: 15,
    elevation: 10
  },
  totalBox: { flexDirection: 'row', alignItems: 'center', backgroundColor: '#F9F9F9', padding: 12, borderRadius: 15, marginBottom: 15 },
  cashLabel: { fontSize: 12, color: '#999' },
  cashValue: { fontSize: 14, fontWeight: 'bold', color: '#2F2D2C' },
  orderBtn: {
    backgroundColor: Colors.light.accent,
    padding: 18,
    borderRadius: 20,
    alignItems: 'center'
  },
  orderBtnText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: 'bold'
  },
  modalOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'flex-end' },
  modalContent: { padding: 25, borderTopLeftRadius: 30, borderTopRightRadius: 30 },
  modalTitle: { fontSize: 20, fontWeight: 'bold', marginBottom: 20 },
  modalLabel: { fontSize: 12, color: '#999', marginBottom: 5, marginTop: 10 },
  modalInput: { borderWidth: 1, borderRadius: 12, padding: 12, fontSize: 16, marginBottom: 10 },
  modalActions: { flexDirection: 'row', justifyContent: 'flex-end', marginTop: 20, gap: 15 },
  cancelBtn: { padding: 12 },
  saveBtn: { paddingHorizontal: 25, paddingVertical: 12, borderRadius: 12 },
});

