import React from 'react';
import { View, StyleSheet } from 'react-native';
import UserManagement from '../../components/admin/UserManagement';

export default function UsersScreen() {
  return (
    <View style={styles.container}>
      <UserManagement />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#f4f4f4', padding: 10 }
});
