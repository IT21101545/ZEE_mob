import React from 'react';
import { 
  View, 
  Text, 
  StyleSheet, 
  TouchableOpacity, 
  ScrollView, 
  SafeAreaView,
  Dimensions,
  Image,
  ActivityIndicator
} from 'react-native';
import { useRouter } from 'expo-router';
import { useAppTheme } from '../../context/ThemeContext';
import { useAuth } from '../../context/AuthContext';
import { Colors } from '@/constants/theme';
import { Ionicons, MaterialIcons } from '@expo/vector-icons';
import api from '../../api/axios';

const { width } = Dimensions.get('window');

import { useFocusEffect } from 'expo-router';

export default function AdminDashboard() {
  const { theme, isDark } = useAppTheme();
  const { logout, user } = useAuth();
  const router = useRouter();
  const colors = Colors[theme];

  const [stats, setStats] = React.useState({
    orderCount: 0,
    productCount: 0,
    userCount: 0,
    unreadOrdersCount: 0,
    unreadReviewsCount: 0,
    unreadMessagesCount: 0,
    totalRevenue: '0.00'
  });
  const [loading, setLoading] = React.useState(true);

  const fetchStats = async () => {
    try {
      const { data } = await api.get('/orders/stats');
      setStats(data);
    } catch (err) {
      console.error('Failed to fetch admin stats', err);
    } finally {
      setLoading(false);
    }
  };

  useFocusEffect(
    React.useCallback(() => {
      fetchStats();
    }, [])
  );

  const adminModules = [
    { name: 'Products', icon: 'inventory', color: '#FF9500', route: '/(tabs)/products', description: 'Manage Catalog' },
    { 
      name: 'Orders', 
      icon: 'receipt', 
      color: '#007AFF', 
      route: '/(tabs)/orders', 
      description: 'Track Sales',
      badge: stats.unreadOrdersCount
    },
    { name: 'Users', icon: 'people', color: '#34C759', route: '/(tabs)/users', description: 'User Accounts' },
    { 
      name: 'Reviews', 
      icon: 'star', 
      color: '#FFCC00', 
      route: '/(tabs)/reviews', 
      description: 'Customer Feedback',
      badge: stats.unreadReviewsCount
    },
    { 
      name: 'Support', 
      icon: 'chat', 
      color: '#5856D6', 
      route: '/(tabs)/orders', // Admin usually goes to orders to chat
      description: 'Customer Chat',
      badge: stats.unreadMessagesCount
    },
    { name: 'Settings', icon: 'settings', color: '#8E8E93', route: '/profile', description: 'System Config' },
  ];

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: colors.background }]}>
      <View style={styles.header}>
        <View style={styles.headerLeft}>
          {user?.avatar ? (
            <Image source={{ uri: user.avatar }} style={styles.headerAvatar} />
          ) : (
            <View style={[styles.headerAvatarPlaceholder, { backgroundColor: colors.accent }]}>
              <Ionicons name="person" size={24} color="#fff" />
            </View>
          )}
          <View>
            <Text style={[styles.greeting, { color: colors.text }]}>Admin Panel</Text>
            <Text style={styles.subGreeting}>Welcome back, {user?.name}</Text>
          </View>
        </View>
        <TouchableOpacity style={styles.logoutBtn} onPress={logout}>
          <Ionicons name="log-out-outline" size={24} color="#FF3B30" />
        </TouchableOpacity>
      </View>

      <ScrollView contentContainerStyle={styles.content}>
        <View style={styles.grid}>
          {adminModules.map((module, index) => (
            <TouchableOpacity 
              key={index} 
              style={[styles.card, { backgroundColor: colors.card }]}
              onPress={() => router.push(module.route as any)}
            >
              {(module as any).badge > 0 && (
                <View style={styles.badge}>
                  <Text style={styles.badgeText}>{(module as any).badge}</Text>
                </View>
              )}
              <View style={[styles.iconBox, { backgroundColor: module.color + '20' }]}>
                <MaterialIcons name={module.icon as any} size={32} color={module.color} />
              </View>
              <Text style={[styles.moduleName, { color: colors.text }]}>{module.name}</Text>
              <Text style={styles.moduleDesc}>{module.description}</Text>
            </TouchableOpacity>
          ))}
        </View>

        {/* Stats Summary */}
        <View style={[styles.statsSection, { backgroundColor: colors.card }]}>
          <Text style={[styles.statsTitle, { color: colors.text }]}>Quick Stats</Text>
          {loading ? (
            <ActivityIndicator color={colors.accent} />
          ) : (
            <View style={styles.statsRow}>
              <View style={styles.statItem}>
                <Text style={styles.statValue}>{stats.productCount}</Text>
                <Text style={styles.statLabel}>Products</Text>
              </View>
              <View style={styles.statItem}>
                <Text style={styles.statValue}>{stats.orderCount}</Text>
                <Text style={styles.statLabel}>Orders</Text>
              </View>
              <View style={styles.statItem}>
                <Text style={styles.statValue}>${stats.totalRevenue}</Text>
                <Text style={styles.statLabel}>Revenue</Text>
              </View>
            </View>
          )}
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', padding: 25, paddingTop: 40 },
  headerLeft: { flexDirection: 'row', alignItems: 'center' },
  headerAvatar: { width: 50, height: 50, borderRadius: 25, marginRight: 15 },
  headerAvatarPlaceholder: { width: 50, height: 50, borderRadius: 25, marginRight: 15, justifyContent: 'center', alignItems: 'center' },
  greeting: { fontSize: 24, fontWeight: 'bold' },
  subGreeting: { fontSize: 14, color: '#999', marginTop: 5 },
  logoutBtn: { padding: 10, borderRadius: 12, backgroundColor: 'rgba(255,59,48,0.1)' },
  content: { padding: 20 },
  grid: { flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'space-between' },
  card: { 
    width: (width - 60) / 2, 
    borderRadius: 25, 
    padding: 20, 
    marginBottom: 20,
    shadowColor: '#000',
    shadowOpacity: 0.05,
    shadowRadius: 10,
    elevation: 2,
    alignItems: 'center'
  },
  iconBox: { width: 60, height: 60, borderRadius: 20, justifyContent: 'center', alignItems: 'center', marginBottom: 15 },
  badge: {
    position: 'absolute',
    top: 15,
    right: 15,
    backgroundColor: '#FF3B30',
    borderRadius: 12,
    minWidth: 24,
    height: 24,
    justifyContent: 'center',
    alignItems: 'center',
    zIndex: 1,
    paddingHorizontal: 6,
    borderWidth: 2,
    borderColor: '#fff'
  },
  badgeText: {
    color: '#fff',
    fontSize: 12,
    fontWeight: 'bold'
  },
  moduleName: { fontSize: 18, fontWeight: 'bold' },
  moduleDesc: { fontSize: 12, color: '#999', marginTop: 4 },
  statsSection: { borderRadius: 25, padding: 25, marginTop: 10 },
  statsTitle: { fontSize: 18, fontWeight: 'bold', marginBottom: 20 },
  statsRow: { flexDirection: 'row', justifyContent: 'space-between' },
  statItem: { alignItems: 'center' },
  statValue: { fontSize: 20, fontWeight: 'bold', color: '#D4AF37' },
  statLabel: { fontSize: 12, color: '#999', marginTop: 5 },
});
