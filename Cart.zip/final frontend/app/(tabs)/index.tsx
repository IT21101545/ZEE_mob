import React, { useState, useCallback } from 'react';
import { 
  View, 
  Text, 
  FlatList, 
  TouchableOpacity, 
  StyleSheet, 
  ActivityIndicator, 
  Alert, 
  TextInput, 
  ScrollView, 
  RefreshControl,
  Dimensions,
  SafeAreaView,
  Modal
} from 'react-native';
import { Image } from 'expo-image';
import { useRouter } from 'expo-router';
import { useProducts } from '../../context/ProductContext';
import { useCart } from '../../context/CartContext';
import { useWishlist } from '../../context/WishlistContext';
import { useAuth } from '../../context/AuthContext';
import { useAppTheme } from '../../context/ThemeContext';
import { MaterialIcons, Ionicons } from '@expo/vector-icons';
import { Colors } from '@/constants/theme';

const { width } = Dimensions.get('window');

const CATEGORIES = ['All Items', 'Latest Arrivals', 'Classic Black', 'Winter Wear', 'Summer Mix'];

export default function ShopScreen() {
  const { products, isLoading, fetchProducts } = useProducts();
  const { addToCart } = useCart();
  const { toggleWishlist, isInWishlist } = useWishlist();
  const { theme, isDark } = useAppTheme();
  const router = useRouter();
  const [search, setSearch] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All Items');
  const [priceRange, setPriceRange] = useState([0, 1000]);
  const [selectedSizes, setSelectedSizes] = useState<string[]>([]);
  const [filterVisible, setFilterVisible] = useState(false);
  const [refreshing, setRefreshing] = useState(false);
  
  const colors = Colors[theme];
  const { user } = useAuth();

  React.useEffect(() => {
    if (user?.role === 'admin') {
      router.replace('/(tabs)/admin-dashboard');
    }
  }, [user]);

  const onRefresh = useCallback(async () => {
    setRefreshing(true);
    await fetchProducts();
    setRefreshing(false);
  }, []);

  const filteredProducts = products.filter(p => {
    const matchesSearch = p.name.toLowerCase().includes(search.toLowerCase());
    const matchesCategory = selectedCategory === 'All Items' || p.category === selectedCategory;
    const matchesPrice = p.price >= priceRange[0] && p.price <= priceRange[1];
    // Assuming products have a 'sizes' array. If not, we skip size filter or check if it exists.
    const matchesSize = selectedSizes.length === 0 || (p as any).sizes?.some((s: string) => selectedSizes.includes(s));
    
    return matchesSearch && matchesCategory && matchesPrice && matchesSize;
  });

  const exclusiveProducts = filteredProducts.slice(0, 4);
  const otherProducts = filteredProducts.slice(4);

  const renderProductCard = ({ item, horizontal = false }: { item: any, horizontal?: boolean }) => (
    <TouchableOpacity
      style={[styles.card, horizontal && styles.horizontalCard, { backgroundColor: colors.card }]}
      onPress={() => router.push(`/product/${item._id}`)}
    >
      <View style={styles.imageContainer}>
        <Image
          source={{ uri: item.image || 'https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?q=80&w=400&auto=format&fit=crop' }}
          style={styles.image}
          contentFit="cover"
          transition={500}
        />
        <TouchableOpacity 
          style={styles.heartButton}
          onPress={() => toggleWishlist(item._id)}
        >
          <Ionicons 
            name={isInWishlist(item._id) ? "heart" : "heart-outline"} 
            size={18} 
            color={isInWishlist(item._id) ? colors.accent : "#333"} 
          />
        </TouchableOpacity>
      </View>
      <View style={styles.info}>
        <Text style={[styles.name, { color: colors.text }]} numberOfLines={1}>{item.name}</Text>
        <Text style={styles.brand}>ZEEFASHION Exclusive</Text>
        <View style={styles.priceRow}>
          <Text style={[styles.price, { color: colors.text }]}>${item.price.toFixed(2)}</Text>
          <View style={styles.colorDots}>
            <View style={[styles.dot, { backgroundColor: '#2F2D2C' }]} />
            <View style={[styles.dot, { backgroundColor: '#EAEAEA' }]} />
            <View style={[styles.dot, { backgroundColor: colors.accent }]} />
          </View>
        </View>
      </View>
    </TouchableOpacity>
  );

  if (isLoading && products.length === 0) {
    return (
      <View style={[styles.center, { backgroundColor: colors.background, flex: 1, justifyContent: 'center', alignItems: 'center' }]}>
        <ActivityIndicator size="large" color={colors.accent} />
        <Text style={{ marginTop: 15, color: colors.text, opacity: 0.6 }}>Curating your collection...</Text>
      </View>
    );
  }

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: colors.background }]}>
      <ScrollView 
        showsVerticalScrollIndicator={false}
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={colors.accent} />
        }
      >
        <View style={styles.content}>
          <View style={styles.locationContainer}>
            <Ionicons name="location-outline" size={16} color="#999" />
            <Text style={styles.locationText}>ZEEFASHION Headquarters, Midtown - USA</Text>
            <Ionicons name="chevron-down" size={14} color="#999" />
          </View>

          <View style={styles.searchRow}>
            <View style={[styles.searchBar, { backgroundColor: colors.card }]}>
              <Ionicons name="search" size={20} color="#999" />
              <TextInput 
                placeholder="Explore Luxury Wear" 
                placeholderTextColor="#999"
                style={[styles.searchInput, { color: colors.text }]}
                value={search}
                onChangeText={setSearch}
              />
            </View>
            <TouchableOpacity 
              style={[styles.filterButton, { backgroundColor: colors.accent }]}
              onPress={() => setFilterVisible(true)}
            >
              <Ionicons name="options-outline" size={20} color="#fff" />
            </TouchableOpacity>
          </View>

          <View style={[styles.banner, { backgroundColor: isDark ? '#2F2D2C' : '#EAE0D5' }]}>
            <View style={styles.bannerTextContainer}>
              <Text style={styles.bannerDate}>Limited Season Offer</Text>
              <Text style={[styles.bannerTitle, { color: isDark ? '#fff' : '#2F2D2C' }]}>Flat 25% Off Premium Collection</Text>
              <TouchableOpacity style={[styles.bannerBtn, { backgroundColor: isDark ? colors.accent : '#2F2D2C' }]}>
                <Text style={styles.bannerBtnText}>Claim Offer</Text>
              </TouchableOpacity>
            </View>
            <Image 
              source={{ uri: 'https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?q=80&w=1000&auto=format&fit=crop' }} 
              style={styles.bannerImage} 
              contentFit="cover"
              transition={1000}
            />
          </View>

          <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.categoryScroll}>
            {CATEGORIES.map(cat => (
              <TouchableOpacity 
                key={cat} 
                style={[
                  styles.categoryChip, 
                  { backgroundColor: colors.card, borderColor: colors.border },
                  selectedCategory === cat && [styles.categoryChipActive, { backgroundColor: colors.accent, borderColor: colors.accent }]
                ]}
                onPress={() => setSelectedCategory(cat)}
              >
                <Text style={[styles.categoryChipText, selectedCategory === cat && styles.categoryChipTextActive]}>
                  {cat}
                </Text>
              </TouchableOpacity>
            ))}
          </ScrollView>

          <View style={styles.sectionHeader}>
            <Text style={[styles.sectionTitle, { color: colors.text }]}>Featured Styles</Text>
            <TouchableOpacity>
              <Text style={styles.seeAllText}>Explore All</Text>
            </TouchableOpacity>
          </View>

          <FlatList 
            data={exclusiveProducts}
            horizontal
            showsHorizontalScrollIndicator={false}
            keyExtractor={item => item._id}
            renderItem={({ item }) => renderProductCard({ item, horizontal: true })}
            contentContainerStyle={styles.horizontalList}
          />

          <View style={styles.sectionHeader}>
            <Text style={[styles.sectionTitle, { color: colors.text }]}>Curated For You</Text>
            <TouchableOpacity>
              <Text style={styles.seeAllText}>View All</Text>
            </TouchableOpacity>
          </View>

          <View style={styles.grid}>
            {otherProducts.length > 0 ? otherProducts.map(item => (
              <View key={item._id} style={styles.gridItem}>
                {renderProductCard({ item })}
              </View>
            )) : (
              <View style={styles.emptyContainer}>
                <Ionicons name="shirt-outline" size={50} color="#ccc" />
                <Text style={styles.noData}>Discovering new styles...</Text>
              </View>
            )}
          </View>
        </View>
        <View style={{ height: 80 }} />
      </ScrollView>

      {/* Filter Modal */}
      <Modal
        visible={filterVisible}
        animationType="slide"
        transparent
        onRequestClose={() => setFilterVisible(false)}
      >
        <View style={styles.modalOverlay}>
          <View style={[styles.modalContent, { backgroundColor: colors.background }]}>
            <View style={styles.modalHeader}>
              <Text style={[styles.modalTitle, { color: colors.text }]}>Refine Search</Text>
              <TouchableOpacity onPress={() => setFilterVisible(false)}>
                <Ionicons name="close" size={24} color={colors.text} />
              </TouchableOpacity>
            </View>

            <ScrollView showsVerticalScrollIndicator={false}>
              <Text style={[styles.filterLabel, { color: colors.text }]}>Price Range (Up to)</Text>
              <View style={styles.priceRowModal}>
                <Text style={{ color: colors.text }}>$0</Text>
                <Text style={{ color: colors.accent, fontWeight: 'bold' }}>${priceRange[1]}</Text>
              </View>
              <TextInput 
                style={[styles.priceInput, { color: colors.text, borderColor: colors.border }]}
                keyboardType="numeric"
                value={priceRange[1].toString()}
                onChangeText={(val) => setPriceRange([0, parseInt(val) || 0])}
                placeholder="Max Price"
              />

              <Text style={[styles.filterLabel, { color: colors.text, marginTop: 25 }]}>Available Sizes</Text>
              <View style={styles.sizeRow}>
                {['S', 'M', 'L', 'XL', 'XXL'].map(size => {
                  const isSelected = selectedSizes.includes(size);
                  return (
                    <TouchableOpacity 
                      key={size}
                      style={[
                        styles.sizeChip, 
                        { borderColor: colors.border },
                        isSelected && { backgroundColor: colors.accent, borderColor: colors.accent }
                      ]}
                      onPress={() => {
                        if (isSelected) setSelectedSizes(selectedSizes.filter(s => s !== size));
                        else setSelectedSizes([...selectedSizes, size]);
                      }}
                    >
                      <Text style={[styles.sizeText, isSelected && { color: '#fff' }]}>{size}</Text>
                    </TouchableOpacity>
                  );
                })}
              </View>

              <TouchableOpacity 
                style={[styles.applyBtn, { backgroundColor: colors.accent }]}
                onPress={() => setFilterVisible(false)}
              >
                <Text style={styles.applyBtnText}>Apply Filters</Text>
              </TouchableOpacity>

              <TouchableOpacity 
                style={styles.resetBtn}
                onPress={() => {
                  setSelectedCategory('All Items');
                  setPriceRange([0, 1000]);
                  setSelectedSizes([]);
                }}
              >
                <Text style={[styles.resetBtnText, { color: colors.accent }]}>Reset All</Text>
              </TouchableOpacity>
            </ScrollView>
          </View>
        </View>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  content: { paddingVertical: 10 },
  locationContainer: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 20, marginBottom: 15 },
  locationText: { color: '#999', fontSize: 13, marginHorizontal: 5 },
  searchRow: { flexDirection: 'row', paddingHorizontal: 20, alignItems: 'center', marginBottom: 20 },
  searchBar: { 
    flex: 1, 
    flexDirection: 'row', 
    alignItems: 'center', 
    borderRadius: 15, 
    paddingHorizontal: 15, 
    paddingVertical: 10,
    shadowColor: '#000',
    shadowOpacity: 0.05,
    shadowRadius: 10,
    elevation: 2
  },
  searchInput: { flex: 1, marginLeft: 10, fontSize: 16 },
  filterButton: { 
    padding: 12, 
    borderRadius: 12, 
    marginLeft: 10 
  },
  banner: { 
    marginHorizontal: 20, 
    borderRadius: 20, 
    height: 160, 
    flexDirection: 'row',
    overflow: 'hidden',
    marginBottom: 20
  },
  bannerTextContainer: { flex: 1, padding: 20, justifyContent: 'center' },
  bannerDate: { color: '#666', fontSize: 12, marginBottom: 5 },
  bannerTitle: { fontSize: 20, fontWeight: 'bold', marginBottom: 15 },
  bannerBtn: { 
    paddingHorizontal: 15, 
    paddingVertical: 8, 
    borderRadius: 10, 
    alignSelf: 'flex-start' 
  },
  bannerBtnText: { color: '#fff', fontSize: 12, fontWeight: '600' },
  bannerImage: { width: 120, height: '100%' },
  categoryScroll: { paddingLeft: 20, marginBottom: 25 },
  categoryChip: { 
    paddingHorizontal: 18, 
    paddingVertical: 10, 
    borderRadius: 12, 
    marginRight: 10,
    borderWidth: 1
  },
  categoryChipActive: {},
  categoryChipText: { color: '#666', fontSize: 14, fontWeight: '500' },
  categoryChipTextActive: { color: '#fff' },
  sectionHeader: { 
    flexDirection: 'row', 
    justifyContent: 'space-between', 
    alignItems: 'center', 
    paddingHorizontal: 20, 
    marginBottom: 15 
  },
  sectionTitle: { fontSize: 18, fontWeight: 'bold' },
  seeAllText: { color: '#999', fontSize: 13 },
  horizontalList: { paddingLeft: 20, paddingRight: 10, marginBottom: 25 },
  card: { 
    borderRadius: 20, 
    overflow: 'hidden',
    shadowColor: '#000',
    shadowOpacity: 0.05,
    shadowRadius: 10,
    elevation: 2,
    marginBottom: 10
  },
  horizontalCard: { width: width * 0.45, marginRight: 15 },
  imageContainer: { position: 'relative' },
  image: { width: '100%', height: 200, resizeMode: 'cover' },
  heartButton: { 
    position: 'absolute', 
    top: 10, 
    right: 10, 
    backgroundColor: 'rgba(255,255,255,0.8)', 
    padding: 6, 
    borderRadius: 20 
  },
  info: { padding: 12 },
  name: { fontSize: 14, fontWeight: 'bold', marginBottom: 2 },
  brand: { fontSize: 11, color: '#999', marginBottom: 8 },
  priceRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  price: { fontSize: 16, fontWeight: 'bold' },
  colorDots: { flexDirection: 'row' },
  dot: { width: 6, height: 6, borderRadius: 3, marginLeft: 3 },
  grid: { 
    flexDirection: 'row', 
    flexWrap: 'wrap', 
    paddingHorizontal: 15 
  },
  gridItem: { width: '50%', padding: 5 },
  noData: { textAlign: 'center', width: '100%', color: '#999', marginVertical: 20 },
  emptyContainer: { width: '100%', alignItems: 'center', justifyContent: 'center', paddingVertical: 50 },
  modalOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'flex-end' },
  modalContent: { borderTopLeftRadius: 30, borderTopRightRadius: 30, padding: 25, maxHeight: '80%' },
  modalHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 25 },
  modalTitle: { fontSize: 22, fontWeight: 'bold' },
  filterLabel: { fontSize: 16, fontWeight: 'bold', marginBottom: 15 },
  priceRowModal: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 10 },
  priceInput: { borderWidth: 1, borderRadius: 12, padding: 12, fontSize: 16 },
  sizeRow: { flexDirection: 'row', flexWrap: 'wrap' },
  sizeChip: { paddingHorizontal: 15, paddingVertical: 10, borderRadius: 12, borderWidth: 1, marginRight: 10, marginBottom: 10 },
  sizeText: { fontSize: 14, fontWeight: '600', color: '#666' },
  applyBtn: { padding: 18, borderRadius: 20, alignItems: 'center', marginTop: 30 },
  applyBtnText: { color: '#fff', fontSize: 16, fontWeight: 'bold' },
  resetBtn: { padding: 15, alignItems: 'center', marginTop: 10 },
  resetBtnText: { fontSize: 14, fontWeight: '600' },
});


