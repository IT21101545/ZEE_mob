import React from 'react';
import { 
  View, 
  Text, 
  StyleSheet, 
  TouchableOpacity, 
  FlatList, 
  Dimensions,
  SafeAreaView
} from 'react-native';
import { Image } from 'expo-image';
import { useWishlist } from '../context/WishlistContext';
import { useAppTheme } from '../context/ThemeContext';
import { useSettings } from '../context/SettingsContext';
import { translations } from '../constants/translations';
import { Ionicons } from '@expo/vector-icons';
import { Colors } from '@/constants/theme';
import { useRouter, Stack } from 'expo-router';

const { width } = Dimensions.get('window');

export default function WishlistScreen() {
  const { wishlist, removeFromWishlist } = useWishlist();
  const { theme, isDark } = useAppTheme();
  const { language } = useSettings();
  const router = useRouter();
  const colors = Colors[theme];
  const t = translations[language] || translations.English;

  const renderWishlistItem = ({ item }: { item: any }) => (
    <TouchableOpacity 
      style={[styles.card, { backgroundColor: colors.card }]}
      onPress={() => router.push(`/product/${item._id}`)}
    >
      <Image source={{ uri: item.image }} style={styles.image} contentFit="cover" />
      <View style={styles.info}>
        <Text style={[styles.name, { color: colors.text }]} numberOfLines={1}>{item.name}</Text>
        <Text style={[styles.price, { color: colors.accent }]}>${item.price.toFixed(2)}</Text>
      </View>
      <TouchableOpacity 
        style={styles.removeBtn} 
        onPress={() => removeFromWishlist(item._id)}
      >
        <Ionicons name="heart" size={20} color={Colors.light.accent} />
      </TouchableOpacity>
    </TouchableOpacity>
  );

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: colors.background }]}>
      <Stack.Screen options={{ 
        headerShown: true,
        headerTitle: t.favorites || 'Wishlist',
        headerStyle: { backgroundColor: colors.background },
        headerTintColor: colors.text,
        headerLeft: () => (
          <TouchableOpacity onPress={() => router.back()} style={{ marginLeft: 10 }}>
            <Ionicons name="arrow-back" size={24} color={colors.text} />
          </TouchableOpacity>
        )
      }} />

      {wishlist.length === 0 ? (
        <View style={styles.emptyContainer}>
          <Ionicons name="heart-outline" size={100} color={isDark ? '#333' : '#eee'} />
          <Text style={[styles.emptyText, { color: isDark ? '#666' : '#999' }]}>Your wishlist is empty</Text>
          <TouchableOpacity 
            style={[styles.shopBtn, { backgroundColor: colors.accent }]}
            onPress={() => router.push('/(tabs)')}
          >
            <Text style={styles.shopBtnText}>Start Shopping</Text>
          </TouchableOpacity>
        </View>
      ) : (
        <FlatList
          data={wishlist}
          renderItem={renderWishlistItem}
          keyExtractor={(item) => item._id}
          numColumns={2}
          contentContainerStyle={styles.list}
          columnWrapperStyle={styles.row}
          showsVerticalScrollIndicator={false}
        />
      )}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  list: { padding: 15 },
  row: { justifyContent: 'space-between' },
  card: {
    width: (width - 45) / 2,
    borderRadius: 20,
    marginBottom: 15,
    overflow: 'hidden',
    shadowColor: '#000',
    shadowOpacity: 0.05,
    shadowRadius: 10,
    elevation: 3
  },
  image: { width: '100%', height: 180 },
  info: { padding: 12 },
  name: { fontSize: 14, fontWeight: '600' },
  price: { fontSize: 15, fontWeight: 'bold', marginTop: 5 },
  removeBtn: {
    position: 'absolute',
    top: 10,
    right: 10,
    backgroundColor: 'rgba(255,255,255,0.9)',
    padding: 6,
    borderRadius: 15
  },
  emptyContainer: { flex: 1, justifyContent: 'center', alignItems: 'center', padding: 20 },
  emptyText: { fontSize: 18, marginTop: 20, marginBottom: 30 },
  shopBtn: { paddingHorizontal: 40, paddingVertical: 15, borderRadius: 20 },
  shopBtnText: { color: '#fff', fontWeight: 'bold', fontSize: 16 }
});
