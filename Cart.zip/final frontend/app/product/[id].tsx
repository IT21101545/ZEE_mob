import React, { useEffect, useState, useRef } from 'react';
import { 
  View, 
  Text, 
  StyleSheet, 
  ScrollView, 
  TouchableOpacity, 
  ActivityIndicator, 
  TextInput, 
  Alert, 
  Dimensions, 
  FlatList,
  SafeAreaView,
  Modal
} from 'react-native';
import { Image } from 'expo-image';
import * as ImagePicker from 'expo-image-picker';
import * as SecureStore from 'expo-secure-store';
import { useLocalSearchParams, useRouter, Stack } from 'expo-router';
import { useProducts, Product } from '../../context/ProductContext';
import { useCart } from '../../context/CartContext';
import { useAuth } from '../../context/AuthContext';
import { useWishlist } from '../../context/WishlistContext';
import { useAppTheme } from '../../context/ThemeContext';
import { MaterialIcons, Ionicons } from '@expo/vector-icons';
import { Colors } from '@/constants/theme';
import api from '../../api/axios';

const { width } = Dimensions.get('window');

interface Review {
  _id: string;
  user: { name: string; _id: string };
  rating: number;
  comment: string;
  image?: string;
  adminReply?: string;
  createdAt: string;
}

const SIZES = ['S', 'M', 'L', 'XL'];
const COLORS = [
  { name: 'Tan', code: '#C67C4E' },
  { name: 'Beige', code: '#EAE0D5' },
  { name: 'Grey', code: '#9B9B9B' },
  { name: 'Dark', code: '#2F2D2C' },
  { name: 'Green', code: '#4B5D55' },
];

export default function ProductDetailsScreen() {
  const { id } = useLocalSearchParams();
  const router = useRouter();
  const { getProduct } = useProducts();
  const { addToCart } = useCart();
  const { user } = useAuth();
  const { toggleWishlist, isInWishlist } = useWishlist();
  const isAdmin = user?.role === 'admin';
  
  const { theme, isDark, toggleTheme } = useAppTheme();
  const colors = Colors[theme];
  
  const [product, setProduct] = useState<Product | null>(null);
  const [reviews, setReviews] = useState<Review[]>([]);
  const [avgRating, setAvgRating] = useState<string>('0');
  const [loading, setLoading] = useState(true);
  const [activeImageIndex, setActiveImageIndex] = useState(0);
  const [selectedSize, setSelectedSize] = useState('M');
  const [selectedColor, setSelectedColor] = useState('Tan');
  const [quantity, setQuantity] = useState(1);
  
  // Custom File state
  const [customFile, setCustomFile] = useState<ImagePicker.ImagePickerAsset | null>(null);

  // Review state
  const [showReviewModal, setShowReviewModal] = useState(false);
  const [reviewRating, setReviewRating] = useState(5);
  const [reviewComment, setReviewComment] = useState('');
  const [reviewImage, setReviewImage] = useState<ImagePicker.ImagePickerAsset | null>(null);
  const [submittingReview, setSubmittingReview] = useState(false);

  useEffect(() => {
    const fetchDetails = async () => {
      if (!id) return;
      setLoading(true);
      const prod = await getProduct(id as string);
      setProduct(prod);

      try {
        const res = await api.get(`/reviews/product/${id}`);
        setReviews(res.data.reviews);
        setAvgRating(res.data.avgRating);
      } catch (error) {
        console.error('Failed to fetch reviews', error);
      } finally {
        setLoading(false);
      }
    };
    fetchDetails();
  }, [id]);

  const handleAddToCart = async () => {
    if (!product) return;
    try {
      await addToCart(product._id, quantity, customFile);
      setCustomFile(null);
      Alert.alert('Added to Cart', `${quantity} item(s) added to your cart successfully.`);
    } catch (error) {
      Alert.alert('Error', 'Could not add item to cart. Please try again.');
    }
  };

  const pickCustomFile = async () => {
    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      allowsEditing: true,
      quality: 0.8,
    });
    if (!result.canceled) {
      setCustomFile(result.assets[0]);
    }
  };

  const pickReviewImage = async () => {
    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      allowsEditing: true,
      quality: 0.8,
    });
    if (!result.canceled) {
      setReviewImage(result.assets[0]);
    }
  };

  const handleSubmitReview = async () => {
    if (!reviewRating || !reviewComment.trim()) {
      Alert.alert('Error', 'Please provide both a rating and a comment.');
      return;
    }

    setSubmittingReview(true);
    try {
      const formData = new FormData();
      formData.append('productId', id as string);
      formData.append('rating', reviewRating.toString());
      formData.append('comment', reviewComment);

      if (reviewImage) {
        const filename = reviewImage.uri.split('/').pop() || 'review.jpg';
        const match = /\.(\w+)$/.exec(filename);
        const type = match ? `image/${match[1]}` : `image`;
        formData.append('image', { uri: reviewImage.uri, name: filename, type } as any);
      }

      const token = await SecureStore.getItemAsync('userToken');
      const res = await fetch(`${api.defaults.baseURL}/reviews`, {
        method: 'POST',
        headers: { Authorization: `Bearer ${token}` },
        body: formData,
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.message || 'Failed to submit review');

      Alert.alert('Success', 'Feedback submitted! Thank you.');
      setShowReviewModal(false);
      setReviewComment('');
      setReviewRating(5);
      setReviewImage(null);
      
      // Refresh reviews
      const revRes = await api.get(`/reviews/product/${id}`);
      setReviews(revRes.data.reviews);
      setAvgRating(revRes.data.avgRating);
    } catch (error: any) {
      Alert.alert('Error', error.message);
    } finally {
      setSubmittingReview(false);
    }
  };

  const handleDeleteReview = async (reviewId: string) => {
    Alert.alert('Delete Review', 'Are you sure you want to delete this review?', [
      { text: 'Cancel', style: 'cancel' },
      { 
        text: 'Delete', 
        style: 'destructive',
        onPress: async () => {
          try {
            await api.delete(`/reviews/${reviewId}`);
            setReviews(prev => prev.filter(r => r._id !== reviewId));
            Alert.alert('Success', 'Review deleted successfully');
          } catch (error) {
            Alert.alert('Error', 'Failed to delete review');
          }
        }
      }
    ]);
  };

  if (loading) {
    return (
      <View style={styles.center}>
        <ActivityIndicator size="large" color={Colors.light.accent} />
      </View>
    );
  }

  if (!product) {
    return (
      <View style={[styles.center, { backgroundColor: colors.background }]}>
        <Ionicons name="alert-circle-outline" size={60} color="#ff3b30" />
        <Text style={{ fontSize: 18, color: colors.text, marginTop: 15 }}>Product not found</Text>
      </View>
    );
  }

  const allImages = [
    product.image || 'https://via.placeholder.com/400',
    ...(product.images || []),
  ].filter(Boolean);

  return (
    <View style={{ flex: 1, backgroundColor: colors.background }}>
      <Stack.Screen 
        options={{ 
          headerTransparent: true,
          headerTitle: '',
          headerLeft: () => (
            <TouchableOpacity onPress={() => router.back()} style={[styles.circleBtn, { backgroundColor: isDark ? 'rgba(0,0,0,0.5)' : 'rgba(255,255,255,0.9)' }]}>
              <Ionicons name="chevron-back" size={24} color={isDark ? '#fff' : '#333'} />
            </TouchableOpacity>
          ),
          headerRight: () => (
            <TouchableOpacity onPress={() => toggleWishlist(product._id)} style={[styles.circleBtn, { backgroundColor: isDark ? 'rgba(0,0,0,0.5)' : 'rgba(255,255,255,0.9)' }]}>
              <Ionicons 
                name={isInWishlist(product._id) ? "heart" : "heart-outline"} 
                size={22} 
                color={isInWishlist(product._id) ? colors.accent : (isDark ? '#fff' : '#333')} 
              />
            </TouchableOpacity>
          ),
        }} 
      />

      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingBottom: 100 }}>
        {/* Gallery */}
        <View style={styles.galleryContainer}>
          <ScrollView
            horizontal
            pagingEnabled
            showsHorizontalScrollIndicator={false}
            onMomentumScrollEnd={(e) => {
              const idx = Math.round(e.nativeEvent.contentOffset.x / width);
              setActiveImageIndex(idx);
            }}
          >
            {allImages.map((uri, i) => (
              <Image key={i} source={{ uri }} style={styles.heroImage} />
            ))}
          </ScrollView>
          {allImages.length > 1 && (
            <View style={styles.dotsContainer}>
              {allImages.map((_, i) => (
                <View key={i} style={[styles.dot, activeImageIndex === i && styles.dotActive]} />
              ))}
            </View>
          )}
        </View>

        <View style={styles.content}>
          <View style={styles.mainInfo}>
            <View style={{ flex: 1 }}>
              <Text style={[styles.productName, { color: colors.text }]}>{product.name}</Text>
              <View style={styles.ratingRow}>
                <Ionicons name="star" size={16} color="#FFD700" />
                <Text style={[styles.ratingText, { color: colors.text }]}>{avgRating} ({reviews.length} Reviews)</Text>
                {product.stock <= 5 && product.stock > 0 && (
                  <Text style={{ color: '#ff3b30', fontSize: 12, marginLeft: 10, fontWeight: 'bold' }}>Only {product.stock} left!</Text>
                )}
              </View>
            </View>
          </View>

          {/* Quantity Selector */}
          <View style={styles.quantitySection}>
            <Text style={[styles.sectionTitle, { color: colors.text, marginTop: 0 }]}>Quantity</Text>
            <View style={[styles.qtyContainer, { backgroundColor: colors.card }]}>
              <TouchableOpacity 
                style={styles.qtyBtn} 
                onPress={() => setQuantity(Math.max(1, quantity - 1))}
              >
                <Ionicons name="remove" size={20} color={colors.text} />
              </TouchableOpacity>
              <Text style={[styles.qtyText, { color: colors.text }]}>{quantity}</Text>
              <TouchableOpacity 
                style={styles.qtyBtn} 
                onPress={() => setQuantity(Math.min(product.stock || 99, quantity + 1))}
              >
                <Ionicons name="add" size={20} color={colors.text} />
              </TouchableOpacity>
            </View>
          </View>

          {/* Size Selector */}
          <Text style={[styles.sectionTitle, { color: colors.text }]}>Size</Text>
          <View style={styles.sizeRow}>
            {SIZES.map(s => (
              <TouchableOpacity 
                key={s} 
                style={[
                  styles.sizePill, 
                  { borderColor: colors.border },
                  selectedSize === s && { backgroundColor: colors.text, borderColor: colors.text }
                ]}
                onPress={() => setSelectedSize(s)}
              >
                <Text style={[styles.sizeText, { color: colors.text }, selectedSize === s && { color: colors.background }]}>{s}</Text>
              </TouchableOpacity>
            ))}
          </View>

          {/* Color Selector */}
          <Text style={[styles.sectionTitle, { color: colors.text }]}>Color</Text>
          <View style={styles.colorRow}>
            {COLORS.map(c => (
              <TouchableOpacity 
                key={c.name} 
                style={[styles.colorPill, selectedColor === c.name && { borderColor: colors.accent, borderWidth: 2 }]}
                onPress={() => setSelectedColor(c.name)}
              >
                <View style={[styles.colorCircle, { backgroundColor: c.code }]} />
              </TouchableOpacity>
            ))}
          </View>

          {/* Description */}
          <View style={[styles.tabsRow, { borderBottomColor: colors.border }]}>
            <TouchableOpacity style={[styles.tab, { borderBottomColor: colors.text }]}><Text style={{ color: colors.text, fontWeight: 'bold' }}>Details</Text></TouchableOpacity>
            <TouchableOpacity style={styles.tab}><Text style={{ color: '#999' }}>Support</Text></TouchableOpacity>
            <TouchableOpacity style={styles.tab}><Text style={{ color: '#999' }}>Reviews</Text></TouchableOpacity>
          </View>
          <Text style={[styles.descriptionText, { color: colors.text + '99' }]}>{product.description}</Text>

          {/* Custom Image Upload */}
          <View style={styles.customContainer}>
            <Text style={[styles.sectionTitle, { color: colors.text }]}>Personalize (Optional)</Text>
            <TouchableOpacity style={[styles.uploadBox, { borderColor: colors.border, backgroundColor: colors.card }]} onPress={pickCustomFile}>
              {customFile ? (
                <Image source={{ uri: customFile.uri }} style={styles.uploadPreview} />
              ) : (
                <View style={{ alignItems: 'center' }}>
                  <Ionicons name="cloud-upload-outline" size={30} color={colors.accent} />
                  <Text style={{ color: '#999', fontSize: 12, marginTop: 5 }}>Upload design</Text>
                </View>
              )}
            </TouchableOpacity>
          </View>

          {/* Reviews Section */}
          <View style={styles.reviewsContainer}>
            <View style={styles.reviewsHeader}>
              <Text style={styles.sectionTitle}>Reviews ({reviews.length})</Text>
              <TouchableOpacity>
                <Text style={styles.viewAllText}>View All</Text>
              </TouchableOpacity>
            </View>

            {/* Add Review Button */}
            {!isAdmin && user && !reviews.find(r => r.user._id === user._id) && (
              <TouchableOpacity 
                style={[styles.addFeedbackBtn, { borderColor: Colors.light.accent }]} 
                onPress={() => setShowReviewModal(true)}
              >
                <Ionicons name="add-circle-outline" size={20} color={Colors.light.accent} />
                <Text style={[styles.addFeedbackText, { color: Colors.light.accent }]}>Share Your Feedback</Text>
              </TouchableOpacity>
            )}

            {reviews.length === 0 ? (
              <View style={styles.emptyReviews}>
                <Ionicons name="chatbubbles-outline" size={40} color="#E0E0E0" />
                <Text style={styles.noReviewsText}>No reviews yet. Be the first to share your experience!</Text>
              </View>
            ) : (
              reviews.map((rev) => (
                <View key={rev._id} style={styles.reviewCard}>
                  <View style={styles.reviewHeader}>
                    <View style={styles.reviewerInfo}>
                      <Text style={styles.reviewerName}>{rev.user.name}</Text>
                      <View style={styles.starRow}>
                        {[...Array(5)].map((_, i) => (
                          <Ionicons 
                            key={i} 
                            name={i < rev.rating ? "star" : "star-outline"} 
                            size={12} 
                            color="#FFD700" 
                          />
                        ))}
                      </View>
                    </View>
                    <Text style={styles.reviewDate}>{new Date(rev.createdAt).toLocaleDateString()}</Text>
                  </View>
                  <Text style={styles.reviewComment}>{rev.comment}</Text>
                  {rev.image && <Image source={{ uri: rev.image }} style={styles.reviewAttachedImage} />}
                  
                  {rev.adminReply ? (
                    <View style={styles.adminReply}>
                      <View style={styles.replyHeader}>
                        <Text style={styles.replyTitle}>Response from Seller</Text>
                        <Ionicons name="checkmark-circle" size={14} color={Colors.light.accent} />
                      </View>
                      <Text style={styles.replyText}>{rev.adminReply}</Text>
                    </View>
                  ) : (
                    isAdmin && (
                      <TouchableOpacity 
                        style={styles.replyBtn}
                        onPress={() => router.push({
                          pathname: '/reviews',
                          params: { replyTo: rev._id, productId: product._id }
                        })}
                      >
                        <Ionicons name="arrow-undo-outline" size={14} color={Colors.light.accent} />
                        <Text style={styles.replyBtnText}>Reply as Admin</Text>
                      </TouchableOpacity>
                    )
                  )}

                  {/* Delete button for owner or admin */}
                  {(isAdmin || (user && rev.user._id === user._id)) && (
                    <TouchableOpacity 
                      style={styles.deleteReviewBtn}
                      onPress={() => handleDeleteReview(rev._id)}
                    >
                      <Ionicons name="trash-outline" size={16} color="#ff3b30" />
                    </TouchableOpacity>
                  )}
                </View>
              ))
            )}
          </View>
        </View>
      </ScrollView>

      {/* Review Modal */}
      <Modal visible={showReviewModal} animationType="slide" transparent>
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>Add Feedback</Text>
              <TouchableOpacity onPress={() => setShowReviewModal(false)}>
                <Ionicons name="close" size={24} color="#333" />
              </TouchableOpacity>
            </View>

            <ScrollView>
              <Text style={styles.modalLabel}>Rate this product</Text>
              <View style={styles.modalRatingRow}>
                {[1, 2, 3, 4, 5].map((star) => (
                  <TouchableOpacity key={star} onPress={() => setReviewRating(star)}>
                    <Ionicons 
                      name={star <= reviewRating ? "star" : "star-outline"} 
                      size={40} 
                      color="#FFD700" 
                      style={{ marginHorizontal: 5 }}
                    />
                  </TouchableOpacity>
                ))}
              </View>

              <Text style={styles.modalLabel}>Your Comment</Text>
              <TextInput
                style={styles.modalInput}
                placeholder="How was your experience?"
                multiline
                numberOfLines={4}
                value={reviewComment}
                onChangeText={setReviewComment}
              />

              <Text style={styles.modalLabel}>Attach Photo (Optional)</Text>
              <TouchableOpacity style={styles.modalUpload} onPress={pickReviewImage}>
                {reviewImage ? (
                  <Image source={{ uri: reviewImage.uri }} style={styles.modalUploadPreview} />
                ) : (
                  <View style={{ alignItems: 'center' }}>
                    <Ionicons name="camera-outline" size={32} color="#999" />
                    <Text style={{ color: '#999', fontSize: 12, marginTop: 5 }}>Add Image</Text>
                  </View>
                )}
              </TouchableOpacity>

              <TouchableOpacity 
                style={[styles.modalSubmit, submittingReview && { opacity: 0.7 }]}
                onPress={handleSubmitReview}
                disabled={submittingReview}
              >
                {submittingReview ? <ActivityIndicator color="#fff" /> : <Text style={styles.modalSubmitText}>Submit Feedback</Text>}
              </TouchableOpacity>
            </ScrollView>
          </View>
        </View>
      </Modal>

      {/* Bottom Bar */}

      <View style={[styles.bottomBar, { backgroundColor: colors.card }]}>
        <View>
          <Text style={styles.totalPriceLabel}>Price</Text>
          <Text style={[styles.totalPriceValue, { color: colors.accent }]}>${(product.price * quantity).toFixed(2)}</Text>
        </View>
        <TouchableOpacity 
          style={[
            styles.buyBtn, 
            { backgroundColor: product.stock === 0 ? colors.border : colors.text }
          ]} 
          onPress={handleAddToCart}
          disabled={product.stock === 0}
        >
          <Ionicons name="bag-handle-outline" size={20} color={colors.background} />
          <Text style={[styles.buyBtnText, { color: colors.background }]}>
            {product.stock > 0 ? 'Buy Now' : 'Out of Stock'}
          </Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  center: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  circleBtn: { 
    width: 40, 
    height: 40, 
    borderRadius: 20, 
    backgroundColor: 'rgba(255,255,255,0.9)', 
    justifyContent: 'center', 
    alignItems: 'center',
    marginHorizontal: 10,
    shadowColor: '#000',
    shadowOpacity: 0.1,
    shadowRadius: 5,
    elevation: 3
  },
  galleryContainer: { position: 'relative' },
  heroImage: { width: width, height: 450, resizeMode: 'cover', borderBottomLeftRadius: 40, borderBottomRightRadius: 40 },
  dotsContainer: { position: 'absolute', bottom: 30, width: '100%', flexDirection: 'row', justifyContent: 'center' },
  dot: { width: 6, height: 6, borderRadius: 3, backgroundColor: 'rgba(255,255,255,0.5)', marginHorizontal: 3 },
  dotActive: { width: 15, backgroundColor: '#fff' },
  content: { padding: 25 },
  mainInfo: { marginBottom: 20 },
  productName: { fontSize: 24, fontWeight: 'bold', color: '#2F2D2C', marginBottom: 8 },
  ratingRow: { flexDirection: 'row', alignItems: 'center' },
  ratingText: { fontSize: 13, fontWeight: '600', color: '#2F2D2C', marginHorizontal: 5 },
  designerText: { fontSize: 13, color: '#9B9B9B', marginLeft: 10 },
  sectionTitle: { fontSize: 16, fontWeight: 'bold', color: '#2F2D2C', marginTop: 25, marginBottom: 15 },
  sizeRow: { flexDirection: 'row' },
  sizePill: { 
    width: 50, 
    height: 45, 
    borderRadius: 12, 
    borderWidth: 1, 
    borderColor: '#EAEAEA', 
    justifyContent: 'center', 
    alignItems: 'center', 
    marginRight: 12 
  },
  sizePillActive: { backgroundColor: '#2F2D2C', borderColor: '#2F2D2C' },
  sizeText: { fontSize: 15, color: '#2F2D2C', fontWeight: '500' },
  sizeTextActive: { color: '#fff' },
  colorRow: { flexDirection: 'row' },
  colorPill: { 
    width: 35, 
    height: 35, 
    borderRadius: 18, 
    padding: 3, 
    marginRight: 15, 
    borderWidth: 1, 
    borderColor: 'transparent' 
  },
  colorCircle: { flex: 1, borderRadius: 15 },
  tabsRow: { flexDirection: 'row', marginTop: 30, borderBottomWidth: 1, borderBottomColor: '#F0F0F0' },
  tab: { paddingVertical: 10, marginRight: 20 },
  tabActive: { borderBottomWidth: 2, borderBottomColor: '#2F2D2C' },
  tabText: { color: '#999', fontWeight: '500' },
  tabTextActive: { color: '#2F2D2C', fontWeight: 'bold' },
  descriptionText: { color: '#777', lineHeight: 22, marginTop: 15, fontSize: 14 },
  customContainer: { marginTop: 10 },
  uploadBox: { 
    width: 80, 
    height: 80, 
    borderRadius: 15, 
    borderWidth: 1, 
    borderColor: '#EAEAEA', 
    borderStyle: 'dashed', 
    justifyContent: 'center', 
    alignItems: 'center',
    backgroundColor: '#F9F9F9'
  },
  uploadPreview: { width: '100%', height: '100%', borderRadius: 15 },
  reviewsContainer: { marginTop: 30, paddingBottom: 20 },
  reviewsHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 15 },
  viewAllText: { color: Colors.light.accent, fontWeight: '600', fontSize: 13 },
  emptyReviews: { alignItems: 'center', padding: 20, backgroundColor: '#F9F9F9', borderRadius: 20 },
  noReviewsText: { color: '#999', fontSize: 12, textAlign: 'center', marginTop: 10 },
  reviewCard: { backgroundColor: '#fff', padding: 15, borderRadius: 20, marginBottom: 15, borderWidth: 1, borderColor: '#F5F5F5' },
  reviewHeader: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 10 },
  reviewerInfo: { flex: 1 },
  reviewerName: { fontSize: 14, fontWeight: 'bold', color: '#2F2D2C' },
  starRow: { flexDirection: 'row', marginTop: 2 },
  reviewDate: { fontSize: 11, color: '#999' },
  reviewComment: { fontSize: 13, color: '#555', lineHeight: 20 },
  reviewAttachedImage: { width: 100, height: 100, borderRadius: 12, marginTop: 10 },
  adminReply: { backgroundColor: '#FDF5F0', padding: 12, borderRadius: 15, marginTop: 12, borderLeftWidth: 3, borderLeftColor: Colors.light.accent },
  replyHeader: { flexDirection: 'row', alignItems: 'center', marginBottom: 5 },
  replyTitle: { fontSize: 12, fontWeight: 'bold', color: '#2F2D2C', marginRight: 5 },
  replyText: { fontSize: 13, color: '#777', lineHeight: 18 },
  deleteReviewBtn: {
    position: 'absolute',
    top: 15,
    right: 15,
    padding: 5,
    backgroundColor: '#fff',
    borderRadius: 15,
    elevation: 2,
    shadowColor: '#000',
    shadowOpacity: 0.1,
    shadowRadius: 2,
    shadowOffset: { width: 0, height: 1 }
  },
  replyBtn: { flexDirection: 'row', alignItems: 'center', marginTop: 12, paddingVertical: 8, paddingHorizontal: 15, backgroundColor: '#FDF5F0', borderRadius: 12, alignSelf: 'flex-start' },
  replyBtnText: { color: Colors.light.accent, fontWeight: 'bold', fontSize: 13, marginLeft: 6 },
  bottomBar: { 
    position: 'absolute', 
    bottom: 0, 
    left: 0, 
    right: 0, 
    backgroundColor: '#fff', 
    flexDirection: 'row', 
    padding: 20, 
    paddingBottom: 35,
    alignItems: 'center', 
    justifyContent: 'space-between',
    borderTopLeftRadius: 30,
    borderTopRightRadius: 30,
    shadowColor: '#000',
    shadowOpacity: 0.1,
    shadowRadius: 15,
    elevation: 10
  },
  totalPriceLabel: { fontSize: 12, color: '#9B9B9B', marginBottom: 2 },
  totalPriceValue: { fontSize: 20, fontWeight: 'bold', color: Colors.light.accent },
  buyBtn: { 
    flexDirection: 'row', 
    backgroundColor: '#2F2D2C', 
    paddingHorizontal: 35, 
    paddingVertical: 15, 
    borderRadius: 20, 
    alignItems: 'center' 
  },
  buyBtnText: { color: '#fff', fontSize: 16, fontWeight: 'bold', marginLeft: 10 },
  addFeedbackBtn: { 
    flexDirection: 'row', 
    alignItems: 'center', 
    justifyContent: 'center', 
    padding: 15, 
    borderRadius: 15, 
    borderWidth: 1, 
    borderStyle: 'dashed',
    marginBottom: 20,
    backgroundColor: '#FDF9F6'
  },
  addFeedbackText: { fontSize: 14, fontWeight: 'bold', marginLeft: 8 },
  modalOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'flex-end' },
  modalContent: { backgroundColor: '#fff', borderTopLeftRadius: 30, borderTopRightRadius: 30, padding: 25, maxHeight: '80%' },
  modalHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 25 },
  modalTitle: { fontSize: 20, fontWeight: 'bold', color: '#333' },
  modalLabel: { fontSize: 16, fontWeight: '600', color: '#333', marginTop: 15, marginBottom: 10 },
  modalRatingRow: { flexDirection: 'row', justifyContent: 'center', marginVertical: 10 },
  modalInput: { borderWidth: 1, borderColor: '#EEE', borderRadius: 15, padding: 15, height: 100, textAlignVertical: 'top', fontSize: 15 },
  modalUpload: { width: 100, height: 100, borderRadius: 15, borderWidth: 1, borderColor: '#EEE', borderStyle: 'dashed', justifyContent: 'center', alignItems: 'center', marginTop: 5, backgroundColor: '#FAFAFA' },
  modalUploadPreview: { width: '100%', height: '100%', borderRadius: 15 },
  modalSubmit: { backgroundColor: Colors.light.accent, borderRadius: 15, padding: 18, alignItems: 'center', marginTop: 30, shadowColor: Colors.light.accent, shadowOpacity: 0.3, shadowRadius: 10, elevation: 5 },
  modalSubmitText: { color: '#fff', fontSize: 16, fontWeight: 'bold' },
  qtyContainer: { flexDirection: 'row', alignItems: 'center', alignSelf: 'flex-start', borderRadius: 15, paddingHorizontal: 15, paddingVertical: 8 },
  qtyBtn: { width: 35, height: 35, borderRadius: 18, justifyContent: 'center', alignItems: 'center' },
  qtyText: { fontSize: 18, fontWeight: 'bold', marginHorizontal: 20 },
  quantitySection: { marginTop: 10 },
});

