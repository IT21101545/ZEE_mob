import React, { useState } from 'react';
import { 
  View, 
  Text, 
  TextInput, 
  TouchableOpacity, 
  StyleSheet, 
  ScrollView, 
  Alert, 
  ActivityIndicator,
  SafeAreaView,
  Image
} from 'react-native';
import { useRouter } from 'expo-router';
import { useCart } from '../context/CartContext';
import { useOrders } from '../context/OrderContext';
import { useAppTheme } from '../context/ThemeContext';
import { Colors } from '@/constants/theme';
import * as ImagePicker from 'expo-image-picker';
import { Ionicons } from '@expo/vector-icons';

export default function CheckoutScreen() {
  const { cartItems, cartTotal, clearCart, shippingAddress } = useCart();
  const { createOrder } = useOrders();
  const { theme, isDark } = useAppTheme();
  const router = useRouter();
  const colors = Colors[theme];

  const [address, setAddress] = useState(shippingAddress.address);
  const [city, setCity] = useState(shippingAddress.city);
  const [postalCode, setPostalCode] = useState(shippingAddress.postalCode);
  const [paymentMethod, setPaymentMethod] = useState<'Card' | 'COD' | 'Deposit'>('COD');
  const [bankSlip, setBankSlip] = useState<ImagePicker.ImagePickerAsset | null>(null);
  const [cardNumber, setCardNumber] = useState('');
  const [expiry, setExpiry] = useState('');
  const [cvv, setCvv] = useState('');
  const [loading, setLoading] = useState(false);

  const deliveryFee = 5.00;
  const totalPrice = cartTotal + deliveryFee;

  const pickBankSlip = async () => {
    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      allowsEditing: true,
      quality: 0.8,
    });
    if (!result.canceled) {
      setBankSlip(result.assets[0]);
    }
  };

  const handlePlaceOrder = async () => {
    if (!address || !city || !postalCode) {
      Alert.alert('Error', 'Please enter complete delivery details');
      return;
    }

    if (paymentMethod === 'Card') {
      if (!cardNumber || !expiry || !cvv) {
        Alert.alert('Error', 'Please fill in your card details');
        return;
      }
    }

    if (paymentMethod === 'Deposit' && !bankSlip) {
      Alert.alert('Error', 'Please upload your bank deposit slip');
      return;
    }

    setLoading(true);
    try {
      const formData = new FormData();
      
      const orderItems = cartItems
        .filter(item => item.product != null)
        .map(item => ({
          name: item.product.name,
          quantity: item.quantity,
          image: item.product.image || '',
          price: item.product.price,
          product: item.product._id,
        }));

      formData.append('orderItems', JSON.stringify(orderItems));
      formData.append('shippingAddress', JSON.stringify({ address, city, postalCode, country: 'Sri Lanka' }));
      formData.append('paymentMethod', paymentMethod === 'Card' ? 'Credit Card' : paymentMethod === 'Deposit' ? 'Bank Deposit' : 'Cash on Delivery');
      formData.append('itemsPrice', cartTotal.toString());
      formData.append('shippingPrice', deliveryFee.toString());
      formData.append('totalPrice', totalPrice.toString());
      formData.append('isPaid', (paymentMethod === 'Card').toString());

      if (paymentMethod === 'Deposit' && bankSlip) {
        const filename = bankSlip.uri.split('/').pop() || 'slip.jpg';
        const match = /\.(\w+)$/.exec(filename);
        const type = match ? `image/${match[1]}` : `image`;
        
        formData.append('attachment', {
          uri: bankSlip.uri,
          name: filename,
          type,
        } as any);
      }

      await createOrder(formData);
      clearCart();
      Alert.alert('Success', 'Order placed successfully!', [
        { text: 'View Orders', onPress: () => router.push('/(tabs)/profile') },
        { text: 'Continue Shopping', onPress: () => router.push('/(tabs)') }
      ]);
    } catch (error: any) {
      Alert.alert('Error', error.response?.data?.message || 'Failed to place order');
    } finally {
      setLoading(false);
    }
  };

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: colors.background }]}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => router.back()} style={[styles.backBtn, { backgroundColor: colors.card }]}>
          <Ionicons name="arrow-back" size={24} color={colors.text} />
        </TouchableOpacity>
        <Text style={[styles.headerTitle, { color: colors.text }]}>Checkout</Text>
      </View>

      <ScrollView contentContainerStyle={styles.content}>
        <Text style={[styles.mainTitle, { color: colors.text }]}>Complete Your Order</Text>

        {/* Order Summary */}
        <View style={[styles.section, { backgroundColor: colors.card, borderColor: colors.border }]}>
          <Text style={[styles.sectionTitle, { color: colors.text }]}>Order Summary</Text>
          {cartItems.map((item, idx) => (
            <View key={idx} style={styles.summaryRow}>
              <Text style={[styles.itemText, { color: isDark ? '#888' : '#666' }]}>{item.quantity}x {item.product?.name}</Text>
              <Text style={[styles.itemPrice, { color: colors.text }]}>${((item.product?.price || 0) * item.quantity).toFixed(2)}</Text>
            </View>
          ))}
          <View style={[styles.divider, { backgroundColor: colors.border }]} />
          <View style={styles.totalRow}>
            <Text style={[styles.totalLabel, { color: colors.text }]}>Total Amount</Text>
            <Text style={[styles.totalValue, { color: colors.accent }]}>${totalPrice.toFixed(2)}</Text>
          </View>
        </View>

        {/* Delivery Address */}
        <View style={[styles.section, { backgroundColor: colors.card, borderColor: colors.border }]}>
          <Text style={[styles.sectionTitle, { color: colors.text }]}>Shipping Details</Text>
          <Text style={styles.inputLabel}>Delivery Address</Text>
          <TextInput
            style={[styles.textArea, { marginBottom: 15, backgroundColor: isDark ? colors.background : '#FDFDFD', color: colors.text, borderColor: colors.border }]}
            placeholder="No. 123, Galle Road, Colombo"
            placeholderTextColor="#666"
            multiline
            numberOfLines={3}
            value={address}
            onChangeText={setAddress}
          />
          <View style={styles.row}>
            <View style={{ flex: 1, marginRight: 10 }}>
              <Text style={styles.inputLabel}>City</Text>
              <TextInput
                style={[styles.proInputBox, { backgroundColor: isDark ? colors.background : '#FDFDFD', color: colors.text, borderColor: colors.border }]}
                placeholder="Colombo"
                placeholderTextColor="#666"
                value={city}
                onChangeText={setCity}
              />
            </View>
            <View style={{ flex: 1 }}>
              <Text style={styles.inputLabel}>Postal Code</Text>
              <TextInput
                style={[styles.proInputBox, { backgroundColor: isDark ? colors.background : '#FDFDFD', color: colors.text, borderColor: colors.border }]}
                placeholder="10100"
                placeholderTextColor="#666"
                value={postalCode}
                onChangeText={setPostalCode}
                keyboardType="numeric"
              />
            </View>
          </View>
        </View>

        {/* Payment Method */}
        <View style={[styles.section, { backgroundColor: colors.card, borderColor: colors.border }]}>
          <Text style={[styles.sectionTitle, { color: colors.text }]}>Payment Option</Text>
          
          <TouchableOpacity 
            style={[styles.paymentOption, { borderColor: paymentMethod === 'Card' ? colors.accent : colors.border }]}
            onPress={() => setPaymentMethod('Card')}
          >
            <Ionicons name="card-outline" size={24} color={paymentMethod === 'Card' ? colors.accent : '#666'} />
            <Text style={[styles.paymentOptionText, { color: paymentMethod === 'Card' ? colors.accent : (isDark ? '#888' : '#666') }]}>Credit Card</Text>
          </TouchableOpacity>

          {paymentMethod === 'Card' && (
            <View style={[styles.professionalCardContainer, { backgroundColor: isDark ? colors.background : '#FAFAFA', borderColor: colors.border }]}>
              <View style={styles.cardHeader}>
                <Ionicons name="card" size={24} color={colors.accent} />
                <Ionicons name="wifi" size={24} color="#666" style={{ transform: [{ rotate: '90deg' }] }} />
              </View>
              <TextInput
                style={[styles.proInputBox, { marginBottom: 15, backgroundColor: colors.card, color: colors.text, borderColor: colors.border }]}
                placeholder="Card Number"
                placeholderTextColor="#666"
                value={cardNumber}
                onChangeText={setCardNumber}
                keyboardType="numeric"
              />
              <View style={styles.row}>
                <TextInput
                  style={[styles.proInputBox, { flex: 1, marginRight: 10, backgroundColor: colors.card, color: colors.text, borderColor: colors.border }]}
                  placeholder="MM/YY"
                  placeholderTextColor="#666"
                  value={expiry}
                  onChangeText={setExpiry}
                />
                <TextInput
                  style={[styles.proInputBox, { flex: 1, backgroundColor: colors.card, color: colors.text, borderColor: colors.border }]}
                  placeholder="CVV"
                  placeholderTextColor="#666"
                  value={cvv}
                  onChangeText={setCvv}
                  keyboardType="numeric"
                  secureTextEntry
                />
              </View>
            </View>
          )}

          <TouchableOpacity 
            style={[styles.paymentOption, { borderColor: paymentMethod === 'Deposit' ? colors.accent : colors.border }]}
            onPress={() => setPaymentMethod('Deposit')}
          >
            <Ionicons name="receipt-outline" size={24} color={paymentMethod === 'Deposit' ? colors.accent : '#666'} />
            <Text style={[styles.paymentOptionText, { color: paymentMethod === 'Deposit' ? colors.accent : (isDark ? '#888' : '#666') }]}>Bank Deposit</Text>
          </TouchableOpacity>

          {paymentMethod === 'Deposit' && (
            <View style={[styles.depositInfoBox, { backgroundColor: isDark ? colors.background : '#FAFAFA', borderLeftColor: colors.accent }]}>
              <Text style={[styles.depositLabel, { color: colors.text }]}>Bank: Commercial Bank</Text>
              <Text style={[styles.depositLabel, { color: colors.text }]}>Acc: 123-456-789-0</Text>
              <TouchableOpacity style={[styles.slipUploadBtn, { borderColor: colors.accent }]} onPress={pickBankSlip}>
                {bankSlip ? (
                  <Image source={{ uri: bankSlip.uri }} style={styles.slipPreview} />
                ) : (
                  <Text style={[styles.slipUploadText, { color: colors.accent }]}>Upload Deposit Slip</Text>
                )}
              </TouchableOpacity>
            </View>
          )}

          <TouchableOpacity 
            style={[styles.paymentOption, { borderColor: paymentMethod === 'COD' ? colors.accent : colors.border }]}
            onPress={() => setPaymentMethod('COD')}
          >
            <Ionicons name="cash-outline" size={24} color={paymentMethod === 'COD' ? colors.accent : '#666'} />
            <Text style={[styles.paymentOptionText, { color: paymentMethod === 'COD' ? colors.accent : (isDark ? '#888' : '#666') }]}>Cash on Delivery</Text>
          </TouchableOpacity>
        </View>
      </ScrollView>

      <View style={[styles.footer, { backgroundColor: colors.card }]}>
        <TouchableOpacity 
          style={[styles.confirmBtn, { backgroundColor: colors.accent }]} 
          onPress={handlePlaceOrder}
          disabled={loading}
        >
          {loading ? <ActivityIndicator color="#fff" /> : <Text style={styles.confirmBtnText}>Place Order</Text>}
        </TouchableOpacity>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: { flexDirection: 'row', alignItems: 'center', padding: 20 },
  backBtn: { padding: 5 },
  headerTitle: { fontSize: 18, fontWeight: '500', marginLeft: 20, color: '#000' },
  content: { padding: 20 },
  mainTitle: { fontSize: 28, fontWeight: 'bold', color: '#333', marginBottom: 25 },
  section: { backgroundColor: '#fff', borderRadius: 15, padding: 20, marginBottom: 20, borderWidth: 1, borderColor: '#EBEBEB' },
  sectionTitle: { fontSize: 18, fontWeight: 'bold', marginBottom: 15, color: '#333' },
  summaryRow: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 10 },
  itemText: { fontSize: 16, color: '#666' },
  itemPrice: { fontSize: 16, fontWeight: '500', color: '#333' },
  divider: { height: 1, backgroundColor: '#EEE', marginVertical: 15 },
  totalRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  totalLabel: { fontSize: 18, fontWeight: 'bold', color: '#333' },
  totalValue: { fontSize: 20, fontWeight: 'bold', color: '#D4AF37' },
  inputLabel: { fontSize: 13, color: '#999', marginBottom: 5, fontWeight: '500' },
  proInputBox: { borderWidth: 1, borderColor: '#EBEBEB', borderRadius: 12, padding: 12, fontSize: 15, backgroundColor: '#FDFDFD', color: '#333' },
  textArea: { borderWidth: 1, borderColor: '#EBEBEB', borderRadius: 15, padding: 15, fontSize: 16, height: 100, textAlignVertical: 'top', backgroundColor: '#FDFDFD' },
  depositInfoBox: { padding: 15, backgroundColor: '#FAFAFA', borderRadius: 15, borderLeftWidth: 4, borderLeftColor: '#D4AF37', marginBottom: 15 },
  depositLabel: { fontSize: 14, fontWeight: 'bold', color: '#333', marginBottom: 5 },
  slipUploadBtn: { marginTop: 10, padding: 15, borderRadius: 12, borderWidth: 1, borderColor: '#D4AF37', borderStyle: 'dashed', alignItems: 'center', justifyContent: 'center', backgroundColor: '#fff' },
  slipUploadText: { color: '#D4AF37', fontWeight: 'bold', marginTop: 5, fontSize: 13 },
  slipPreview: { width: '100%', height: 150, borderRadius: 10, resizeMode: 'cover' },
  paymentOption: { 
    flexDirection: 'row', 
    alignItems: 'center', 
    padding: 18, 
    borderWidth: 1, 
    borderColor: '#EBEBEB', 
    borderRadius: 15, 
    marginBottom: 12 
  },
  paymentOptionText: { fontSize: 16, marginLeft: 15, color: '#666' },
  professionalCardContainer: { padding: 20, backgroundColor: '#FAFAFA', borderRadius: 20, borderWidth: 1, borderColor: '#EEE', marginBottom: 15 },
  cardHeader: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 20 },
  inputWithIcon: { flexDirection: 'row', alignItems: 'center', backgroundColor: '#FFF', borderWidth: 1, borderColor: '#EBEBEB', borderRadius: 12, paddingHorizontal: 15, marginBottom: 15, height: 55, shadowColor: '#000', shadowOpacity: 0.02, shadowRadius: 5, elevation: 1 },
  inputIcon: { marginRight: 10 },
  proInput: { flex: 1, fontSize: 16, color: '#333' },
  row: { flexDirection: 'row' },
  footer: { padding: 20, paddingBottom: 35 },
  confirmBtn: { backgroundColor: '#D4AF37', height: 60, borderRadius: 15, justifyContent: 'center', alignItems: 'center', shadowColor: '#D4AF37', shadowOpacity: 0.4, shadowRadius: 10, elevation: 5 },
  confirmBtnText: { color: '#fff', fontSize: 18, fontWeight: 'bold', letterSpacing: 1 },
});
