import React, { useState } from 'react';
import { 
  View, 
  Text, 
  TextInput, 
  TouchableOpacity, 
  StyleSheet, 
  ActivityIndicator, 
  Alert, 
  SafeAreaView, 
  KeyboardAvoidingView, 
  Platform,
  ImageBackground,
  Dimensions
} from 'react-native';
import { useRouter } from 'expo-router';
import { useAuth } from '../../context/AuthContext';
import { useAppTheme } from '../../context/ThemeContext';
import { Colors } from '@/constants/theme';
import { Ionicons } from '@expo/vector-icons';

const { width, height } = Dimensions.get('window');

export default function LoginScreen() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  
  const { login } = useAuth();
  const { theme, toggleTheme, isDark } = useAppTheme();
  const router = useRouter();
  const colors = Colors[theme];

  const handleLogin = async () => {
    if (!email || !password) {
      Alert.alert('Error', 'Please fill in all fields');
      return;
    }
    setLoading(true);
    try {
      await login(email, password);
    } catch (error: any) {
      Alert.alert('Login Failed', error.response?.data?.message || 'Something went wrong');
    } finally {
      setLoading(false);
    }
  };

  return (
    <View style={styles.container}>
      <ImageBackground 
        source={{ uri: 'https://images.unsplash.com/photo-1490481651871-ab68de25d43d?q=80&w=2070&auto=format&fit=crop' }} 
        style={styles.backgroundImage}
      >
        <View style={[styles.overlay, { backgroundColor: isDark ? 'rgba(0,0,0,0.85)' : 'rgba(255,255,255,0.85)' }]}>
          <SafeAreaView style={styles.safeArea}>
            <KeyboardAvoidingView 
              behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
              style={styles.content}
            >
              <View style={styles.header}>
                <TouchableOpacity style={styles.themeToggle} onPress={toggleTheme}>
                  <Ionicons name={isDark ? "sunny" : "moon"} size={24} color="#D4AF37" />
                </TouchableOpacity>
                
                <View style={styles.logoContainer}>
                  <View style={[styles.logoBox, { backgroundColor: '#D4AF37' }]}>
                    <Ionicons name="diamond" size={40} color="#fff" />
                  </View>
                  <Text style={[styles.title, { color: isDark ? '#D4AF37' : '#B8860B' }]}>ZEEFASHION</Text>
                  <Text style={[styles.subtitle, { color: isDark ? '#ccc' : '#666' }]}>The Pinnacle of Style</Text>
                </View>
              </View>

              <View style={styles.form}>
                <View style={styles.inputContainer}>
                  <Ionicons name="mail-outline" size={20} color="#D4AF37" style={styles.inputIcon} />
                  <TextInput
                    style={[styles.input, { color: colors.text, borderColor: '#D4AF37', backgroundColor: isDark ? 'rgba(212,175,55,0.05)' : 'rgba(212,175,55,0.02)' }]}
                    placeholder="Email Address"
                    placeholderTextColor="#999"
                    value={email}
                    onChangeText={setEmail}
                    autoCapitalize="none"
                    keyboardType="email-address"
                  />
                </View>

                <View style={styles.inputContainer}>
                  <Ionicons name="lock-closed-outline" size={20} color="#D4AF37" style={styles.inputIcon} />
                  <TextInput
                    style={[styles.input, { color: colors.text, borderColor: '#D4AF37', backgroundColor: isDark ? 'rgba(212,175,55,0.05)' : 'rgba(212,175,55,0.02)' }]}
                    placeholder="Password"
                    placeholderTextColor="#999"
                    value={password}
                    onChangeText={setPassword}
                    secureTextEntry={!showPassword}
                  />
                  <TouchableOpacity onPress={() => setShowPassword(!showPassword)} style={styles.eyeIcon}>
                    <Ionicons name={showPassword ? "eye-off-outline" : "eye-outline"} size={20} color="#999" />
                  </TouchableOpacity>
                </View>

                <TouchableOpacity onPress={() => router.push('/(auth)/forgot-password')} style={styles.forgotBtn}>
                  <Text style={[styles.forgotText, { color: '#B8860B' }]}>Forgot Password?</Text>
                </TouchableOpacity>

                <TouchableOpacity 
                  style={[styles.loginBtn, { backgroundColor: '#D4AF37' }]} 
                  onPress={handleLogin} 
                  disabled={loading}
                >
                  {loading ? (
                    <ActivityIndicator color="#fff" />
                  ) : (
                    <Text style={styles.loginBtnText}>SIGN IN</Text>
                  )}
                </TouchableOpacity>
              </View>

              <View style={styles.footer}>
                <Text style={[styles.footerText, { color: colors.text }]}>Don't have an account? </Text>
                <TouchableOpacity onPress={() => router.push('/(auth)/register')}>
                  <Text style={[styles.signUpText, { color: '#B8860B' }]}>Sign Up</Text>
                </TouchableOpacity>
              </View>
            </KeyboardAvoidingView>
          </SafeAreaView>
        </View>
      </ImageBackground>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  backgroundImage: { width: width, height: height },
  overlay: { flex: 1 },
  safeArea: { flex: 1 },
  content: { flex: 1, padding: 30, justifyContent: 'center' },
  header: { alignItems: 'center', marginBottom: 50 },
  themeToggle: { position: 'absolute', top: 0, right: 0, padding: 10 },
  logoContainer: { alignItems: 'center' },
  logoBox: { width: 80, height: 80, borderRadius: 25, justifyContent: 'center', alignItems: 'center', marginBottom: 15, shadowColor: '#D4AF37', shadowOpacity: 0.5, shadowRadius: 15, elevation: 10 },
  title: { fontSize: 36, fontWeight: '900', letterSpacing: 2, fontFamily: Platform.OS === 'ios' ? 'Georgia' : 'serif' },
  subtitle: { fontSize: 12, marginTop: 5, letterSpacing: 4, textTransform: 'uppercase', fontWeight: '600' },
  form: { width: '100%' },
  inputContainer: { flexDirection: 'row', alignItems: 'center', marginBottom: 20, position: 'relative' },
  inputIcon: { position: 'absolute', left: 15, zIndex: 1 },
  input: { flex: 1, height: 60, borderWidth: 1.5, borderRadius: 20, paddingHorizontal: 50, fontSize: 16 },
  eyeIcon: { position: 'absolute', right: 15 },
  forgotBtn: { alignSelf: 'flex-end', marginBottom: 30 },
  forgotText: { fontSize: 14, fontWeight: '700' },
  loginBtn: { height: 60, borderRadius: 20, justifyContent: 'center', alignItems: 'center', shadowColor: '#000', shadowOpacity: 0.3, shadowRadius: 10, elevation: 8 },
  loginBtnText: { color: '#fff', fontSize: 18, fontWeight: '900', letterSpacing: 2 },
  footer: { flexDirection: 'row', justifyContent: 'center', marginTop: 40 },
  footerText: { fontSize: 15 },
  signUpText: { fontSize: 15, fontWeight: '900' },
});



