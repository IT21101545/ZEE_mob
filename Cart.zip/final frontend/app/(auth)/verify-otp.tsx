import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, ActivityIndicator, Alert, SafeAreaView, KeyboardAvoidingView, Platform } from 'react-native';
import { useRouter, useLocalSearchParams } from 'expo-router';
import { useAuth } from '../../context/AuthContext';
import { useAppTheme } from '../../context/ThemeContext';
import { Colors } from '@/constants/theme';
import { Ionicons } from '@expo/vector-icons';

export default function VerifyOtpScreen() {
  const { email } = useLocalSearchParams();
  const [otp, setOtp] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  
  const { verifyOtpAndReset } = useAuth();
  const { theme, isDark } = useAppTheme();
  const router = useRouter();
  const colors = Colors[theme];

  const handleVerifyAndReset = async () => {
    if (!otp || !newPassword) {
      Alert.alert('Error', 'Please enter the OTP and a new password');
      return;
    }
    
    setLoading(true);
    try {
      const emailStr = Array.isArray(email) ? email[0] : email;
      await verifyOtpAndReset(emailStr, otp, newPassword);
      Alert.alert('Success', 'Password has been reset successfully!', [
        { text: 'OK', onPress: () => router.push('/(auth)/login') }
      ]);
    } catch (error: any) {
      Alert.alert('Reset Failed', error.response?.data?.message || 'Invalid OTP or expired');
    } finally {
      setLoading(false);
    }
  };

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: colors.background }]}>
      <KeyboardAvoidingView 
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        style={styles.content}
      >
        <TouchableOpacity style={styles.backBtn} onPress={() => router.back()}>
          <Ionicons name="arrow-back" size={24} color={colors.text} />
        </TouchableOpacity>

        <View style={styles.header}>
          <View style={[styles.iconBox, { backgroundColor: colors.accent }]}>
            <Ionicons name="shield-checkmark-outline" size={40} color="#fff" />
          </View>
          <Text style={[styles.title, { color: colors.text }]}>Verify Identity</Text>
          <Text style={styles.subtitle}>Enter the 6-digit code sent to {email}</Text>
        </View>

        <View style={styles.form}>
          <View style={styles.inputContainer}>
            <Ionicons name="apps-outline" size={20} color={colors.accent} style={styles.inputIcon} />
            <TextInput
              style={[styles.input, { color: colors.text, borderColor: colors.border }]}
              placeholder="6-Digit OTP Code"
              placeholderTextColor="#999"
              value={otp}
              onChangeText={setOtp}
              keyboardType="numeric"
              maxLength={6}
            />
          </View>

          <View style={styles.inputContainer}>
            <Ionicons name="lock-closed-outline" size={20} color={colors.accent} style={styles.inputIcon} />
            <TextInput
              style={[styles.input, { color: colors.text, borderColor: colors.border }]}
              placeholder="Set New Password"
              placeholderTextColor="#999"
              value={newPassword}
              onChangeText={setNewPassword}
              secureTextEntry={!showPassword}
            />
            <TouchableOpacity onPress={() => setShowPassword(!showPassword)} style={styles.eyeIcon}>
              <Ionicons name={showPassword ? "eye-off-outline" : "eye-outline"} size={20} color="#999" />
            </TouchableOpacity>
          </View>

          <TouchableOpacity 
            style={[styles.verifyBtn, { backgroundColor: colors.accent }]} 
            onPress={handleVerifyAndReset} 
            disabled={loading}
          >
            {loading ? (
              <ActivityIndicator color="#fff" />
            ) : (
              <Text style={styles.verifyBtnText}>Verify & Reset</Text>
            )}
          </TouchableOpacity>
        </View>

        <View style={styles.footer}>
          <TouchableOpacity onPress={() => router.back()}>
            <Text style={[styles.wrongEmailText, { color: colors.accent }]}>Wrong email? Go back</Text>
          </TouchableOpacity>
        </View>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  content: { flex: 1, padding: 30, justifyContent: 'center' },
  backBtn: { position: 'absolute', top: 50, left: 30, padding: 10 },
  header: { alignItems: 'center', marginBottom: 40 },
  iconBox: { width: 80, height: 80, borderRadius: 25, justifyContent: 'center', alignItems: 'center', marginBottom: 20 },
  title: { fontSize: 32, fontWeight: 'bold', letterSpacing: 1 },
  subtitle: { fontSize: 15, color: '#999', marginTop: 10, textAlign: 'center' },
  form: { width: '100%' },
  inputContainer: { flexDirection: 'row', alignItems: 'center', marginBottom: 20, position: 'relative' },
  inputIcon: { position: 'absolute', left: 15, zIndex: 1 },
  input: { flex: 1, height: 60, borderWidth: 1, borderRadius: 20, paddingHorizontal: 50, fontSize: 16, backgroundColor: 'rgba(0,0,0,0.02)' },
  eyeIcon: { position: 'absolute', right: 15 },
  verifyBtn: { height: 60, borderRadius: 20, justifyContent: 'center', alignItems: 'center', marginTop: 10, shadowColor: '#000', shadowOpacity: 0.2, shadowRadius: 10, elevation: 5 },
  verifyBtnText: { color: '#fff', fontSize: 18, fontWeight: 'bold' },
  footer: { alignItems: 'center', marginTop: 40 },
  wrongEmailText: { fontSize: 15, fontWeight: 'bold' },
});

