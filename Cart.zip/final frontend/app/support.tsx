import React, { useState } from 'react';
import { 
  View, 
  Text, 
  StyleSheet, 
  ScrollView, 
  TouchableOpacity, 
  SafeAreaView, 
  Dimensions,
  LayoutAnimation,
  Platform,
  UIManager
} from 'react-native';
import { Ionicons, MaterialIcons, FontAwesome5 } from '@expo/vector-icons';
import { useRouter, Stack } from 'expo-router';
import { useAppTheme } from '../context/ThemeContext';
import { Colors } from '@/constants/theme';

const { width } = Dimensions.get('window');

if (Platform.OS === 'android' && UIManager.setLayoutAnimationEnabledExperimental) {
  UIManager.setLayoutAnimationEnabledExperimental(true);
}

const FAQ_DATA = [
  {
    category: 'Orders & Delivery',
    icon: 'local-shipping',
    questions: [
      { q: 'How long does delivery take?', a: 'Standard delivery within Colombo takes 1-2 business days. Outstation deliveries typically take 3-5 business days.' },
      { q: 'How can I track my order?', a: 'Once your order is shipped, go to "My Orders" and click on the specific order to see the real-time tracking status.' },
      { q: 'Can I change my delivery address?', a: 'You can change your address before the order is "Shipped". Please contact support immediately for urgent changes.' },
    ]
  },
  {
    category: 'Payments',
    icon: 'payments',
    questions: [
      { q: 'What payment methods do you accept?', a: 'We accept Credit/Debit Cards, Cash on Delivery (COD), and Bank Deposits. For Bank Deposits, you must upload a photo of the deposit slip.' },
      { q: 'Is my card information secure?', a: 'Yes, we use industry-standard encryption and do not store your full card details on our servers.' },
      { q: 'How do I upload a bank slip?', a: 'During checkout, select "Bank Deposit". You will see an option to upload your slip image directly from your gallery.' },
    ]
  },
  {
    category: 'Products & Quality',
    icon: 'check-circle',
    questions: [
      { q: 'Are the textiles genuine?', a: 'Absolutely. ZEEFASHION prides itself on sourcing only high-quality, authentic fabrics including 100% pure silk and organic cotton.' },
      { q: 'Can I request a custom design?', a: 'Yes! On the product detail page, use the "Personalize" section to upload your own design or pattern for our master tailors.' },
      { q: 'What if the fabric is damaged?', a: 'We have a strict quality check, but if you receive a defective item, you can initiate a return within 7 days for a full refund.' },
    ]
  }
];

const TUTORIAL_STEPS = [
  {
    title: '1. Discover Styles',
    desc: 'Browse our curated collections of premium textiles and luxury wear.',
    icon: 'search'
  },
  {
    title: '2. Personalize',
    desc: 'Choose your size and even upload your own designs for a unique touch.',
    icon: 'create'
  },
  {
    title: '3. Easy Checkout',
    desc: 'Select your preferred payment method. We support Cards, COD, and Bank Deposits.',
    icon: 'card'
  },
  {
    title: '4. Real-time Tracking',
    desc: 'Monitor your package from our warehouse to your doorstep with live updates.',
    icon: 'map'
  }
];

export default function SupportScreen() {
  const router = useRouter();
  const { theme, isDark } = useAppTheme();
  const colors = Colors[theme];
  const [expandedIndex, setExpandedIndex] = useState<string | null>(null);

  const toggleExpand = (id: string) => {
    LayoutAnimation.configureNext(LayoutAnimation.Presets.easeInEaseOut);
    setExpandedIndex(expandedIndex === id ? null : id);
  };

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: colors.background }]}>
      <Stack.Screen options={{ 
        headerShown: true, 
        title: 'Help & Support',
        headerTransparent: false,
        headerStyle: { backgroundColor: colors.background },
        headerTitleStyle: { color: colors.text, fontWeight: 'bold' },
        headerLeft: () => (
          <TouchableOpacity onPress={() => router.back()} style={{ marginLeft: 10 }}>
            <Ionicons name="arrow-back" size={24} color={colors.text} />
          </TouchableOpacity>
        )
      }} />

      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.scrollContent}>
        
        {/* Tutorial Section */}
        <View style={styles.section}>
          <Text style={[styles.sectionTitle, { color: colors.text }]}>How It Works</Text>
          <View style={[styles.tutorialCard, { backgroundColor: colors.card }]}>
            {TUTORIAL_STEPS.map((step, i) => (
              <View key={i} style={styles.stepItem}>
                <View style={[styles.stepIcon, { backgroundColor: colors.accent + '20' }]}>
                  <Ionicons name={step.icon as any} size={20} color={colors.accent} />
                </View>
                <View style={styles.stepContent}>
                  <Text style={[styles.stepTitle, { color: colors.text }]}>{step.title}</Text>
                  <Text style={styles.stepDesc}>{step.desc}</Text>
                </View>
                {i < TUTORIAL_STEPS.length - 1 && <View style={[styles.stepLine, { backgroundColor: colors.border }]} />}
              </View>
            ))}
          </View>
        </View>

        {/* FAQ Section */}
        <View style={styles.section}>
          <Text style={[styles.sectionTitle, { color: colors.text }]}>Common Questions</Text>
          {FAQ_DATA.map((cat, catIdx) => (
            <View key={catIdx} style={styles.categoryBox}>
              <View style={styles.categoryHeader}>
                <MaterialIcons name={cat.icon as any} size={20} color={colors.accent} />
                <Text style={[styles.categoryTitle, { color: colors.text }]}>{cat.category}</Text>
              </View>
              
              {cat.questions.map((q, qIdx) => {
                const id = `${catIdx}-${qIdx}`;
                const isExpanded = expandedIndex === id;
                return (
                  <TouchableOpacity 
                    key={id} 
                    style={[styles.faqItem, { backgroundColor: colors.card, borderColor: colors.border }]}
                    onPress={() => toggleExpand(id)}
                    activeOpacity={0.7}
                  >
                    <View style={styles.faqHeader}>
                      <Text style={[styles.questionText, { color: colors.text }]}>{q.q}</Text>
                      <Ionicons name={isExpanded ? "chevron-up" : "chevron-down"} size={18} color="#999" />
                    </View>
                    {isExpanded && (
                      <View style={styles.answerBox}>
                        <Text style={styles.answerText}>{q.a}</Text>
                      </View>
                    )}
                  </TouchableOpacity>
                );
              })}
            </View>
          ))}
        </View>

        {/* Contact Support */}
        <View style={[styles.contactCard, { backgroundColor: colors.accent }]}>
          <View style={styles.contactInfo}>
            <Text style={styles.contactTitle}>Still need help?</Text>
            <Text style={styles.contactSubtitle}>Our support team is available 24/7 to assist you.</Text>
          </View>
          <View style={styles.contactButtons}>
            <TouchableOpacity style={styles.contactBtn}>
              <Ionicons name="chatbubble-ellipses" size={20} color={colors.accent} />
              <Text style={[styles.contactBtnText, { color: colors.accent }]}>Live Chat</Text>
            </TouchableOpacity>
            <TouchableOpacity style={[styles.contactBtn, { backgroundColor: 'transparent', borderWidth: 1, borderColor: '#fff' }]}>
              <Ionicons name="mail" size={20} color="#fff" />
              <Text style={[styles.contactBtnText, { color: '#fff' }]}>Email Us</Text>
            </TouchableOpacity>
          </View>
        </View>

        <View style={styles.footer}>
          <Text style={styles.footerText}>ZEEFASHION - Version 2.1.0</Text>
          <Text style={styles.footerText}>© 2026 Textile Management System</Text>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  scrollContent: { padding: 20, paddingBottom: 40 },
  section: { marginBottom: 30 },
  sectionTitle: { fontSize: 20, fontWeight: 'bold', marginBottom: 15 },
  tutorialCard: { borderRadius: 20, padding: 20, elevation: 2, shadowColor: '#000', shadowOpacity: 0.05, shadowRadius: 10 },
  stepItem: { flexDirection: 'row', marginBottom: 25, position: 'relative' },
  stepIcon: { width: 40, height: 40, borderRadius: 12, justifyContent: 'center', alignItems: 'center', marginRight: 15 },
  stepContent: { flex: 1 },
  stepTitle: { fontSize: 16, fontWeight: 'bold', marginBottom: 4 },
  stepDesc: { fontSize: 13, color: '#888', lineHeight: 18 },
  stepLine: { position: 'absolute', left: 20, top: 45, width: 1, height: 20 },
  categoryBox: { marginBottom: 20 },
  categoryHeader: { flexDirection: 'row', alignItems: 'center', marginBottom: 12, marginLeft: 5 },
  categoryTitle: { fontSize: 14, fontWeight: 'bold', marginLeft: 10, textTransform: 'uppercase', letterSpacing: 1, opacity: 0.7 },
  faqItem: { borderRadius: 15, padding: 15, marginBottom: 10, borderWidth: 1 },
  faqHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  questionText: { fontSize: 15, fontWeight: '600', flex: 1, marginRight: 10 },
  answerBox: { marginTop: 12, paddingTop: 12, borderTopWidth: 1, borderTopColor: '#f0f0f0' },
  answerText: { fontSize: 14, color: '#666', lineHeight: 20 },
  contactCard: { borderRadius: 25, padding: 25, flexDirection: 'column' },
  contactTitle: { color: '#fff', fontSize: 22, fontWeight: 'bold', marginBottom: 5 },
  contactSubtitle: { color: 'rgba(255,255,255,0.8)', fontSize: 14, marginBottom: 20 },
  contactButtons: { flexDirection: 'row' },
  contactBtn: { backgroundColor: '#fff', flexDirection: 'row', alignItems: 'center', paddingHorizontal: 15, paddingVertical: 10, borderRadius: 12, marginRight: 10 },
  contactBtnText: { fontWeight: 'bold', marginLeft: 8, fontSize: 14 },
  footer: { alignItems: 'center', marginTop: 20 },
  footerText: { fontSize: 12, color: '#999', marginBottom: 5 }
});
