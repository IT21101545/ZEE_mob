const mongoose = require('mongoose');

const productSchema = new mongoose.Schema({
  name:          { type: String, required: true, trim: true },
  description:   { type: String, required: true },
  price:         { type: Number, required: true, min: 0 },
  category:      { type: String, required: true },
  sizes:         { type: [String], default: [] },
  stock:         { type: Number, required: true, min: 0, default: 0 },
  image:         { type: String, default: '' },
  images:        [{ type: String }],  // additional product photos
  imagePublicId: { type: String, default: '' },
  createdBy:     { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true }
}, { 
  timestamps: true,
  toJSON: {
    transform: function(doc, ret, options) {
      // Note: req is usually not available here unless passed via options
      // But we can at least ensure relative paths are returned if we want
      // Actually, it's better to do this in the controller or a middleware
      return ret;
    }
  }
});

module.exports = mongoose.model('Product', productSchema);
