const Cart    = require('../models/Cart');
const Product = require('../models/Product');
const { toBase64 } = require('../config/cloudinary');

const populateCart = (cart) =>
  cart.populate({ path: 'items.product', select: 'name price image stock' });

// GET /api/cart
const getCart = async (req, res) => {
  try {
    let cart = await Cart.findOne({ user: req.user._id });
    if (!cart) cart = await Cart.create({ user: req.user._id, items: [] });
    await populateCart(cart);

    // Filter out items where the product no longer exists
    const beforeCount = cart.items.length;
    const validItems = cart.items.filter(item => item.product);
    if (validItems.length !== beforeCount) {
      cart = await Cart.findOneAndUpdate(
        { _id: cart._id },
        { items: validItems },
        { new: true }
      );
      await populateCart(cart);
    }

    const total = cart.items.reduce(
      (sum, item) => sum + (item.product?.price || 0) * item.quantity, 0
    );
    res.json({ cart, total });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

// POST /api/cart/add
const addToCart = async (req, res) => {
  try {
    const { productId, quantity = 1 } = req.body;
    if (!productId) return res.status(400).json({ message: 'Product ID is required' });

    const product = await Product.findById(productId);
    if (!product) return res.status(404).json({ message: 'Product not found' });
    if (product.stock < quantity)
      return res.status(400).json({ message: 'Insufficient stock' });

    const customFile = toBase64(req.file);

    // Use findOneAndUpdate with $push/$set to avoid versioning (Optimistic Lock) errors
    let cart = await Cart.findOne({ user: req.user._id });
    if (!cart) {
      cart = await Cart.create({ user: req.user._id, items: [] });
    }

    const existingItemIndex = cart.items.findIndex(i => i.product.toString() === productId);
    
    if (existingItemIndex > -1) {
      // Update existing item
      const updateObj = { 
        $inc: { [`items.${existingItemIndex}.quantity`]: Number(quantity) } 
      };
      if (customFile) {
        updateObj.$set = { [`items.${existingItemIndex}.customFile`]: customFile };
      }
      cart = await Cart.findOneAndUpdate(
        { _id: cart._id },
        updateObj,
        { new: true }
      );
    } else {
      // Add new item
      cart = await Cart.findOneAndUpdate(
        { _id: cart._id },
        { $push: { items: { product: productId, quantity: Number(quantity), customFile } } },
        { new: true }
      );
    }

    await populateCart(cart);
    res.json(cart);
  } catch (err) {
    console.error('Add to cart error:', err);
    res.status(500).json({ message: 'Error adding to cart' });
  }
};

// PUT /api/cart/update
const updateCartItem = async (req, res) => {
  try {
    const { productId, quantity } = req.body;
    if (!productId || quantity === undefined)
      return res.status(400).json({ message: 'productId and quantity are required' });

    let cart = await Cart.findOne({ user: req.user._id });
    if (!cart) return res.status(404).json({ message: 'Cart not found' });

    const existingItemIndex = cart.items.findIndex(i => i.product.toString() === productId);
    if (existingItemIndex === -1) return res.status(404).json({ message: 'Item not in cart' });

    if (quantity <= 0) {
      cart = await Cart.findOneAndUpdate(
        { _id: cart._id },
        { $pull: { items: { product: productId } } },
        { new: true }
      );
    } else {
      cart = await Cart.findOneAndUpdate(
        { _id: cart._id, "items.product": productId },
        { $set: { "items.$.quantity": Number(quantity) } },
        { new: true }
      );
    }

    await populateCart(cart);
    res.json(cart);
  } catch (err) {
    console.error('Update cart error:', err);
    res.status(500).json({ message: 'Error updating cart' });
  }
};

// DELETE /api/cart/remove/:productId
const removeFromCart = async (req, res) => {
  try {
    const cart = await Cart.findOneAndUpdate(
      { user: req.user._id },
      { $pull: { items: { product: req.params.productId } } },
      { new: true }
    );
    
    if (!cart) return res.status(404).json({ message: 'Cart not found' });

    await populateCart(cart);
    res.json(cart);
  } catch (err) {
    console.error('Remove from cart error:', err);
    res.status(500).json({ message: 'Error removing from cart' });
  }
};

// DELETE /api/cart/clear
const clearCart = async (req, res) => {
  try {
    await Cart.findOneAndUpdate({ user: req.user._id }, { items: [] });
    res.json({ message: 'Cart cleared' });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

module.exports = { getCart, addToCart, updateCartItem, removeFromCart, clearCart };
