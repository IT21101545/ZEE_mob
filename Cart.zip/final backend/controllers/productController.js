const Product  = require('../models/Product');
const { toBase64 } = require('../config/cloudinary');

// GET /api/products
const getProducts = async (req, res) => {
  try {
    const { category, search } = req.query;
    const filter = {};
    if (category) filter.category = category;
    if (search)   filter.name = { $regex: search, $options: 'i' };

    // Exclude additional images array in the list view to reduce payload size
    const products = await Product.find(filter)
      .select('-images') 
      .sort({ createdAt: -1 });
    res.json(products);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

// GET /api/products/:id
const getProductById = async (req, res) => {
  try {
    const product = await Product.findById(req.params.id);
    if (!product) return res.status(404).json({ message: 'Product not found' });
    res.json(product);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

// POST /api/products  (admin)
const createProduct = async (req, res) => {
  try {
    const { name, description, price, category, stock } = req.body;
    if (!name || !description || !price || !category)
      return res.status(400).json({ message: 'All fields are required' });

    // Main image
    const mainImage = req.files?.image?.[0] ? toBase64(req.files.image[0]) : '';

    // Additional images
    const additionalImages = (req.files?.images || []).map(f => toBase64(f));

    const product = await Product.create({
      name, description, price, category, stock,
      image: mainImage,
      images: additionalImages,
      createdBy: req.user._id,
    });
    res.status(201).json(product);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

// PUT /api/products/:id  (admin)
const updateProduct = async (req, res) => {
  try {
    const product = await Product.findById(req.params.id);
    if (!product) return res.status(404).json({ message: 'Product not found' });

    const { name, description, price, category, stock } = req.body;
    product.name        = name        || product.name;
    product.description = description || product.description;
    product.price       = price       !== undefined ? price : product.price;
    product.category    = category    || product.category;
    product.stock       = stock       !== undefined ? stock : product.stock;

    // Update main image if provided
    if (req.files?.image?.[0]) {
      product.image = toBase64(req.files.image[0]);
    }

    // Update additional images if provided
    if (req.files?.images?.length > 0) {
      const newImages = req.files.images.map(f => toBase64(f));
      // Keep existing images from body if sent, otherwise append
      const keepExisting = req.body.keepExistingImages === 'true';
      product.images = keepExisting 
        ? [...(product.images || []), ...newImages]
        : newImages;
    }

    const updated = await product.save();
    res.json(updated);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

// DELETE /api/products/:id  (admin)
const deleteProduct = async (req, res) => {
  try {
    const product = await Product.findById(req.params.id);
    if (!product) return res.status(404).json({ message: 'Product not found' });

    await product.deleteOne();
    res.json({ message: 'Product deleted' });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

module.exports = { getProducts, getProductById, createProduct, updateProduct, deleteProduct };
