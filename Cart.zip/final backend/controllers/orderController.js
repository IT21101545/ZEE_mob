const Order = require('../models/Order');
const Product = require('../models/Product');
const User = require('../models/User');
const { toBase64 } = require('../config/cloudinary');

// POST /api/orders
const addOrderItems = async (req, res) => {
  try {
    console.log('[OrderService] New order request received');
    
    const {
      orderItems,
      shippingAddress,
      paymentMethod,
      itemsPrice,
      taxPrice,
      shippingPrice,
      totalPrice,
      isPaid
    } = req.body;

    // Explicitly parse stringified FormData fields
    let parsedItems = orderItems;
    let parsedAddress = shippingAddress;

    try {
      if (typeof orderItems === 'string') parsedItems = JSON.parse(orderItems);
      if (typeof shippingAddress === 'string') parsedAddress = JSON.parse(shippingAddress);
      
      // Safety check for double stringification
      if (typeof parsedItems === 'string') parsedItems = JSON.parse(parsedItems);
      if (typeof parsedAddress === 'string') parsedAddress = JSON.parse(parsedAddress);
    } catch (e) {
      console.error('[OrderService] JSON Parse Error:', e);
      return res.status(400).json({ message: 'Invalid data format for items or address' });
    }

    if (!parsedItems || (Array.isArray(parsedItems) && parsedItems.length === 0)) {
      return res.status(400).json({ message: 'No order items' });
    }

    const attachment = toBase64(req.file);

    const order = new Order({
      orderItems: parsedItems,
      user: req.user._id,
      shippingAddress: parsedAddress,
      paymentMethod: paymentMethod || 'Cash on Delivery',
      itemsPrice: Number(itemsPrice) || 0,
      taxPrice: Number(taxPrice) || 0,
      shippingPrice: Number(shippingPrice) || 0,
      totalPrice: Number(totalPrice) || 0,
      isPaid: isPaid === 'true' || isPaid === true,
      paidAt: (isPaid === 'true' || isPaid === true) ? Date.now() : undefined,
      attachment,
    });

    const createdOrder = await order.save();
    console.log(`[OrderService] Order created successfully: ${createdOrder._id}`);

    // Notify admin about new order
    try {
      const { createNotification } = require('./notificationController');
      const AdminUser = await User.findOne({ role: 'admin' });
      if (AdminUser) {
        await createNotification({
          recipient: AdminUser._id,
          type: 'new_order',
          title: 'New Order Received',
          message: `Order #${String(createdOrder._id).slice(-6).toUpperCase()} placed by ${req.user.name}`,
          order: createdOrder._id
        });
      }
    } catch (notifErr) {
      console.warn('[OrderService] Failed to send admin notification:', notifErr.message);
    }

    res.status(201).json(createdOrder);
  } catch (err) {
    console.error('[OrderService] Error in addOrderItems:', err);
    res.status(500).json({ message: 'Server error creating order', details: err.message });
  }
};

// GET /api/orders/myorders
const getMyOrders = async (req, res) => {
  try {
    if (!req.user || !req.user._id) {
      console.warn('getMyOrders called without authenticated user');
      return res.status(401).json({ message: 'Not authorized' });
    }

    console.log(`[OrderService] Fetching orders for user: ${req.user._id}`);
    const orders = await Order.find({ user: req.user._id }).sort({ createdAt: -1 }).lean();
    
    console.log(`[OrderService] Found ${orders.length} orders for user: ${req.user._id}`);
    res.json(orders);
  } catch (err) {
    console.error(`[OrderService] Error fetching orders for user ${req.user?._id}:`, err);
    res.status(500).json({ 
      message: 'Error fetching your orders. Please try again later.',
      details: process.env.NODE_ENV === 'development' ? err.message : undefined
    });
  }
};

// GET /api/orders/:id
const getOrderById = async (req, res) => {
  try {
    const mongoose = require('mongoose');
    if (!mongoose.Types.ObjectId.isValid(req.params.id)) {
      return res.status(400).json({ message: 'Invalid Order ID format' });
    }

    const order = await Order.findById(req.params.id).populate('user', 'name email');
    if (order) {
      res.json(order);
    } else {
      res.status(404).json({ message: 'Order not found' });
    }
  } catch (err) {
    console.error('Error in getOrderById:', err);
    res.status(500).json({ message: 'Server error retrieving order' });
  }
};

// PUT /api/orders/:id/status (admin)
const updateOrderStatus = async (req, res) => {
  try {
    const order = await Order.findById(req.params.id);
    if (order) {
      order.status = req.body.status || order.status;
      if (order.status === 'Delivered') {
        order.isDelivered = true;
        order.deliveredAt = Date.now();
      }
      const updatedOrder = await order.save();

      // Notify customer about status change
      const { createNotification } = require('./notificationController');
      await createNotification({
        recipient: order.user,
        type: 'order_status',
        title: 'Order Updated',
        message: `Your order #${String(order._id).slice(-6).toUpperCase()} is now ${order.status}.`,
        order: order._id
      });

      res.json(updatedOrder);
    } else {
      res.status(404).json({ message: 'Order not found' });
    }
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

// GET /api/orders/stats (admin)
const getAdminStats = async (req, res) => {
  try {
    const Review = require('../models/Review');
    const Message = require('../models/Message');
    const orderCount = await Order.countDocuments();
    const productCount = await Product.countDocuments();
    const userCount = await User.countDocuments();
    
    const unreadOrdersCount = await Order.countDocuments({ isAdminRead: false });
    const unreadReviewsCount = await Review.countDocuments({ isAdminRead: false });
    const unreadMessagesCount = await Message.countDocuments({ sender: { $ne: req.user._id }, isRead: false });

    const orders = await Order.find({ status: { $ne: 'Cancelled' } });
    const totalRevenue = orders.reduce((acc, order) => acc + (order.totalPrice || 0), 0);

    res.json({
      orderCount,
      productCount,
      userCount,
      unreadOrdersCount,
      unreadReviewsCount,
      unreadMessagesCount,
      totalRevenue: totalRevenue.toFixed(2),
    });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

// PUT /api/orders/mark-read (admin)
const markOrdersAsRead = async (req, res) => {
  try {
    await Order.updateMany({ isAdminRead: false }, { isAdminRead: true });
    res.json({ message: 'Orders marked as read' });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

// GET /api/orders (admin)
const getOrders = async (req, res) => {
  try {
    const orders = await Order.find({}).populate('user', '_id name').sort({ createdAt: -1 });
    res.json(orders);
  } catch (err) {
    console.error('Error in getOrders:', err);
    res.status(500).json({ message: err.message });
  }
};

module.exports = {
  addOrderItems,
  getMyOrders,
  getOrderById,
  updateOrderStatus,
  getOrders,
  getAdminStats,
  markOrdersAsRead,
};
