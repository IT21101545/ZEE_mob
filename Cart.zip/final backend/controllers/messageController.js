const Message = require('../models/Message');
const Order = require('../models/Order');
const User = require('../models/User');
const { createNotification } = require('./notificationController');

// POST /api/messages
const sendMessage = async (req, res) => {
  try {
    const { orderId, text } = req.body;
    if (!orderId || !text) {
      return res.status(400).json({ message: 'Order ID and text are required' });
    }

    const order = await Order.findById(orderId);
    if (!order) {
      return res.status(404).json({ message: 'Order not found' });
    }

    const message = await Message.create({
      order: orderId,
      sender: req.user._id,
      text,
    });

    // Determine recipient
    let recipientId;
    if (req.user.role === 'admin') {
      recipientId = order.user;
    } else {
      // Find an admin to notify (or notify all admins)
      // For simplicity, we'll notify the customer if admin sent it, 
      // or all admins if customer sent it.
      const admins = await User.find({ role: 'admin' });
      // For notifications, we might need a more complex system, but let's notify the first admin for now or all.
      for (const admin of admins) {
        await createNotification({
          recipient: admin._id,
          type: 'chat_message',
          title: `New Message - Order #${order._id.toString().slice(-6).toUpperCase()}`,
          message: text,
          order: orderId,
        });
      }
      return res.status(201).json(message);
    }

    // If admin sent it, notify the customer
    await createNotification({
      recipient: recipientId,
      type: 'chat_message',
      title: 'New Message from Support',
      message: text,
      order: orderId,
    });

    res.status(201).json(message);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

// GET /api/messages/:orderId
const getMessages = async (req, res) => {
  try {
    const messages = await Message.find({ order: req.params.orderId })
      .populate('sender', 'name role')
      .sort({ createdAt: 1 });
    res.json(messages);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

// PUT /api/messages/:orderId/read
const markAsRead = async (req, res) => {
  try {
    // Mark messages as read where sender is NOT the current user
    await Message.updateMany(
      { order: req.params.orderId, sender: { $ne: req.user._id }, isRead: false },
      { isRead: true }
    );
    res.json({ message: 'Messages marked as read' });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

// GET /api/messages/unread-counts
const getUnreadCounts = async (req, res) => {
  try {
    const counts = await Message.aggregate([
      { $match: { sender: { $ne: req.user._id }, isRead: false } },
      { $group: { _id: '$order', count: { $sum: 1 } } }
    ]);
    res.json(counts);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

module.exports = {
  sendMessage,
  getMessages,
  markAsRead,
  getUnreadCounts,
};
