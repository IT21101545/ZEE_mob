const Wishlist = require('../models/Wishlist');

// GET /api/wishlist
const getWishlist = async (req, res) => {
  try {
    let wl = await Wishlist.findOne({ user: req.user._id }).populate('products');
    if (!wl) wl = await Wishlist.create({ user: req.user._id, products: [] });
    res.json(wl.products);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

// POST /api/wishlist/toggle/:productId
const toggleWishlist = async (req, res) => {
  try {
    let wl = await Wishlist.findOne({ user: req.user._id });
    if (!wl) wl = await Wishlist.create({ user: req.user._id, products: [] });

    const idx = wl.products.indexOf(req.params.productId);
    if (idx > -1) {
      wl.products.splice(idx, 1);
    } else {
      wl.products.push(req.params.productId);
    }
    await wl.save();
    await wl.populate('products');
    res.json({ products: wl.products, added: idx === -1 });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

// GET /api/wishlist/check/:productId
const checkWishlist = async (req, res) => {
  try {
    const wl = await Wishlist.findOne({ user: req.user._id });
    const inWishlist = wl ? wl.products.includes(req.params.productId) : false;
    res.json({ inWishlist });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

module.exports = { getWishlist, toggleWishlist, checkWishlist };
