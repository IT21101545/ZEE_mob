const express = require('express');
const router = express.Router();
const {
  sendMessage,
  getMessages,
  markAsRead,
  getUnreadCounts,
} = require('../controllers/messageController');
const { protect } = require('../middleware/authMiddleware');

router.route('/')
  .post(protect, sendMessage);

router.route('/unread-counts')
  .get(protect, getUnreadCounts);

router.route('/:orderId')
  .get(protect, getMessages);

router.route('/:orderId/read')
  .put(protect, markAsRead);

module.exports = router;
