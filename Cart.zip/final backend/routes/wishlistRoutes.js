const express = require('express');
const router = express.Router();
const { protect } = require('../middleware/authMiddleware');
const { getWishlist, toggleWishlist, checkWishlist } = require('../controllers/wishlistController');

router.get('/', protect, getWishlist);
router.post('/toggle/:productId', protect, toggleWishlist);
router.get('/check/:productId', protect, checkWishlist);

module.exports = router;
