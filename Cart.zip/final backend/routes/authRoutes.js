const express = require('express');
const router = express.Router();
const { register, login, getProfile, updateProfile, getAllUsers, deleteUser, requestOtp, verifyOtpAndReset, updateUserRole, toggleUserBlock } = require('../controllers/authController');
const { protect, admin } = require('../middleware/authMiddleware');
const { upload } = require('../config/cloudinary');

router.post('/register', register);
router.post('/login', login);
router.post('/request-otp', requestOtp);
router.post('/verify-otp', verifyOtpAndReset);

router.get('/profile', protect, getProfile);
router.put('/profile', protect, upload.single('avatar'), updateProfile);

router.get('/users', protect, admin, getAllUsers);
router.put('/users/:id/role', protect, admin, updateUserRole);
router.put('/users/:id/block', protect, admin, toggleUserBlock);
router.delete('/users/:id', protect, admin, deleteUser);

module.exports = router;
