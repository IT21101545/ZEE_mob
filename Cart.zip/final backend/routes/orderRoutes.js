const express = require('express');
const router = express.Router();
const {
  addOrderItems,
  getMyOrders,
  getOrderById,
  updateOrderStatus,
  getOrders,
  getAdminStats,
  markOrdersAsRead,
} = require('../controllers/orderController');
const { protect, admin } = require('../middleware/authMiddleware');

router.route('/mark-read').put(protect, admin, markOrdersAsRead);
const { upload } = require('../config/cloudinary');

router.route('/').post(protect, upload.single('attachment'), addOrderItems).get(protect, admin, getOrders);
router.route('/stats').get(protect, admin, getAdminStats);
router.route('/myorders').get(protect, getMyOrders);

router.route('/:id').get(protect, getOrderById);

router.route('/:id/status').put(protect, admin, updateOrderStatus);

module.exports = router;
