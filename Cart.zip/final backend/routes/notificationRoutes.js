const express = require('express');
const router = express.Router();
const { protect } = require('../middleware/authMiddleware');
const { 
  getNotifications, 
  markAsRead, 
  markAllAsRead, 
  getUnreadCount 
} = require('../controllers/notificationController');

router.get('/',          protect, getNotifications);
router.get('/unread',    protect, getUnreadCount);
router.put('/read-all',  protect, markAllAsRead);
router.put('/:id/read',  protect, markAsRead);

module.exports = router;
