const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
require('dotenv').config();

const { logListenHelp } = require('./utils/lanInfo');

const app = express();

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Routes
app.use('/api/auth',     require('./routes/authRoutes'));
app.use('/api/products', require('./routes/productRoutes'));
app.use('/api/orders',   require('./routes/orderRoutes'));
app.use('/api/cart',     require('./routes/cartRoutes'));
app.use('/api/payments', require('./routes/paymentRoutes'));
app.use('/api/reviews',  require('./routes/reviewRoutes'));

app.get('/', (req, res) => res.json({ message: 'ShopMate API running' }));

const PORT = Number(process.env.PORT) || 5000;
// Listen on all interfaces so phones / other PCs on your LAN can reach this API.
const BIND_HOST = process.env.BIND_HOST || '0.0.0.0';

// Start HTTP immediately so you can verify http://<LAN-IP>:PORT/ in a browser even if MongoDB is still connecting or unreachable.
app.listen(PORT, BIND_HOST, () => {
  console.log(`API listening on http://127.0.0.1:${PORT} (this PC)`);
  logListenHelp(PORT);
});

mongoose
  .connect(process.env.MONGO_URI)
  .then(() => console.log('MongoDB connected'))
  .catch((err) => {
    console.error('MongoDB connection failed — fix MONGO_URI / network; DB routes will fail until connected.');
    console.error(err.message || err);
  });
