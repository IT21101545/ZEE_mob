const os = require('os');

/** Non-loopback IPv4 addresses (typical Wi‑Fi / Ethernet). */
function getLanIPv4s() {
  const nets = os.networkInterfaces();
  const out = [];
  for (const name of Object.keys(nets)) {
    for (const net of nets[name] || []) {
      if (net.family === 'IPv4' && !net.internal) out.push(net.address);
    }
  }
  return out;
}

function logListenHelp(port) {
  const ips = getLanIPv4s();
  console.log('\n--- Connect from phone / tablet (same Wi‑Fi) ---');
  if (ips.length === 0) {
    console.log('No LAN IPv4 found. Check Wi‑Fi / Ethernet.');
  } else {
    ips.forEach((ip) => {
      console.log(`  Browser test: http://${ip}:${port}/`);
      console.log(`  Expo .env:    EXPO_PUBLIC_API_URL=http://${ip}:${port}/api`);
    });
  }
  console.log('(Use a real address like 192.168.x.x — not the words "your_pc_lan_ip".)\n');
}

module.exports = { getLanIPv4s, logListenHelp };
