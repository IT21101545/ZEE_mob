const Product = require('../models/Product');
const { cloudinary } = require('../config/cloudinary');

// Validation helper
const validateProductInput = (data) => {
  const errors = [];
  
  if (!data.name || data.name.trim().length < 3) {
    errors.push('Product name must be at least 3 characters');
  }
  if (!data.description || data.description.trim().length < 10) {
    errors.push('Description must be at least 10 characters');
  }
  if (!data.price || data.price < 0) {
    errors.push('Valid price is required');
  }
  if (data.salePrice && data.salePrice >= data.price) {
    errors.push('Sale price must be less than regular price');
  }
  if (!data.category) {
    errors.push('Category is required');
  }
  if (data.stock === undefined || data.stock < 0) {
    errors.push('Valid stock quantity is required');
  }
  
  return errors;
};

// GET /api/products - Get all products with pagination, filtering, and sorting
const getProducts = async (req, res) => {
  try {
    const {
      category,
      search,
      page = 1,
      limit = 10,
      sortBy = 'createdAt',
      sortOrder = 'desc',
      minPrice,
      maxPrice,
      minRating,
      featured
    } = req.query;

    // Build filter object
    const filter = { isActive: true };
    
    if (category) filter.category = category;
    if (featured === 'true') filter.isFeatured = true;
    if (minRating) filter.averageRating = { $gte: parseFloat(minRating) };
    
    // Price range filter
    if (minPrice || maxPrice) {
      filter.price = {};
      if (minPrice) filter.price.$gte = parseFloat(minPrice);
      if (maxPrice) filter.price.$lte = parseFloat(maxPrice);
    }
    
    // Search filter
    if (search) {
      filter.$or = [
        { name: { $regex: search, $options: 'i' } },
        { description: { $regex: search, $options: 'i' } },
        { tags: { $in: [new RegExp(search, 'i')] } }
      ];
    }

    // Calculate pagination
    const pageNum = Math.max(1, parseInt(page));
    const limitNum = Math.min(100, Math.max(1, parseInt(limit)));
    const skip = (pageNum - 1) * limitNum;

    // Build sort object
    const sortObj = {};
    const validSortFields = ['createdAt', 'price', 'averageRating', 'name'];
    const sortField = validSortFields.includes(sortBy) ? sortBy : 'createdAt';
    sortObj[sortField] = sortOrder === 'asc' ? 1 : -1;

    // Execute query
    const products = await Product.find(filter)
      .sort(sortObj)
      .skip(skip)
      .limit(limitNum)
      .select('-imagePublicId -createdBy');

    // Get total count for pagination
    const total = await Product.countDocuments(filter);

    res.json({
      success: true,
      data: products,
      pagination: {
        total,
        page: pageNum,
        limit: limitNum,
        pages: Math.ceil(total / limitNum)
      }
    });
  } catch (err) {
    res.status(500).json({
      success: false,
      message: 'Error fetching products',
      error: err.message
    });
  }
};

// GET /api/products/featured - Get featured products
const getFeaturedProducts = async (req, res) => {
  try {
    const limit = Math.min(20, parseInt(req.query.limit) || 10);
    
    const products = await Product.find({ isActive: true, isFeatured: true })
      .sort({ createdAt: -1 })
      .limit(limit)
      .select('-imagePublicId -createdBy');

    res.json({
      success: true,
      data: products
    });
  } catch (err) {
    res.status(500).json({
      success: false,
      message: 'Error fetching featured products',
      error: err.message
    });
  }
};

// GET /api/products/trending - Get trending products by rating
const getTrendingProducts = async (req, res) => {
  try {
    const limit = Math.min(20, parseInt(req.query.limit) || 10);
    
    const products = await Product.find({ isActive: true, totalReviews: { $gt: 0 } })
      .sort({ averageRating: -1, totalReviews: -1 })
      .limit(limit)
      .select('-imagePublicId -createdBy');

    res.json({
      success: true,
      data: products
    });
  } catch (err) {
    res.status(500).json({
      success: false,
      message: 'Error fetching trending products',
      error: err.message
    });
  }
};

// GET /api/products/:id - Get single product by ID
const getProductById = async (req, res) => {
  try {
    const product = await Product.findById(req.params.id)
      .select('-imagePublicId -createdBy');
    
    if (!product || !product.isActive) {
      return res.status(404).json({
        success: false,
        message: 'Product not found'
      });
    }
    
    res.json({
      success: true,
      data: product
    });
  } catch (err) {
    if (err.kind === 'ObjectId') {
      return res.status(404).json({
        success: false,
        message: 'Invalid product ID'
      });
    }
    res.status(500).json({
      success: false,
      message: 'Error fetching product',
      error: err.message
    });
  }
};

// POST /api/products - Create new product (admin only)
const createProduct = async (req, res) => {
  try {
    const { name, description, price, salePrice, category, stock, sku, sizes, colors, brand, tags } = req.body;

    // Validate input
    const errors = validateProductInput({ name, description, price, salePrice, category, stock });
    if (errors.length > 0) {
      return res.status(400).json({
        success: false,
        message: 'Validation errors',
        errors
      });
    }

    // Check for duplicate SKU
    if (sku) {
      const existingSku = await Product.findOne({ sku });
      if (existingSku) {
        return res.status(400).json({
          success: false,
          message: 'Product with this SKU already exists'
        });
      }
    }

    // Handle image upload
    const getBaseUrl = req => `${req.protocol}://${req.get('host')}`;
    const imageUrl = req.file ? `${getBaseUrl(req)}/uploads/${req.file.filename}` : '';
    const imagePublicId = req.file ? req.file.filename : '';

    // Create product
    const product = await Product.create({
      name: name.trim(),
      description: description.trim(),
      price: parseFloat(price),
      salePrice: salePrice ? parseFloat(salePrice) : undefined,
      category,
      stock: parseInt(stock),
      sku: sku ? sku.trim() : undefined,
      image: imageUrl,
      imagePublicId,
      sizes: sizes ? (typeof sizes === 'string' ? sizes.split(',').map(s => s.trim()) : sizes) : [],
      colors: colors ? (typeof colors === 'string' ? colors.split(',').map(c => c.trim()) : colors) : [],
      brand: brand ? brand.trim() : undefined,
      tags: tags ? (typeof tags === 'string' ? tags.split(',').map(t => t.trim()) : tags) : [],
      createdBy: req.user._id
    });

    res.status(201).json({
      success: true,
      message: 'Product created successfully',
      data: product
    });
  } catch (err) {
    res.status(500).json({
      success: false,
      message: 'Error creating product',
      error: err.message
    });
  }
};

// PUT /api/products/:id - Update product (admin only)
const updateProduct = async (req, res) => {
  try {
    const product = await Product.findById(req.params.id);
    
    if (!product) {
      return res.status(404).json({
        success: false,
        message: 'Product not found'
      });
    }

    const { name, description, price, salePrice, category, stock, sku, sizes, colors, brand, tags, isFeatured } = req.body;

    // Validate input if provided
    if (name || description || price || category || stock !== undefined) {
      const errors = validateProductInput({
        name: name || product.name,
        description: description || product.description,
        price: price !== undefined ? price : product.price,
        salePrice: salePrice !== undefined ? salePrice : product.salePrice,
        category: category || product.category,
        stock: stock !== undefined ? stock : product.stock
      });
      if (errors.length > 0) {
        return res.status(400).json({
          success: false,
          message: 'Validation errors',
          errors
        });
      }
    }

    // Check for duplicate SKU if changed
    if (sku && sku !== product.sku) {
      const existingSku = await Product.findOne({ sku, _id: { $ne: product._id } });
      if (existingSku) {
        return res.status(400).json({
          success: false,
          message: 'Product with this SKU already exists'
        });
      }
    }

    // Update fields
    if (name) product.name = name.trim();
    if (description) product.description = description.trim();
    if (price !== undefined) product.price = parseFloat(price);
    if (salePrice !== undefined) product.salePrice = salePrice ? parseFloat(salePrice) : undefined;
    if (category) product.category = category;
    if (stock !== undefined) product.stock = parseInt(stock);
    if (sku) product.sku = sku.trim();
    if (sizes) product.sizes = typeof sizes === 'string' ? sizes.split(',').map(s => s.trim()) : sizes;
    if (colors) product.colors = typeof colors === 'string' ? colors.split(',').map(c => c.trim()) : colors;
    if (brand) product.brand = brand.trim();
    if (tags) product.tags = typeof tags === 'string' ? tags.split(',').map(t => t.trim()) : tags;
    if (isFeatured !== undefined) product.isFeatured = isFeatured;

    // Handle image update
    if (req.file) {
      if (product.imagePublicId) {
        try {
          await cloudinary.uploader.destroy(product.imagePublicId);
        } catch (err) {
          console.error('Error deleting old image:', err);
        }
      }
      const getBaseUrl = req => `${req.protocol}://${req.get('host')}`;
      product.image = `${getBaseUrl(req)}/uploads/${req.file.filename}`;
      product.imagePublicId = req.file.filename;
    }

    const updated = await product.save();
    
    res.json({
      success: true,
      message: 'Product updated successfully',
      data: updated
    });
  } catch (err) {
    res.status(500).json({
      success: false,
      message: 'Error updating product',
      error: err.message
    });
  }
};

// DELETE /api/products/:id - Delete product (admin only)
const deleteProduct = async (req, res) => {
  try {
    const product = await Product.findById(req.params.id);
    
    if (!product) {
      return res.status(404).json({
        success: false,
        message: 'Product not found'
      });
    }

    // Delete image from Cloudinary
    if (product.imagePublicId) {
      try {
        await cloudinary.uploader.destroy(product.imagePublicId);
      } catch (err) {
        console.error('Error deleting image:', err);
      }
    }

    // Delete additional images
    if (product.images && product.images.length > 0) {
      for (const img of product.images) {
        try {
          await cloudinary.uploader.destroy(img.publicId);
        } catch (err) {
          console.error('Error deleting image:', err);
        }
      }
    }

    await Product.findByIdAndDelete(req.params.id);
    
    res.json({
      success: true,
      message: 'Product deleted successfully'
    });
  } catch (err) {
    res.status(500).json({
      success: false,
      message: 'Error deleting product',
      error: err.message
    });
  }
};

// GET /api/products/categories - Get all categories
const getCategories = async (req, res) => {
  try {
    const categories = await Product.distinct('category', { isActive: true });
    res.json({
      success: true,
      data: categories
    });
  } catch (err) {
    res.status(500).json({
      success: false,
      message: 'Error fetching categories',
      error: err.message
    });
  }
};

module.exports = {
  getProducts,
  getFeaturedProducts,
  getTrendingProducts,
  getProductById,
  createProduct,
  updateProduct,
  deleteProduct,
  getCategories
};
