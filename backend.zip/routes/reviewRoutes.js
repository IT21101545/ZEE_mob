const express = require('express');
const router  = express.Router();
const { createReview, getProductReviews, getMyReviews, updateReview, deleteReview, getAllReviews, replyToReview } = require('../controllers/reviewController');
const { protect, adminOnly } = require('../middleware/authMiddleware');
const { upload } = require('../config/cloudinary');

router.post('/',                          protect, upload.single('image'), createReview);
router.get ('/my',                        protect, getMyReviews);
router.get ('/product/:productId',        getProductReviews);
router.put ('/:id',                       protect, updateReview);
router.delete('/:id',                     protect, deleteReview);

// Admin routes
router.get('/all', protect, adminOnly, getAllReviews);
router.put('/:id/reply', protect, adminOnly, replyToReview);
router.delete('/:id', protect, adminOnly, deleteReview);

module.exports = router;
