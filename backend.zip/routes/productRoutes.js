const express = require('express');
const router  = express.Router();
const { getProducts, getProductById, createProduct, updateProduct, deleteProduct } = require('../controllers/productController');
const { protect, adminOnly } = require('../middleware/authMiddleware');
const { upload } = require('../config/cloudinary');

const productUpload = upload.fields([
  { name: 'image', maxCount: 1 },
  { name: 'images', maxCount: 5 }
]);

router.get ('/',    getProducts);
router.get ('/:id', getProductById);
router.post('/',    protect, adminOnly, productUpload, createProduct);
router.put ('/:id', protect, adminOnly, productUpload, updateProduct);
router.delete('/:id', protect, adminOnly, deleteProduct);

module.exports = router;
