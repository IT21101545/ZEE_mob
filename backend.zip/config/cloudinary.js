const multer = require('multer');

// Use memory storage — files stay in RAM as Buffer
// Then controllers convert to Base64 and store in MongoDB
const storage = multer.memoryStorage();

const upload = multer({
  storage,
  limits: { fileSize: 5 * 1024 * 1024 }, // 5 MB max
  fileFilter: (req, file, cb) => {
    if (file.mimetype.startsWith('image/')) {
      cb(null, true);
    } else {
      cb(new Error('Only image files are allowed'), false);
    }
  }
});

// Helper: convert multer file buffer to Base64 data URI
const toBase64 = (file) => {
  if (!file) return '';
  const base64 = file.buffer.toString('base64');
  return `data:${file.mimetype};base64,${base64}`;
};

module.exports = { upload, toBase64 };
